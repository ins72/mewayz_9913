

<form class="mt-2 email subscribe subtitle-width-size" x-data="form__subscribe" :class="{'name': !onlyEmail()}">
    <div class="names-input">
        <template x-if="section.form.first_name_enable">
            <input name="firstname" type="text" class="shape" :placeholder="section.form.first_name ? section.form.first_name : '{{ __('First Name') }}'">
        </template>
        <template x-if="section.form.last_name_enable">
            <input name="lastname" type="text" class="shape" :placeholder="section.form.last_name ? section.form.last_name : '{{ __('Last Name') }}'">
        </template>
    </div>
    
    <input name="email" type="text" class="shape" :class="{'t-1': onlyEmail()}" :placeholder="section.form.email ? section.form.email : '{{ __('Email') }}'">
    
    <template x-if="section.form.phone_enable">
        <input name="phone" type="number" class="shape" :placeholder="section.form.phone ? section.form.phone : '{{ __('Phone') }}'">
    </template>
    <template x-if="section.form.message_enable">
        <textarea name="message" class="shape mt-[10px]" :placeholder="section.form.message ? section.form.message : '{{ __('Message') }}'"></textarea>
    </template>
    
    <button class="site-btn t-1 shape" :class="{'mt-2': !onlyEmail()}" x-text="section.form.button_name ? section.form.button_name : '{{ __('Sign up') }}'"></button>
    <div class="screen"></div>

    @script
    <script>
        Alpine.data('form__subscribe', () => {
           return {
            onlyEmail(){
                return !this.section.form.first_name_enable && !this.section.form.last_name_enable && !this.section.form.phone_enable && !this.section.form.message_enable;
            },
            init(){
               var $this = this;
            }
           }
        });
    </script>
    @endscript
</form>
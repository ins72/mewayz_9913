<div {{ $attributes }}>
    {{ $slot }}
</div>
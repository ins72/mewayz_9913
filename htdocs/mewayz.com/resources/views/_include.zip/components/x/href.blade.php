@props(['active'])

@php
    $_attributes = $attributes;
    $href = $attributes['href'];
    if(isset($attributes['href'])){
        $_attributes = $_attributes->merge(['wire:navigate' => 'true']);

        
        $parse = parse_url($href);
        if(request()->url() == $href){
            $_attributes = $_attributes->merge(['class' => '--active']);
        }
    }
@endphp

<a {{ $_attributes }} 
x-data="{ active: false, u() { this.active = window.location.href == '{{ $href }}' ? true : false; }}"
x-init="u()"
x-on:alpine:navigated.document="$nextTick(u)"
x-bind:class="active && '--active'">{{ $slot }}</a>
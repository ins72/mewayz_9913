<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
        @php
            $appName = config('app.name', 'Laravel');
        @endphp
        <title>{{ isset($title) ? "$appName - $title" : $appName }}</title>

        <!-- Scripts -->
        @vite([
            'resources/css/app.css',
            'resources/sass/app.scss',
            'resources/sass/console/console.scss',
            'resources/sass/console/console.sidebar.scss',
            'resources/sass/console/console.placeholder.scss',
            'resources/js/app.js'
        ])


        {{-- <script type="text/javascript" src="{{ gs('assets/js/navigate.turbo.js') }}" defer></script> --}}

        @livewireStyles
    </head>
    <body class="font-sans text-gray-900 antialiased light">
        
        <div id="app">

            @persist('app-utils')
               <livewire:components.console.utils.logout>
               <livewire:components.console.utils.toast lazy>
            @endpersist
            
            @persist('app-toolbar')
               <livewire:components.console.sidebar.toolbar lazy>
            @endpersist

            <div class="yena-app-wrapper flex w-full h-full relative">
               {{-- <div class="yena-sidebar">
                  @persist('sidebar-menu')
                     <livewire:components.console.sidebar.menu lazy>
                  @endpersist
               </div> --}}

               <div class="yena-root-main">

                  <div class="yena-container" id="yenaApp">
                     {{ $slot }}
                  </div>
               </div>
            </div>

            @stack('below-slot')
        </div>

        @stack('scripts')

        @livewireScriptConfig

        @vite([
         'resources/js/yenaWire.js'
        ])
    </body>
</html>

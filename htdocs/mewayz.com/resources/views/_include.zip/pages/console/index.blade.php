<?php
   
   use Carbon\Carbon;
   use function Laravel\Folio\name;
    
   name('console-index');
?>
<x-layouts.app>
   <x-slot:title>{{ __('Console') }}</x-slot>
   
   <div>
      <livewire:components.console.sites.page lazy/>
   </div>
</x-layouts.app>

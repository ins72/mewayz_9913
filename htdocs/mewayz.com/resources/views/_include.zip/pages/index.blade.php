<?php

?>
<x-layouts.base>
   <x-slot:title>{{ __('Notes') }}</x-slot>
   <script src="http://feeedbase.test/widget/v1.js" data-widget="260d0733-8d4d-4bf4-9d8e-e1894d35168a?"></script>

   <div>
      <div class="min-h-screen">
         <div class="mx-auto min-h-[400px] lg:min-h-[500px] mb-12 lg:mb-24 relative">
           <div class="">
       <header class="container mx-auto flex justify-between items-center">
         <div class="flex items-center p-8 lg:p-12">
           <a href="https://lore.saastheme-demo.com" rel="home" class="lg:mr-16"><img class="w-16 lg:w-24" src="https://lore.saastheme-demo.com/img/logo-dark.svg" alt="Lore - Saas Theme Demo"></a>
           <nav class="hidden lg:flex gap-x-12 ">
             <a href="https://lore.saastheme-demo.com/pricing" class="btn btn-link font-semibold">Pricing</a>
             <a href="https://lore.saastheme-demo.com/contact" class="btn btn-link font-semibold">Contact</a>
           </nav>
         </div>
         <div class="flex items-center gap-x-10 mr-4 lg:mr-8">
                       <a class="font-semibold" href="https://lore.saastheme-demo.com/login">Login</a>
           <a href="https://lore.saastheme-demo.com/pricing" class="flex text-base lg:text-base items-center justify-center rounded-3xl h-[40px] lg:h-[44px] w-40 bg-black font-semibold text-white hover:shadow-lg hover:drop-shadow-lg transition duration-200">
             <span class="tracking-tight">Get Started</span>
             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 16 16" class="ml-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
               <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"></path>
             </svg></a>
               </div>
       </header>
     </div>
           <main>
             <div class="relative">
       <div class="container mx-auto">
         <div class="bg-[#ebeb41] sm:rounded-3xl pl-8 lg:pl-12 pt-12 lg:pt-24 lg:min-h-screen flex items-center overflow-hidden">
           <div class="lg:flex justify-between items-center">
             <div class="lg:w-1/2 pr-12 mb-12 lg:mb-0">
               <h1 class="text-4xl md:text-5xl xl:text-7xl font-bold tracking-tight leading-none mb-4">SaaS boilerplate with style</h1>
               <p class="xl:w-4/6 leading-snug mb-4 text-lg lg:text-2xl">Lore is made by SaaS themes, save on development time and cost.</p>
               <div class="entry-meta flex items-center">
                 <div class="flex-shrink-0"><img class="rounded-full border border-4 border-[#ebeb41] w-10 h-10 lg:w-14 lg:h-14" src="https://lore.saastheme-demo.com/img/avatars/user-1.jpg"></div>
                 <div class="flex-shrink-0 -ml-3"><img class="rounded-full border border-4 border-[#ebeb41] w-10 h-10 lg:w-14 lg:h-14" src="https://lore.saastheme-demo.com/img/avatars/user-2.jpg"></div>
                 <div class="flex-shrink-0 -ml-3"><img class="rounded-full border border-4 border-[#ebeb41] w-10 h-10 lg:w-14 lg:h-14" src="https://lore.saastheme-demo.com/img/avatars/user-3.jpg"></div>
                 <div class="flex-shrink-0 -ml-3"><img class="rounded-full border border-4 border-[#ebeb41] w-10 h-10 lg:w-14 lg:h-14" src="https://lore.saastheme-demo.com/img/avatars/user-4.jpg"></div>
                 <div class="ml-2">
                   <p class="font-semibold leading-none">Rated 4.9 by 238+ customers</p>
                 </div>
               </div>
             </div>
             <div class="lg:w-1/2">
               <img class="w-full rounded-tl-3xl" src="https://lore.saastheme-demo.com/img/hero.jpg">
             </div>
           </div>
         </div>
       </div>
     </div>
     <section class="py-10">
       <div class="flex flex-col gap-y-5 items-center justify-center px-5 pt-12">
         <p class="text-center text-xl">We work with the most popular companies</p>
         <div class="grid w-full sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 grid-items-center gap-4">
           <div class="flex justify-center items-center h-24">
             <img class="h-14 w-24 lg:h-auto lg:w-auto grayscale" src="https://lore.saastheme-demo.com/img/logos/logoipsum-5.svg" alt="logo">
           </div>
           <div class="flex justify-center items-center h-24">
             <img class="h-14 w-24 lg:h-auto lg:w-auto grayscale" src="https://lore.saastheme-demo.com/img/logos/logoipsum-3.svg" alt="logo">
           </div>
           <div class="flex justify-center items-center h-24">
             <img class="h-14 w-24 lg:h-auto lg:w-auto grayscale" src="https://lore.saastheme-demo.com/img/logos/logoipsum-2.svg" alt="logo">
           </div>
           <div class="flex justify-center items-center h-24">
             <img class="h-14 w-24 lg:h-auto lg:w-auto grayscale" src="https://lore.saastheme-demo.com/img/logos/logoipsum-6.svg" alt="logo">
           </div>
           <div class="flex justify-center items-center h-24">
             <img class="h-14 w-24 lg:h-auto lg:w-auto grayscale" src="https://lore.saastheme-demo.com/img/logos/logoipsum-4.svg" alt="logo">
           </div>
           <div class="flex justify-center items-center h-24">
             <img class="h-14 w-24 lg:h-auto lg:w-auto grayscale" src="https://lore.saastheme-demo.com/img/logos/logoipsum-1.svg" alt="logo">
           </div>
         </div>
       </div>
     </section>
     
     <section class="pb-10">
       <div class="container mx-auto">
         <section class="py-10 sm:py-16 lg:py-24">
           <div class="max-w-5xl px-4 mx-auto sm:px-6 lg:px-8">
             <div class="text-center">
               <h2 class="text-3xl sm:text-4xl lg:text-[44px] font-bold mb-12 text-center">
                 <span class="border-b-4 border-[#ebeb41]"> Save weeks of development time </span>
               </h2>
             </div>
             <div class="grid grid-cols-1 mt-16 text-center md:mt-24 md:grid-cols-2 gap-y-10 gap-x-24">
               <div>
                 <div class="flex items-center justify-center">
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                 </div>
                 <blockquote class="mt-7">
                   <p class="text-xl leading-relaxed text-gray-800">“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam”</p>
                 </blockquote>
                 <img class="w-auto h-8 mx-auto mt-6 md:mt-10" src="https://lore.saastheme-demo.com/img/logos/logoipsum-1.svg" alt="">
               </div>
               <div>
                 <div class="flex items-center justify-center">
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                   <svg class="w-8 h-8 text-[#ebeb41]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                     <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                   </svg>
                 </div>
                 <blockquote class="mt-7">
                   <p class="text-xl leading-relaxed text-gray-800">“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam”</p>
                 </blockquote>
     
                 <img class="w-auto h-8 mx-auto mt-6 md:mt-10" src="https://lore.saastheme-demo.com/img/logos/logoipsum-2.svg" alt="">
               </div>
             </div>
           </div>
         </section>
     
         <section class="py-10 bg-gray-50 sm:rounded-3xl sm:py-16 lg:py-24">
           <div class="px-4 mx-auto max-w-7xl sm:px-6 lg:px-24">
             <div class="max-w-xl mx-auto text-center">
               <p class="font-bold text-blue-700 text-lg">Laravel SaaS Boilerplate</p>
               <h2 class="mt-6 text-3xl font-bold leading-tight text-black sm:text-4xl lg:text-5xl">Some of the best features to kickstart your project</h2>
             </div>
     
             <div class="grid items-center grid-cols-1 mt-12 gap-y-10 lg:grid-cols-5 sm:mt-20 gap-x-4">
               <div class="space-y-8 lg:pr-16 xl:pr-24 lg:col-span-2 lg:space-y-12">
                 <div class="flex items-start">
                   <svg class="flex-shrink-0 text-[#ebeb41] w-9 h-9" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
                   </svg>
                   <div class="ml-5">
                     <h3 class="text-xl font-semibold text-black">Simply Copy &amp; Paste</h3>
                     <p class="mt-3 text-base text-gray-600">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.</p>
                   </div>
                 </div>
                 <div class="flex items-start">
                   <svg class="flex-shrink-0 text-[#ebeb41] w-9 h-9" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                   </svg>
                   <div class="ml-5">
                     <h3 class="text-xl font-semibold text-black">Easy to Customize</h3>
                     <p class="mt-3 text-base text-gray-600">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.</p>
                   </div>
                 </div>
                 <div class="flex items-start">
                   <svg class="flex-shrink-0 text-[#ebeb41] w-9 h-9" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                   </svg>
                   <div class="ml-5">
                     <h3 class="text-xl font-semibold text-black">Made with TailwindCSS</h3>
                     <p class="mt-3 text-base text-gray-600">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.</p>
                   </div>
                 </div>
               </div>
               <div class="lg:col-span-3">
                 <img class="w-full rounded-lg shadow-lg" src="https://lore.saastheme-demo.com/img/screenshot.jpg" alt="">
               </div>
             </div>
           </div>
         </section>
       </div>
     </section>
     <section class="py-10">
       <div class="mx-auto">
         <div class="flex justify-center items-center">
           <h3 class="text-3xl sm:text-4xl lg:text-[44px] font-bold mb-12 text-center">What people are saying</h3>
         </div>
         <div class="container mx-auto px-6 lg:px-0">
           <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
           <div class="rounded-3xl flex flex-col justify-between bg-gray-50">
               <div class="p-6 lg:p-8 gap-y-2">
                 <p class="text-xl lg:text-2xl font-medium lg:leading-normal">“The clean codebase and thoughtful architecture of the boilerplate have significantly sped up our development cycles.”</p>
                 <div class="mt-5 flex items-center gap-x-2">
                   <div><img class="h-12 w-12 rounded-full" src="https://lore.saastheme-demo.com/img/avatars/user-1.jpg" alt="user"></div>
                   <div>
                     <p class="font-semibold">Stephanie H</p>
                     <p class="text-xs">CEO @ X Company</p>
                   </div>
                 </div>
               </div>
             </div>
             <div class="rounded-3xl flex flex-col justify-between bg-gray-50">
               <div class="p-6 lg:p-8 gap-y-2">
                 <p class="text-xl lg:text-2xl font-medium lg:leading-normal">“Lore has been a game-changer for our development team. Its well-organized structure and pre-built features saved us countless hours of coding.”</p>
                 <div class="mt-5 flex items-center gap-x-2">
                   <div><img class="h-12 w-12 rounded-full" src="https://lore.saastheme-demo.com/img/avatars/user-4.jpg" alt="user"></div>
                   <div>
                     <p class="font-semibold">Alberto F</p>
                     <p class="text-xs">Lead Dev @ SaaS X</p>
                   </div>
                 </div>
               </div>
             </div>
             <div class="rounded-3xl flex flex-col justify-between bg-gray-50">
               <div class="p-6 lg:p-8 gap-y-2">
                 <p class="text-xl lg:text-2xl font-medium lg:leading-normal">“The out-of-the-box features, including user authentication, subscription management, and billing, provide a solid groundwork for any SaaS application.”</p>
                 <div class="mt-5 flex items-center gap-x-2">
                   <div><img class="h-12 w-12 rounded-full" src="https://lore.saastheme-demo.com/img/avatars/user-3.jpg" alt="user"></div>
                   <div>
                     <p class="font-semibold">Jessica A</p>
                     <p class="text-xs">CTO @ Marketing X</p>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
       </section></main></div>
       </div>
       <div class="max-w-5xl mx-auto py-12 lg:pt-20">
         <div>
           <h3 class="text-3xl sm:text-4xl lg:text-[44px] max-w-xs mx-auto md:max-w-full md:mx-0 text-center font-bold leading-[1.15] text-black">Frequently asked questions</h3>
         </div>
         <div class="faq-container lg:mt-5">
           <div class="w-full px-7 md:px-10 xl:px-2 py-10">
             <div class="mx-auto w-full max-w-5xl">
               <div class="border-b border-black">
                 <div class="faq-question w-full block p-5">
                   <div class="flex w-full items-start gap-x-5 justify-between rounded-3xl cursor-pointer mb-2">
                     <h2 class="text-left text-lg font-bold pointer-events-none">Q1: What is Lore?</h2>
                     <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="faq-icon h-5 w-5 pointer-events-none rotate-180" xmlns="http://www.w3.org/2000/svg">
                       <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
                     </svg>
                   </div>
                   <div class="faq-answer">
                     <p>A1: Lore is a Laravel SaaS (Software as a Service) boilerplate that provides a solid foundation for building and deploying SaaS applications. It comes with pre-built features and modules to accelerate the development of your SaaS projects.</p>
                   </div>
                 </div>
               </div>
               <div class="border-b border-black">
                 <div class="faq-question w-full block p-5">
                   <div class="flex w-full items-start gap-x-5 justify-between rounded-3xl cursor-pointer mb-2">
                     <h2 class="text-left text-lg font-bold pointer-events-none">Q2: What are the key features of Lore?</h2>
                     <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="faq-icon h-5 w-5 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                       <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
                     </svg>
                   </div>
                   <div class="faq-answer hidden">
                     <p>A2: Lore includes essential features for SaaS development, such as user authentication, subscription management, billing, Stripe integration, and more. It's designed to save developers time by offering a robust starting point with common SaaS functionalities.</p>
                   </div>
                 </div>
               </div>
               <div class="">
                 <div class="faq-question w-full block p-5">
                   <div class="flex w-full items-start gap-x-5 justify-between rounded-3xl cursor-pointer mb-2">
                     <h2 class="text-left text-lg font-bold pointer-events-none">Q3: Is Lore customizable?</h2>
                     <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="faq-icon h-5 w-5 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                       <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
                     </svg>
                   </div>
                   <div class="faq-answer hidden">
                     <p>A3: Yes, Lore is highly customizable. It is built on Laravel, a flexible PHP framework, making it easy to extend and modify according to your project requirements. You can customize views, add new features, and integrate third-party packages as needed.</p>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>

       <footer class="py-12">
  <div class="container mx-auto">
    <div class="bg-black sm:rounded-3xl p-12">
      <div class="border-b border-white/30 mx-auto flex flex-col md:flex-row md:items-center md:justify-between px-8 lg:px-20 xl:px-0 pb-10">
        <div class="flex flex-col justify-start items-start">
          <h3 class="text-2xl lg:text-3xl text-white font-semibold max-w-lg">Advanced systems to ship your saas faster with boilerplate code</h3>
        </div>
      </div>
      <div class="mx-auto pt-10 flex flex-col md:flex-row md:items-center md:justify-between px-8 lg:px-20 xl:px-0">
        <div class="md:w-1/2 flex flex-col justify-start items-start"><button>
            <div class="flex items-center space-x-2">
              <a href="https://lore.saastheme-demo.com" rel="home"><img class="w-16 lg:w-24" src="https://lore.saastheme-demo.com/img/logo.svg" alt="Lore - Saas Theme Demo"></a>
            </div>
          </button>
          <p class="text-gray-100 text-sm mt-5 max-w-xs font-[400]">Save on development time and cost with our range of <a href="https://saasthemes.com/" target="_blank" rel="noopener">Laravel SaaS boilerplate themes</a>.</p>
          <p class="text-gray-100 text-sm mt-5 max-w-xs font-[400]">Credits <a href="https://logoipsum.com/" target="_blank" rel="noopener">Logo Ipsum</a>.</p>
          <p class="text-white text-sm mt-10">© Lore. All rights reserved.</p>
        </div>
        <div class="pt-5 md:w-1/2">
          <div class="flex gap-x-3 items-center justify-between px-0 lg:px-10">
            <ul class="text-gray-200 text-sm font-[400] flex flex-col gap-y-2">
              <li><a href="https://lore.saastheme-demo.com/pricing" class="transition hover:text-white">Pricing</a></li>
              <li><a href="#" class="transition hover:text-white">Press</a></li>
              <li><a href="#" class="transition hover:text-white">Careers</a></li>
              <li><a href="#" class="transition hover:text-white">Newsletter</a></li>
            </ul>
            <ul class="text-gray-200 text-sm font-[400] flex flex-col gap-y-2">
              <li><a href="https://lore.saastheme-demo.com/contact" class="transition hover:text-white">Contact</a></li>
              <li><a href="#" class="transition hover:text-white">Press</a></li>
              <li><a href="#" class="transition hover:text-white">Careers</a></li>
              <li><a href="#" class="transition hover:text-white">Newsletter</a></li>
            </ul>
            <ul class="text-gray-200 text-sm font-[400] flex flex-col gap-y-2">
                            <li><a href="https://lore.saastheme-demo.com/login" class="transition hover:text-white">Login</a></li>
                            <li><a href="#" class="transition hover:text-white">Press</a></li>
              <li><a href="#" class="transition hover:text-white">Careers</a></li>
              <li><a href="#" class="transition hover:text-white">Newsletter</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
   </div>
</x-layouts.base>

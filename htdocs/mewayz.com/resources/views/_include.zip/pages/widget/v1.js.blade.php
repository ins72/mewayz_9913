
<?php

   use function Laravel\Folio\render;
   use Illuminate\View\View;
   use Illuminate\Http\Response;
   
   render(function (View $view) {
      return response($view)->header('Content-Type', 'application/javascript');
   });
?>
(function () {
   // Read data-widget attribute from the script tag
   var scriptElement =
     document.currentScript || document.querySelector("script[data-widget]");
   var widgetId = scriptElement.getAttribute("data-widget");
 
   // Create the iframe element
   var iframe = document.createElement("iframe");
   iframe.src = "{{ config('app.url') }}/widget/" + widgetId;
   iframe.title = "feedback widget";
   iframe.height = "36";
   iframe.width = "125";
   iframe.allowTransparency = "true";
   iframe.style =
     "position: fixed; bottom: 0; left: 24px; z-index: 20; border: none; overflow: hidden; background: transparent;";
 
   // Function to set iframe width based on screen size
   var screenWidth = window.innerWidth;
 
   if (screenWidth >= 480) {
     // Large screens
     iframe.style.left = "24px";
   } else {
     // Small screens
     iframe.style.left = "0";
   }
 
   // Add event listener for iframe load
   iframe.addEventListener("load", function () {
     var timeoutId;
 
     // Add event listener for mouseenter
     iframe.addEventListener("mouseenter", function () {
       clearTimeout(timeoutId);
       iframe.height = "260";
       if (screenWidth >= 480) {
         // Large screens
         iframe.width = "320";
       } else {
         // Small screens
         iframe.width = screenWidth;
       }
     });
 
     // Add event listener for mouseleave
     iframe.addEventListener("mouseleave", function () {
       timeoutId = setTimeout(function () {
         iframe.height = "36";
         iframe.width = "125";
       }, 300);
     });
   });
 
   // Append the iframe to the page
   document.body.appendChild(iframe);
 })();
 
<?php
   use App\Models\ProjectPixel;
   use App\Models\ProjectPixelDatum;
   use App\Models\ProjectPixelKeyword;
   use DonatelloZa\RakePlus\RakePlus;
   use function Livewire\Volt\{state, mount, rules};
    
   state([
    'pixel_id' => '',
    'pixel' => [],
   ]);


   state([
      'reaction' => '',
      'feedback' => '',
      'email' => '',
   ]);
   
   mount(function(){
      if(!$this->pixel = ProjectPixel::where('pixel', $this->pixel_id)->first()) abort(404);
   });

   rules(fn() => [
      'reaction' => 'required',
      'feedback' => 'required',
   ]);

   state(successFeedback:false);
   $submitFeedback = function(){
      

      $this->validate();

      $new = new ProjectPixelDatum;
      $new->project_id = $this->pixel->id;
      $new->feedback = $this->feedback;
      $new->reaction = $this->reaction;
      $new->email = $this->email;
      $new->_tracking = tracking_log();
      $new->save();

      $phrases = RakePlus::create($this->feedback, 'en_US')->sort('asc')->get();

      $keywords = collect($phrases)->take(rand(1, 5));

      foreach ($keywords as $item) {
         $keyword = new ProjectPixelKeyword;
         $keyword->project_id = $this->pixel->id;
         $keyword->feedback_id = $new->id;
         $keyword->keyword = $item;
         $keyword->save();
      }

      // Successful
      $this->successFeedback = true;
   };
?>
<x-layouts.min-no-js>
   <x-slot:title>{{ __('Pixel') }}</x-slot>
   @volt
   <div>
      <div
      class="fixed bg-white w-full rounded-tr-xl shadow-md p-4 pb-2 border-t border-l border-r duration-300 h-56 -bottom-56 z-translate-y-56 hover:-translate-y-56">
      <div
         class="z-50 bg-white flex items-center absolute -top-[37px] mx-0 rounded-t-xl -left-[1px] text-center text-sm font-bold mb-2 border border-b-0 px-4 py-2">
         {{ __('Feedback') }}


         {!! __icon('interface-essential', 'chat-message-text 2', 'w-5 h-5 ml-3') !!}
      </div>

      @if ($successFeedback)
      <div class="h-32 items-center justify-center text-center flex flex-col">
         <div wire:transition.opacity>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="fill-red-500 text-red-500">
               <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
            </svg>
         </div>
         <div wire:transition.opacity>
            <div class="mt-3 text-sm text-slate-600">{{ __('Your feedback has been received!') }}</div>
         </div>
         <div wire:transition.opacity>
            <div class="mt-1 text-sm text-slate-600">{{ __('Thanks for helping us improve.') }}</div>
         </div>
      </div>
      @endif

      @if (!$successFeedback)
          
      <form class="space-y-3" wire:submit="submitFeedback" x-data="{reaction: @entangle('reaction')}">
         <div>
            <div>
               <x-yena.form-error-toast class="my-2" />
            </div>

            <div>
               <x-textarea-x wire:model="feedback" placeholder="{{ __('Your feedback...') }}" />
            </div>
            <div>
               <x-input-x wire:model="email" placeholder="{{ __('Email (Optional)') }}" />
            </div>
         </div>
         <div class="flex items-center justify-between">
            <div class="flex gap-1">
               <button type="button" @click="reaction = 'good'" class="p-2 hover:bg-green-100 hover:text-green-900 rounded-full duration-200" :class="{'bg-green-100 text-green-900': reaction == 'good'}">
                  {!! __icon('Smileys', 'Smileys.2', 'w-6 h-6') !!}
               </button>
               <button type="button" @click="reaction = 'normal'" class="p-2 hover:bg-yellow-100 hover:text-yellow-900 rounded-full duration-200" :class="{'bg-yellow-100 text-yellow-900': reaction == 'normal'}">
                  {!! __icon('Smileys', 'Smileys.14', 'w-6 h-6') !!}
               </button>
               <button type="button" @click="reaction = 'sad'" class="p-2 hover:bg-orange-100 hover:text-orange-900 rounded-full duration-200" :class="{'bg-orange-100 text-orange-900': reaction == 'sad'}">
                  {!! __icon('Smileys', 'Smileys.7', 'w-6 h-6') !!}
               </button>
            </div>
            <div>
               <button
                  class="inline-flex items-center text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-9 rounded-md px-3 justify-center w-20"
                  type="submit">
                  {{ __('Send') }}

                  {!! __icon('interface-essential', 'send-message-send-share.2', 'w-4 h-4 ml-1') !!}
               </button>
            </div>
         </div>
      </form>
      @endif
      <div
         class="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-center flex items-center justify-center text-[0.6rem] text-slate-500">
         {{ __('Powered by') }} <a href="{{ config('app.url') }}" target="_blank" class="font-bold text-slate-800 ml-1">{{ config('app.name') }}</a>
      </div>
   </div>
   </div>
   @endvolt
</x-layouts.min-no-js>

<?php
    use function Laravel\Folio\name;

    use App\Livewire\Actions\ToastUp;
    use App\Models\ProjectPixel;
    use function Livewire\Volt\{state, mount, rules, uses, updated};

    updated([
        'domain' => function (){
            $this->validate([
                'domain' => 'required|url'
            ]);
        },
    ]);
    
    uses([ToastUp::class]);
    name('create-project');

    state([
        '_name' => '',
        'domain' => ''
    ]);

    rules(fn() => [
        'name' => 'required|string',
        'domain' => 'required|url',
    ]);
   
    $create = function (){
        // Check for plans limit

        $this->validate();

        $project = new ProjectPixel;
        $project->pixel = str()->uuid();
        $project->name = $this->name;
        $project->domain = $this->domain;
        $project->user_id = iam()->id;
        $project->save();

        $this->js(
            '
                window.runToast("success", "'. __('Project created successfully') .'")
                setTimeout(function() {
                    Livewire.navigate("/console");
                }, 2000);
            '
        );
    };
?>
<x-layouts.base>
   <x-slot:title>{{ __('Create Project') }}</x-slot>
  
   @volt
   <div>
    <div class="bg-[#f8f9fb] flex h-full w-full items-center justify-center min-h-screen">
        <form class="bg-white flex w-[420px] flex-col items-center gap-6 rounded-2xl p-10 shadow-lg" wire:submit="create">
           <img src="/assets/Logo-icon-eeca8df4.png" width="32px">
            <div class="flex w-full flex-col gap-2">
                <h2 class="text-display-xs text-content-primary text-center font-bold">Welcome to Doocs.app</h2>
                <p class="text-content-secondary text-center">Let's get started by choosing a subdomain for your documentation site.</p>
            </div>
            <div class="flex w-full flex-col gap-2">
  
              <div>
                  <x-input-x wire:model.live.debounce.300ms="name" placeholder="{{ __('Project name') }}" />
              </div>
              <div>
                  <x-input-x wire:model.live.debounce.300ms="domain" placeholder="{{ __('Project domain') }}" />
              </div>

              <x-yena.form-error-toast class="" />
              
              @php
                $isError = false;
        
                if(!$errors->isEmpty()) $isError = true;

                if(Session::get('error._error')) $isError = true;

                if(empty($name) || empty($domain)) $isError = true;
              @endphp
              
              <button class="z-0 group relative inline-flex items-center justify-center box-border appearance-none select-none whitespace-nowrap font-normal subpixel-antialiased overflow-hidden tap-highlight-transparent outline-none data-[focus-visible=true]:z-10 data-[focus-visible=true]:outline-2 data-[focus-visible=true]:outline-focus data-[focus-visible=true]:outline-offset-2 px-unit-4 min-w-unit-20 h-unit-10 text-small gap-unit-2 rounded-medium w-full [&amp;>svg]:max-w-[theme(spacing.unit-8)] data-[pressed=true]:scale-[0.97] transition-transform-colors motion-reduce:transition-none bg-primary text-primary-foreground cursor-pointer {{ $isError ? 'opacity-disabled pointer-events-none' : '' }}" {{ $isError ? 'disabled' : '' }}>{{ __('Create') }}</button>
            </div>
            
            <a class="z-0 group relative inline-flex items-center justify-center box-border appearance-none select-none whitespace-nowrap font-normal subpixel-antialiased overflow-hidden tap-highlight-transparent outline-none data-[focus-visible=true]:z-10 data-[focus-visible=true]:outline-2 data-[focus-visible=true]:outline-focus data-[focus-visible=true]:outline-offset-2 px-unit-4 min-w-unit-20 h-unit-10 text-small gap-unit-2 rounded-medium w-full [&amp;>svg]:max-w-[theme(spacing.unit-8)] data-[pressed=true]:scale-[0.97] transition-transform-colors motion-reduce:transition-none text-default-foreground bg-[#f8f9fb] hover:bg-[#f2f3f6]" href="{{ route('console-index') }}" wire:navigate.hover>{{ __('Go Home') }}</a>
        </form>
    </div>
   </div>
   @endvolt
</x-layouts.base>

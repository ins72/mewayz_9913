<?php

use App\Livewire\Forms\LoginForm;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Session;

use function Livewire\Volt\form;
use function Livewire\Volt\state;
use function Livewire\Volt\layout;

layout('components.layouts.base');

form(LoginForm::class);

$login = function () {
    $this->validate();

    $this->form->authenticate();

    Session::regenerate();

    $this->redirect(route('console-index'),
        navigate: true
    );
};

?>
<div>

    <div x-init="window.__livewirelazy($wire.__instance)"></div>
    <div class="flex min-h-screen">
        <div class="flex items-center justify-center bg-[var(--yena-colors-white)] flex-1 md:max-w-[var(--yena-sizes-container-sm)]">

            <div class="auth-page">
                <div class="auth-page-header">
                   <div class="auth-page-logo flex justify-center">
                        <img src="https://lore.saastheme-demo.com/img/logo-dark.svg" class="h-16 w-16 object-contain" alt=" " width="36" class="block">
                    </div>
            
                   <h1 class="text-center">{{ __('Welcome back.') }}</h1>
            
                   <div inline="true" class="inline-flex items-center text-[14px]">
                      <div class="m-0">
                        <i class="fi fi-rr-info flex"></i>
                      </div>
                      <div class="ml-1">{{ __('You\'re new here?') }}
                        <a href="{{ route('register') }}" wire:navigate><b>{{ __('Create an account.') }}</b></a></div>
                   </div>
                </div>
            
        
                @if ($auth = Auth::user())
                <div class="flex justify-between bg-white shadow-xl rounded-lg mt-5 -is-login-card">
                    <div class="flex flex-gap-10">
                         <div class="o-avatar m-1">
                            <img src="{{ $auth->getAvatar() }}" alt="">
                         </div>
                         <div class="m-1">
                             <div class="font--11 --title">{{ __('Welcome back') }}</div>
                             <div class="font-semibold --desc font--14">{{ $auth->name }}</div>
                         </div>
                    </div>
             
                    <a href="{{ route('console-index') }}" wire:navigate class="m-1">
                       <button type="button" class="ui-button ui-button-button ui-button-small ui-button-outline ">
                         <div class="flex items-center">
                            <!----> 
                            <div>{{ __('Continue') }}</div>
                            <div>
                             <i class="fi fi-rr-angle-small-right flex"></i>
                            </div>
                         </div>
                       </button>
                    </a>
                 </div>
                @endif
                @php
                    $error = false;
            
                    if(!$errors->isEmpty()){
                        $error = $errors->first();
                    }
                    
                    if(Session::get('error')) $error = Session::get('error');
                @endphp

                <form wire:submit="login" class="auth-form mt-10">
                            
                    @if ($error)
                    <div class="mb-5 bg-red-200 text-[11px] p-1 px-2 rounded-md">
                        <div class="flex items-center">
                            <div>
                                <i class="fi fi-rr-cross-circle flex"></i>
                            </div>
                            <div class="flex-grow ml-1">{{ $error }}</div>
                        </div>
                    </div>
                    @endif
                
                <script>
                    function _login(){
                        return {
                            email: @entangle('form.email'),
                            password: @entangle('form.password'),
                            showPassword: false,

                            shown(){
                                if(this.password !== '' && this.password !== null && this.showPassword) return true;
                                return false;
                            },
                        }
                    }
                </script>
                
                <div x-data="_login">
                        <div class="form-input">
                            <label>{{ __('Your Email') }}</label>
                            <input type="email" name="email" x-model="email" placeholder="{{ __('e.g: jeffjola@gmail.com') }}">
                        </div>
                        <div class="form-input mt-4">
                            <label>{{ __('Your Password') }}</label>
                            <div class="relative">
                                <input type="password" name="password" x-model="password" placeholder="*******" class="transition-all" :class="{'pb-[2.4rem!important]' : shown()}">

                                <div class="p-2 absolute right-1 cursor-pointer" :class="{'top-2/4 transform -translate-y-1/2': !shown(), 'top-1': shown()}" @click="showPassword =! showPassword">
                                    <span x-cloak :class="{'hidden': !shown()}">
                                        {!! __icon('interface-essential', 'eye-show-visible', 'w-4 h-4') !!}
                                    </span>
                                    <span x-cloak :class="{'hidden': shown()}">
                                        {!! __icon('interface-essential', 'eye-hidden', 'w-4 h-4') !!}
                                    </span>
                                </div>
                            </div>

                            <div class="w-full px-[10px] pb-[6px] absolute bottom-0" :class="{'hidden': !shown()}">
                                <span class="text-xs" x-text="shown() ? password : ''"></span>
                            </div>
                        </div>
                        <button type="submit" class="yena-button-stack w-full mt-5" :class="{'opacity-40 cursor-not-allowed [box-shadow:var(--yena-shadows-none)] pointer-events-none': email == '' || email == null || password == '' || password == null}">
                            <div class="flex justify-center items-center">
                                <div>{{ __('Login now') }}</div>
                                <div>
                                    <i class="fi fi-rr-angle-small-right flex"></i>
                                </div>
                            </div>
                        </button>
                </div>

                <div class="mt-5 text-[11px] text-center">{{ __('Forgot your password?') }}
                    <a href="{{ route('password.request') }}" wire:navigate class=""><b>{{ __('Reset it here.') }}</b></a>
                </div>


                @if (config('app.GOOGLE_ENABLE'))
                <a href="{{ route('auth-google', isset($extra) ? $extra : null) }}">
                    <button type="button" class="w-full bg-white mt-5 ui-button ui-button-button ui-button-base ui-button-outline h--40">

                        <div class="flex items-center justify-center">
                            <div>
                                <svg class="icon w-6 h-6">
                                <use xlink:href="{{ gs('assets/image/svg','sprite.svg#icon-google-icon') }}"></use>
                                </svg>
                            </div>
                            <div class="ml-1">{{ __('Login with Google') }}</div>
                        </div>
                    </button>
                </a>
                @endif
                @if (config('app.FACEBOOK_ENABLE'))
                <a href="{{ route('auth-facebook', isset($extra) ? $extra : null) }}">
                    <button type="button" class="w-full bg-white mt-5 ui-button ui-button-button ui-button-base ui-button-outline h--40">

                        <div class="flex items-center justify-center">
                            <div>
                                <i class="fi fi-brands-facebook flex"></i>
                            </div>
                            <div class="ml-1">{{ __('Login with Facebook') }}</div>
                        </div>
                    </button>
                </a>
                @endif

                <div class="text-[11px] color-gray mt-5">
                    @php
                        $terms_link = settings('others.terms');
                        $privacy_link = settings('others.privacy');
                    @endphp
                    {!! __t("By logging in, I agree to the <a href=\"$terms_link\">Terms of service</a> and <a href=\"$privacy_link\">Privacy policy</a>. I also agree to receive emails and communication relating to our services and offers.") !!}
                    
                </div>
                </form>
             </div>
        </div>
        
        <div style="--bg-url: url({{ gs('assets/image/others/pexels-rnd-photography-18058712.png') }})" class="flex [background:var(--bg-url)_center_bottom_/_cover_no-repeat] flex-1 relative overflow-hidden">
        </div>
    </div>
</div>

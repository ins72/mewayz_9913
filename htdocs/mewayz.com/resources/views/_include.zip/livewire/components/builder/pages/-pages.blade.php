
<?php

   use App\Models\Section;
   use App\Models\Page;
   use App\Models\SiteHeaderLink;
   use function Livewire\Volt\{state, mount, placeholder, on};

   // Functions
   placeholder('
   <div class="w-full p-5 mt-1">
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
   </div>');

   state(['site']);

   state([
      'pages' => [],
   ]);

   // // Methods
   // $getPages = function(){
   //    $this->pages = $this->site->pages()->orderBy('id', 'asc')->get();
   // };

   // $setPage = function($page){

   //    $this->site->current_edit_page = $page;
   //    $this->site->save();

   //    // Disptach Event
   //    $this->dispatch('builder::setPage');
   // };

   $duplicatePage = function($item){
      
      $page = new Page;
      $page->fill($item);
      $page->name = $page->name . '_copy';
      $page->default = 0;
      $page->save();

      
      $layouts = Section::where('page_id', __a($item, 'id'))->get();

      foreach($layouts as $_item){
         $layout = $_item->replicate();
         $layout->page_id = $page->id;
         $layout->save();

         foreach ($_item->items()->get() as $sec) {
            $section = $sec->replicate();
            $section->section_id = $layout->id;
            $section->save();
         }
      }

      $this->js("pages.push(". collect($page)->toJson() .")");

      return $page;
      // $this->js("this.setPage($page->id)");
   };

   $setAsHome = function($id){
      $this->site->pages()->update([
         'default' => 0,
      ]);
      if(!$page = $this->site->pages()->where('id', $id)->first()) return;

      $page->default = 1;
      $page->save();
      $this->dispatch('hideTippy');
   };

   $deletePage = function($id){
      if(!$page = $this->site->pages()->where('id', $id)->first()) return;

      $page->sections()->delete();

      $page->processDelete();

      // $this->getPages();
      $this->dispatch('hideTippy');
   };

   $add_to_header = function($item){
       $_item = new SiteHeaderLink;
       $_item->fill($item);
       $_item->site_id = $this->site->id;
       $_item->save();
   };
?>

<div>

   <div class="website-section" wire:ignore x-data="builder__pages">
      <div>
         <div x-show="createPage">
            <livewire:components.builder.parts.pages.new-page :$site lazy :key="uukey('builder', 'pages-new-page')" />
         </div>
      </div>
   
      <template x-if="!createPage">
         <div>
            <div class="design-navbar">
               <ul >
                  <li class="close-header !flex">
                      <a @click="navigatePage('-')">
                          <span>
                              {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                          </span>
                      </a>
                  </li>
                  <li class="!pl-0">{{ __('Pages') }}</li>
                  <li class="!flex md:!hidden">
                      <a @click="navigatePage('-')" class="menu--icon !bg-black !text-[10px] !text-white !w-auto !px-2 !h-5 cursor-pointer">
                          {{ __('Close') }}
                      </a>
                  </li>
               </ul>
            </div>
            <div class="container-small">
               <div class="mt-2 website-pages">
                  <div class="flex flex-col gap-2 mt-4 lg:flex-row">
            
                     <a href="" class="yena-button-stack --black">
                        <div class="--icon">
                           {!! __icon('interface-essential', 'plus-add.3', 'w-6 h-6') !!}
                        </div>
         
                        {{ __('Create new') }}
         
                        <div class="inline-flex self-center ml-2 shrink-0">
                           <div class="--badge">{{ __('AI') }}</div>
                        </div>
                     </a>
                     
                     <a wire:click="createBlank" class="cursor-pointer yena-button-stack">
                        <div class="--icon">
                           {!! __icon('interface-essential', 'plus-add.3', 'w-6 h-6') !!}
                        </div>
         
                        {{ __('New from blank') }}
                     </a>
                  </div>
                  <a class="yena-button-stack w-full !mt-1" @click="createPage=true">
                     {{ __('New Page') }}
                  </a>
                  <ul class="mb-1 add-new-page !hidden" @click="createPage=true">
                     <li >
                        <span >
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M12 5V19" stroke="var(--background)"></path>
                              <path d="M5 12H19" stroke="var(--background)"></path>
                           </svg>
                        </span>
                        {{ __('New Page') }}
                     </li>
                  </ul>
                  <ul >
                     <template x-for="(item, index) in pages" :key="index">
                        <li class="page-list-section" :class="{
                           'active': site.current_edit_page == item.id
                           }" @click="setPage(item.id)" x-data="{
                           tippy: {
                              content: () => $refs.template.innerHTML,
                              allowHTML: true,
                              appendTo: $root,
                              maxWidth: 360,
                              interactive: true,
                              trigger: 'click',
                              animation: 'scale',
                           }
                        }">
                           <span class="home-icon page-list-item">
                              <template x-if="item.default">
                                 {!! __i('interface-essential', 'home-house-line') !!}
                              </template>
                              
                              <span x-text="item.name"></span>
                           </span>
                           <span class="page-list-option" @click="$event.stopPropagation();" x-tooltip="tippy">
                              {!! __icon('interface-essential', 'dots-menu') !!}
                           </span>
                                          
                           <template x-ref="template">
                              <div class="yena-menu-list !w-full">
                                 <a @click="duplicatePage(item)" class="yena-menu-list-item">
                                    <div class="--icon">
                                       {!! __icon('interface-essential', 'copy-duplicate-object-add-plus', 'w-5 h-5') !!}
                                    </div>
                                    <span>{{ __('Duplicate') }}</span>
                                 </a>
                                 <a href="" class="yena-menu-list-item">
                                    <div class="--icon">
                                       {!! __icon('interface-essential', 'share-arrow.1', 'w-5 h-5') !!}
                                    </div>
                                    <span>{{ __('Copy link') }}</span>
                                 </a>
                                 <a @click="addToHeader(item)" class="yena-menu-list-item">
                                    <div class="--icon">
                                       {!! __icon('Type, Paragraph, Character', 'header', 'w-5 h-5') !!}
                                    </div>
                                    <span>{{ __('Add to Header') }}</span>
                                 </a>
                                 
                                 <a @click="setAsHome(item);" class="yena-menu-list-item">
                                    <div class="--icon">
                                       {!! __icon('interface-essential', 'home-house-line 2', 'w-5 h-5') !!}
                                    </div>
                                    <span>{{ __('Set as Home') }}</span>
                                 </a>
                                 
                                 <a @click="setPage(item.id); navigatePage('settings');" class="yena-menu-list-item">
                                    <div class="--icon">
                                       {!! __icon('interface-essential', 'setting4', 'w-5 h-5') !!}
                                    </div>
                                    <span>{{ __('Settings') }}</span>
                                 </a>
                                 
                                 <hr class="--divider">
                                 <a class="yena-menu-list-item !text-[color:red] cursor-pointer" @click="deletePage(item);">
                                    <div class="--icon">
                                       {!! __icon('interface-essential', 'delete-disabled.2', 'w-5 h-5') !!}
                                    </div>
                                    <span>{{ __('Permanently delete') }}</span>
                                 </a>
                              </div>
                           </template>
                        </li>
                     </template>
                  </ul>
               </div>
            </div>
         </div>
      </template>
   </div>

   
   @script
      <script>
         Alpine.data('builder__pages', () => {
            return {
               createPage: false,

               duplicatePage(item){
                  var $this = this;
                  this.$wire.duplicatePage(item).then(r => {
                     $this.setPage(r.id);
                  });
               },
               
               addToHeader(_i){
                  var count = this.siteheader.links.length + 1;

                  var url = _i.slug;
                  var slug = _i.slug;

                  this.pages.forEach((x, i) => {
                      if(x.default && x.id == _i.id){
                          slug = '';
                      };
                  });

                  url = `/${slug}`;

                  let item = {
                     uuid: this.$store.builder.generateUUID(),
                     title: _i.name,
                     link: url,
                     position: count,
                  };

                  this.siteheader.links.push(item);

                  this.$wire.add_to_header(item);
               },

               setPage(page_id){
                  this.site.current_edit_page = page_id;

                  this.broadcastSite();
                  this.$dispatch('builder::setPage');
                  this.$dispatch('builder::saveSite');
                  
                  this.getCurrentPage();
               },

               setAsHome(item){
                  this.pages.forEach(element => {
                     element.default=0;
                  });
                  item.default=1;
                  this.$wire.setAsHome(item.id);
               },

               deletePage(item){
                  let index = 0;
                  this.pages.forEach(element => {
                     if(item.id == element.id){
                        this.pages.splice(index, 1);
                     }

                     index++;
                  });
                  this.$wire.deletePage(item.id);
                  this.$dispatch('builder::reloadPage');
                  
                  this.getCurrentPage();
               },

               init(){
                  window.addEventListener('builder::setAsHomeEvent', (event) => {
                     this.setAsHome(event.detail);
                  });
                  window.addEventListener('builder::deletePageEvent', (event) => {
                     this.deletePage(event.detail);
                  });
               }
            }
         });
      </script>
   @endscript
</div>

<?php

   use function Livewire\Volt\{state, mount, placeholder, on};

   state([
      '__page' => '-',
      'site',
   ]);

   placeholder('
   <div class="p-5 w-full mt-1">
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
   </div>');

   on([
    
   ]);
?>

<div>

   <div x-data="builder__settings">

      <div x-show="__page == 'section'">
          <div>
            ddd
          </div>
      </div>

      <div x-cloak x-show="__page == '-'">
        <div class="settings-section section">
            <div class="settings-section-content">
        
                <div class="top-bar">
                  <div class="page-settings-navbar">
                     <ul >
                         <li class="close-header !flex">
                         <a @click="navigatePage('pages')">
                             <span>
                                 {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                             </span>
                         </a>
                     </li>
                     <li class="!pl-0">{{ __('Settings') }}</li>
                     <li></li>
                     </ul>
                 </div>
                 <div class="container-small sticky">
                     <div class="tab-link">
                         <ul class="tabs">
                         <li class="tab !w-full" @click="__tab = 'page'" :class="{'active': __tab == 'page'}">{{ __('Page') }}</li>
                         <li class="tab !w-full" @click="__tab = 'site'" :class="{'active': __tab == 'site'}">{{ __('Site') }}</li>
                         </ul>
                     </div>
                 </div>
                </div>
                <div class="container-small tab-content-box">
                    <div class="tab-content">
                        <div x-cloak :class="{'active': __tab == 'page'}" data-tab-content>
                            <div  class="page-settings mt-2">
                                <div  class="seo-content mt-2">
                                    <form  action="" method="post" onsubmit="return false">
                                        <div class="input-box">
                                            <div class="input-label">{{ __('Title') }}</div>
                                            <div class="input-group">
                                                <input type="text" class="input-small" placeholder="{{ __('Add title') }}" x-model="currentPage.name">
                                            </div>
                                        </div>
                                        <template x-if="!currentPage.default">
                                            <div class="input-box">
                                                <div class="input-label">{{ __('Link') }}</div>
                                                <div class="input-group">
                                                    <input type="text" class="input-small" placeholder="{{ __('Add link') }}" x-model="currentPage.slug">
                                                </div>
                                            </div>
                                        </template>
                                        <div  class="post-settings">
                                            
                                        </div>
                                    </form>
                                </div>
                                <div  class="page-actions">
                                    <ul >
                                        <template x-if="!currentPage.default">
                                        <li>
                                            <div class="input-box !mt-0">
                                                <div class="input-group !border-0">
                                                    <div class="switchWrapper">
                                                        <input id="set-homepage" type="checkbox" class="switchInput !border-0" x-model="currentPage.default" x-on:input="$dispatch('builder::setAsHomeEvent', currentPage)">
                                                        <label for="set-homepage" class="switchLabel">{{ __('Set as homepage') }}</label>
                                                        <div class="slider"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        </template>
                                        
                                        <li >
                                            <a  name="duplicate">{{ __('SEO & Social') }}
                                            <span><svg  width="24" height="24" viewBox="0 0 24 24"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path  d="M9 18L15 12L9 6" stroke="var(--foreground)"
                                                            stroke-miterlimit="10" stroke-linecap="square"></path>
                                                    </svg>
                                                </span>
                                            </a>
                                        </li>
                                        <li class="!hidden">
                                            <a  name="duplicate"> Page password <span>
                                                <svg
                                                         width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path  d="M9 18L15 12L9 6" stroke="var(--foreground)"
                                                            stroke-miterlimit="10" stroke-linecap="square"></path>
                                                    </svg>
                                                </span>
                                            </a>
                                        </li>
                                        <li><a  name="duplicate"> Duplicate page </a></li>


                                        <li class="mb-2 !hidden" @click="deletePage();">
                                            <a class="delete-page-link" name="delete">{{ __('Delete page') }}</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                        <div x-cloak :class="{'active': __tab == 'site'}" data-tab-content>
                            <div class="site-settings-section mt-2">
                                <form action="" method="post" onsubmit="return false">
                                   <div class="input-box">
                                      <div class="input-label active" for="display">Title</div>
                                      <div class="input-group"><input type="text" class="input-small" placeholder="Your Site"></div>
                                   </div>
                                   <div class="input-box">
                                      <div class="input-label active" for="display">Domain</div>
                                      <div class="input-group"><input type="text" class="input-small domain-name" maxlength="20" placeholder="Site Link"><span>.vzy.io</span></div>
                                   </div>
                                   <!---->
                                   <div class="input-box">
                                      <div class="input-label">Favicon</div>
                                      <div class="input-group">
                                         <button data-v-30a941e4="" class="btn btn-large btn btn-large heroPicker">
                                            <input data-v-30a941e4="" id="favicon-picker" type="file" accept="image/png, image/svg, image/gif, image/webp, .gif, .svg" style="display: none;">
                                            <div data-v-30a941e4="" class="svg-box"><span data-v-30a941e4="" class="icon undefined"><img data-v-30a941e4="" src="https://app.vzy.co/assets/icons/favicon.svg" alt="dark image"></span></div>
                                            <span data-v-30a941e4="">
                                               <svg data-v-30a941e4="" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-5fbb38d8="">
                                                  <path data-v-30a941e4="" d="M18.0036 8.00363L12 2M12 2L5.99637 8.00363M12 2V16M2 22H22" stroke="var(--foreground)" stroke-miterlimit="10" data-v-5fbb38d8=""></path>
                                               </svg>
                                            </span>
                                         </button>
                                      </div>
                                   </div>
                                   <div class="input-box">
                                      <div class="input-label active" for="display">Email</div>
                                      <div class="input-group"><input type="text" class="input-small" placeholder="Site Email"></div>
                                   </div>
                                </form>
                                <div class="site-actions mt-2">
                                   <div class="input-box">
                                      <div class="input-label" for="link"></div>
                                      <div class="input-group">
                                         <div class="switchWrapper">
                                            <input id="made-in-vzy" type="checkbox" class="switchInput" disabled=""><label for="made-in-vzy" class="switchLabel">Made in Vzy</label>
                                            <div class="slider"></div>
                                         </div>
                                      </div>
                                   </div>
                                   <div class="input-box">
                                      <div class="input-label" for="link"></div>
                                      <div class="input-group">
                                         <div class="switchWrapper">
                                            <input id="site-preloader" type="checkbox" class="switchInput"><label for="site-preloader" class="switchLabel">Site preloader</label>
                                            <div class="slider"></div>
                                         </div>
                                      </div>
                                   </div>
                                   <ul>
                                      <li>
                                         <a name="site plans">
                                            <p>Site plans</p>
                                            <span>
                                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                  <path d="M9 18L15 12L9 6" stroke="var(--foreground)" stroke-miterlimit="10" stroke-linecap="square"></path>
                                               </svg>
                                            </span>
                                         </a>
                                      </li>
                                      <li>
                                         <a name="signup">
                                            <p>Custom domain</p>
                                            <span>
                                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                  <path d="M9 18L15 12L9 6" stroke="var(--foreground)" stroke-miterlimit="10" stroke-linecap="square"></path>
                                               </svg>
                                            </span>
                                         </a>
                                      </li>
                                      <li>
                                         <a name="export-site">
                                            <p>Custom code</p>
                                            <span>
                                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                  <path d="M9 18L15 12L9 6" stroke="var(--foreground)" stroke-miterlimit="10" stroke-linecap="square"></path>
                                               </svg>
                                            </span>
                                         </a>
                                      </li>
                                      <li>
                                         <a name="vzy-pro">
                                            <p>Transfer site</p>
                                            <span>
                                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                  <path d="M9 18L15 12L9 6" stroke="var(--foreground)" stroke-miterlimit="10" stroke-linecap="square"></path>
                                               </svg>
                                            </span>
                                         </a>
                                      </li>
                                      <li>
                                         <a name="signup">
                                            <p>Duplicate site</p>
                                            <span></span>
                                         </a>
                                      </li>
                                      <li>
                                         <a name="export-site">
                                            <p>Export site </p>
                                            <span></span>
                                         </a>
                                      </li>
                                      <li>
                                         <a name="unpublish-site">
                                            <p class="error">Unpublish site</p>
                                            <span></span>
                                         </a>
                                      </li>
                                      <li class="mb-2">
                                         <a class="delete-site" name="vzy-pro">
                                            <p>Delete site</p>
                                            <span></span>
                                         </a>
                                      </li>
                                   </ul>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
      </div>
    
      @script
      <script>
          Alpine.data('builder__settings', () => {
             return {
                __tab: 'page',
                __page: @entangle('__page'),
                autoSaveTimer: null,
                deletePage() {
                    //if(!this.currentPage && this.pages.length > 0) this.currentPage = this.pages[0];
                    this.pages.forEach((element, index) => {
                        if(item.id == element.id){
                            this.pages.splice(index, 1);
                        }
                    });
                    // this.$wire.deletePage(item.id);
                    // this.$dispatch('builder::reloadPage');
                    
                    // this.getCurrentPage();
                    $dispatch('builder::deletePageEvent', this.currentPage);
                    $dispatch('builder::setPageEvent', this.pages[0].id);
                },
                init(){
                   var $this = this;

                     
                    this.$watch('currentPage' , (value, _v) => {
                        $this.$dispatch('builder::updatePage', $this.currentPage);
                        clearTimeout($this.autoSaveTimer);

                        $this.autoSaveTimer = setTimeout(function(){
                            $this.$store.builder.savingState = 0;
                            event = new CustomEvent("builder::savePage", {
                                detail: {
                                    page: $this.currentPage,
                                    js: '$store.builder.savingState = 2',
                                }
                            });

                            window.dispatchEvent(event);
                        }, $this.$store.builder.autoSaveDelay);
                    });
                }
             }
          });
      </script>
      @endscript
    </div>
</div>
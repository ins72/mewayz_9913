
<?php

   use App\Models\SiteHeaderLink;
   use App\Models\Section;
   use App\Models\SectionItem;
   use function Livewire\Volt\{state, mount, on, updated};

   state([
      'site',
      'sections' => [],
      'section' => [],
      'pages' => [],

      'siteArray' => [],
      'headerLinks' => [],
   ]);

   mount(function(){
      $this->getSections();
      $this->getPages();

      $this->getHeaderLinks();

      $this->siteArray = $this->site->toArray();
   });

   on([
      'builder::refreshSections' => function($section){
         $this->getSections();
      },

      'section::deleteItem' => function ($item) {
         if(!$_item = SectionItem::where('uuid', $item)) return;

         $_item->delete();

         // Dispatch another event with status
      },

      'section::create_section_item' => function($item, $section_id){

         // Check if i own this section;
         $_item = new SectionItem;
         $_item->fill($item);
         $_item->section_id = $section_id;
         $_item->save();

         // Dispatch another event with status
         $this->dispatch('section::created_section', $_item);
      },

      // 'section::update_section_items' => function($items, $section_id){

      //    if(!is_array($items)) return;

      //    foreach ($items as $key => $value) {
      //       if(!$_item = SectionItem::where('uuid', __a($value, 'uuid'))) continue;
      //       $_item->fill($value);

      //       $_item->uuid = __a($value, 'uuid');
      //       $_item->save();
      //    }
      // },

      'builder::saveHeaderLinks' => function($links, $js){

         foreach ($links as $key => $value) {
            if(!$_item = SiteHeaderLink::where('uuid', __a($value, 'uuid'))->first()) continue;
            $_item->uuid = __a($value, 'uuid');
            $_item->fill($value);
            $_item->save();


            // Children

            if(is_array($children = __a($value, 'children'))){
               foreach ($children as $v) {
                  if(!$_i = SiteHeaderLink::where('uuid', __a($v, 'uuid'))->first()) continue;
                  $_i->uuid = __a($v, 'uuid');
                  $_i->fill($v);
                  $_i->save();
               }
            }
         }

         $this->js($js);
      },



      'builder::saveSection' => function ($section, $js){
         if(!$_section = $this->site->sections()->where('id', __a($section, 'id'))->first()) return;
         $_section->fill($section);

         $_section->save();

         $this->js($js);
      },

      'builder::save_sections_and_items' => function ($section, $js){
         if(!$_section = $this->site->sections()->where('id', __a($section, 'id'))->first()) return;
         $_section->fill($section);

         $_section->save();
         
         if(is_array($items = __a($section, 'items'))){
            foreach ($items as $key => $value) {
               if(!$_item = SectionItem::where('uuid', __a($value, 'uuid'))->first()) continue;
               $_item->fill($value);

               $_item->uuid = __a($value, 'uuid');
               $_item->save();
            }
         }

         $this->js($js);
      },

      // Create Section

      // Site
      'builder::saveSite' => function(){
         // Update database site with javascript site data.
         $this->site->fill($this->siteArray);
         $this->site->save();

         $this->js('$store.builder.savingState = 2');
      },

      // 'builder::saveHeaderLinks' => function($links, $js){

      //    dd($links);
      //    if(!$_page = $this->site->pages()->where('id', __a($page, 'id'))->first()) return;
      //    // Update database site with javascript site data.

      //    $_page->fill($page);
      //    $_page->save();

      //    $this->js($js);
      // },

      // Page
      'builder::savePage' => function($page, $js){
         if(!$_page = $this->site->pages()->where('id', __a($page, 'id'))->first()) return;
         // Update database site with javascript site data.

         $_page->fill($page);
         $_page->save();

         $this->js($js);
      },
   ]);

   updated([
      'site.name' => function(){

         dd('sdfsd');
         $this->site->save();
      }
   ]);

   // Methods
   $getSections = function(){
      $this->sections = $this->site->sections()->get()->map(function($item){
      $config = $item->getConfig();


      $item->get_media = $item->getMedia();
      $item->editComponent = ao($config, 'components.editComponent');
      //$page_id = "sectionComponent:$item->id";

      return $item;
    })->toArray();
   };

   $getPages = function(){
      $this->pages = $this->site->pages()->orderBy('id', 'asc')->get()->toArray();
   };

   $getHeaderLinks = function(){
      $this->headerLinks = $this->site->header_links()->where('parent_id', '=', null)->get()->toArray();
   };

   // $createSectionItem = function($data){

   //    $section_id = ao($data, 'section_id');
      
   //    $content = [
   //       'title' => __('Add title'),
   //       'text' => __('Add description'),
   //    ];

   //    $item = new SectionItem;
   //    $item->section_id = $section_id;
   //    $item->content = $content;
   //    $item->save();

   //    return $item;
   // // };

   // $deleteItem = function($item_id){

   //    if(!$_item = SectionItem::find(ao($item, 'id'))) return;

   //    $_item->delete();
   // };


   // We need to have methods for crud items;


   $__create_section = function(){

   };

   $__create_section_item = function(){

   };
?>
<div class="editor-panel" x-data="yenaBuilder" :class="{'maximize': renderView == 'max'}">

   <style>
      :root {
         --accent: #004b63;
         --shape: var(--r-full);
         --min-shape: var(--min-r-full);
         --site-width: 800px;
         --logo-height: 50px;
         --logo-height-mobile: 20px;
         --sublinks-shape: calc(var(--min-shape) / 2);
         --design-headFont: 'Arima Madurai Black';
         --design-headWeight: 100;
         --design-bodyFont: 'Arima Madurai regular';
      }
      /* .edit-board button:not(.accordion-header){
      background:var(--accent)!important;
      }
      .edit-board h1:not(.accordion-header):not(.block-card), .edit-board h2:not(.accordion-header):not(.block-card), .edit-board h3:not(.accordion-header):not(.block-card), .edit-board h4:not(.accordion-header):not(.block-card), .accordion-box .accordion-container h1,  .accordion-box .accordion-container .accordion  .accordion-header p,
      .edit-board h2:not(.published-overlayr), a.logo span, #preloader span, .billing-price .amount, .head-font {
            font-family:'Aboreto regular'!important;
            font-weight:400!important;
         }
         .ProseMirror h1, .ProseMirror h2, .ProseMirror h3, .accordion > .edit-board .accordion-item > button.accordion-header, .post-box>.text>.post-title, .mobile-nav-overlay .link__a .body-font {
            font-family:'Aboreto regular'!important;
            font-weight:400!important;
         } */
         /* .edit-board p:not(.accordion-header):not(.block-card):not(.ignore):not(.amount),.edit-board input,.edit-board input::placeholder, .ProseMirror p, .ProseMirror li::marker, .edit-board h3.t-1.small-size, .accordion-box .accordion-container .accordion  .accordion-body p {
            font-family:'Questrial regular'!important;
         }
         header>nav>ul>li>a, .header-nav>nav>ul>li>a, .edit-board button:not(.empty-post > button), .vzy-block *, textarea, .announcement-bar-block > a, .page-list, .navbar-box .sub-link{
            font-family:'Questrial regular'!important;
         } */
         /* .footer-card ul>li>a, .footer-card .footer-bottom>.footer-bottom-right>a, .card-label, .hero-label, .banner-label, .pricing-label, .card-header p, .display-options .display-style li, .pricing-benefits li, .price-title span {
            font-family:'Questrial regular'!important;
         }
      .card-box.accent .card-header > h2, .card-box.accent .border .card-text > h3, .card-box.accent .no-border .card-text > h3, .card-box.accent .border .card-text p, .card-box.accent .no-border .card-text p, .card-box.accent .card-header > p {
         color: var(--c-dark)!important;
      }
         .edit-board button, .pricing-box .pricing-container-small .pricing-section > .tier.popular-price > .pricing-details > a button {
            color:var(--c-dark)!important;
         }
      .edit-panel .theme-container svg path {
         stroke: var(--c-dark)!important
      }
      .edit-panel .custom-color .input-group .input-small,  .edit-panel .custom-color .input-group .hash{
         color: var(--c-dark)!important
      }
         a-nnouncement-bar{
            background: rgba(204,227,255,0.1)!important;
         }
         h1{
            letter-spacing:0em!important;
         }
         h2{
            letter-spacing:0em!important;
         }
         h3{
            letter-spacing:0em!important;
         }
      .logo-text {
         letter-spacing: 0em !important;
      }
         .tt{
            color:light
         } */
         /* @media screen and (min-width: 1200px) {
            .w-boxed{

      max-width:770px!important;
            }
         } */
	
   </style>
   

   <livewire:components.builder.layout.toolbar :$site lazy :key="uukey('builder', 'toolbar')" />
   
   <div class="container !max-w-[initial]">
      <div class="projects">
         <livewire:components.builder.layout.sidebar :$site lazy  :key="uukey('builder', 'sidebar')" />
         <div class="container-small !max-w-[initial] edit-board">
            <div class="edit-blocks">
               <div class="edit-blocks-container">
                  @persist('builder')
                     <div wire:ignore>
                        <livewire:components.builder.index :$site :$pages lazy :key="uukey('builder', 'index')" />
                     </div>
                  @endpersist
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="nav-bottom">
      <div class="nav-list">
         <ul>
            <li>
               <a @click="navigatePage('pages')">
                  <span>
                     {!! __i('interface-essential', 'item-pen-text-square') !!}
                  </span>
                  {{ __('pages') }}
               </a>
            </li>
            <li>
               <a @click="navigatePage('pages')">
                  <span>
                     {!! __i('interface-essential', 'item-pen-text-square') !!}
                  </span>
                  {{ __('Section') }}
               </a>
            </li>
            <li>
               <a>
                  <span>
                     {!! __icon('Design Tools', 'Bucket, Paint') !!}
                  </span>
                  {{ __('design') }} 
               </a>
            </li>
            <li>
               <a>
                  <span>
                     {!! __icon('Business, Products', 'blackboard-business-chart') !!}
                  </span>
                  {{ __('Analytics') }}
               </a>
            </li>
            <li>
               <a @click="navigatePage('media')">
                  <span>
                     {!! __i('Music, Audio', 'media-library-playlist-play') !!}
                  </span>
                  {{ __('Media') }}
               </a>
            </li>
            <li>
               <a>
                  <span>
                     {!! __i('interface-essential', 'setting4') !!}
                  </span>
                  {{ __('Settings') }}
               </a>
            </li>
         </ul>
      </div>
   </div>

   @teleport('body')
   <x-modal name="share-modal" :show="false" removeoverflow="true" maxWidth="2xl" focusable>

      <livewire:components.builder.parts.share :key="uukey('builder', 'share-modal')">
      
      <footer class="flex flex-row gap-2 px-6 py-4 justify-end">
         
         <button class="z-0 group relative inline-flex items-center justify-center box-border appearance-none select-none whitespace-nowrap font-normal subpixel-antialiased overflow-hidden tap-highlight-transparent outline-none data-[focus-visible=true]:z-10 data-[focus-visible=true]:outline-2 data-[focus-visible=true]:outline-focus data-[focus-visible=true]:outline-offset-2 px-unit-4 min-w-unit-20 h-unit-10 text-small gap-unit-2 rounded-medium [&amp;>svg]:max-w-[theme(spacing.unit-8)] data-[pressed=true]:scale-[0.97] transition-transform-colors motion-reduce:transition-none bg-default text-default-foreground" type="button" @click="$dispatch('close')">{{ __('Done') }}</button>
      </footer>
   </x-modal>
   @endteleport
   @script
        <script>
            Alpine.data('yenaBuilder', () => {
               return {
                  renderView: 'normal',
                  renderMobile: false,
                  sidebarClass: '',
                  // page: 'section::header',
                  page: 'pages',
                  __last_page: null,

                  site: @entangle('siteArray'),
                  pages: @entangle('pages'),
                  sections: @entangle('sections'),
                  siteheader:{
                     links: @entangle('headerLinks')
                  },
                  currentPage: null,


                  section: [],
                  getMedia(media){
                     if(!media) return;
                     var _url = "{{gs('media/site/images')}}";

                     return _url + '/' + media;
                  },
                  deleteItem(item_id){

                     this.$dispatch('section::deleteItem', {
                        item: item_id
                     });
                  },

                  editSection(_id){
                     var section = this.sections.filter(item => item.id == _id)[0];
                     this.section = section;
                     this.navigatePage('section::' + section.section);
                     // this.navigatePage('sectionComponent:' + _id);
                  },

                  navigatePage(page){
                     if(page == '__last_state') {
                        this.page = this.__last_page;
                        return;
                     }
                     this.__last_page = page;
                     this.page = page;
                  },

                  sidebarNavigate(sidebarClass, route){

                     this.sidebarClass = sidebarClass;

                     Livewire.navigate(route);
                  },



                  // Broadcast

                  broadcastSite(){
                     
                  },

                  getCurrentPage(){
                     this.currentPage = this.pages.filter(item => item.id == this.site.current_edit_page)[0];

                     if(!this.currentPage && this.pages.length > 0) this.currentPage = this.pages[0];
                  },

                  // Save
                  init(){
                     var $this = this;
                     this.$wire.$on('createSectionItem', function(content){
                        console.log(content);
                        // $this.$wire.createSectionItem(content).then(item => {
                        //    console.log(item)
                        // });
                     });
                     window.addEventListener('createSectionItem', (event) => {
                        //console.log(event.detail)
                     });
                     window.addEventListener('deleteSectionItem', (event) => {
                        console.log(event.detail)
                     });
                     window.addEventListener('builder::createdSection', (event) => {
                        $this.sections.push(event.detail[0]);
                     });

                     this.getCurrentPage();
                  }
               }
            });
        </script>
   @endscript
</div>

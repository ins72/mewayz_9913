
<?php

   use App\Models\Page;
   use function Livewire\Volt\{state, mount, placeholder};

   placeholder('
   <div class="p-5 w-full mt-1">
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
   </div>');


   state([
      'templates' => fn() => config('yena.pages')   
   ]);

   state(['site']);

   // Methods

   $createPage = function($template){
      // Create Page
      $template = $this->templates[$template];


      $name = "Untitled-" . ao($template, 'name');
      $slug = slugify(ao($template, 'name') . str()->random(3), '-');

      $header = [
         'style' => 1,
      ];

      $footer = [
         'style' => 1,
      ];

      $page = new Page;
      $page->site_id = $this->site->id;
      $page->name = ao($template, 'name');
      $page->slug = $slug;
      $page->default = 0;
      $page->published = 1;
      $page->save();

      $this->js('createPage=false');
      $this->js('pages.push('. $page .')');
      $this->dispatch('builder::pageCreated', $page);
   };
?>

<div>
  <div>
     <div class="design-navbar">
        <ul >
            <li class="close-header !flex">
              <a @click="createPage=false">
                <span>
                    {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                </span>
              </a>
           </li>
           <li class="!pl-0">{{ __('Add Page') }}</li>
           <li></li>
        </ul>
     </div>
     <div class="container-small">
      <div class="all-pages-style !mt-4">
         <ul>
            @foreach ($templates as $key => $item)
            <li wire:click="createPage('{{ $key }}')" {{ _k() }}>
               <div>
                  <div>
                     <img src="https://app.vzy.co/assets/Landing-light.2dfd8ae0.svg">
                  </div>
                  <div class="section-text">
                     <p>{{ ao($item, 'name') }}</p>
                     <p>{{ ao($item, 'description') }}</p>
                  </div>
               </div>
               <span>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path d="M9 18L15 12L9 6" stroke="var(--foreground)" stroke-miterlimit="10" stroke-linecap="square"></path>
                  </svg>
               </span>
            </li>
            @endforeach
         </ul>
      </div>
     </div>
  </div>
</div>
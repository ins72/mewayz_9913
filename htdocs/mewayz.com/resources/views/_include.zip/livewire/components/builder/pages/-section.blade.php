
<?php

use App\Models\SitesUpload;
use function Livewire\Volt\{state, mount, placeholder, updated, on};

state(['site']);
on([
   
]);

state([
   'sections' => fn () => collect(config('yena.sections')),
]);

updated([
   
]);

mount(fn() => '');

placeholder('
   <div class="w-full p-5 mt-1">
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
   </div>
');

// Methods

$createSection = function($key){
   if(!$config = ao($this->sections, $key)) return;
   
   // Do other stuff
   $class = ao($config, 'functions.create');
   $class = app()->make($class);

   $create = $class->setSite($this->site)->createSection();

   // dd($create);

   $this->dispatch('builder::createdSection', $create);
};
?>

<div class="website-section">

   <div>
      <div class="design-navbar">
         <ul >
            <li class="close-header !flex">
                <a @click="page='__last_state'">
                    <span>
                        {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                    </span>
                </a>
            </li>
            <li class="!pl-0">{{ __('Sections') }}</li>
            <li class="!flex !md:hidden">
                <a @click="navigatePage('-')" class="menu--icon !bg-black !text-[10px] !text-white !w-auto !px-2 !h-5 cursor-pointer">
                    {{ __('Close') }}
                </a>
            </li>
         </ul>
      </div>
      <div class="container-small">
         <div class="mt-2 all-pages-style">
            <ul>
               @foreach ($sections as $index => $item)
               <li wire:click="createSection('{{ $index }}')">
                  <div>
                     <div>
                        <img src="{{ gs(ao($item, 'icons.showBanner')) }}">
                     </div>
                     <div class="section-text">
                        <p>{{ ao($item, 'name') }}</p>
                        <p>{{ ao($item, 'description') }}</p>
                     </div>
                  </div>
                  <span>
                     {!! __icon('Arrows, Diagrams', 'Arrow.5', 'w-5 h-5') !!}
                  </span>
               </li>
               @endforeach
            </ul>
         </div>
      </div>
   </div>
</div>
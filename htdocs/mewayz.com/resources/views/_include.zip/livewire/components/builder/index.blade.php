
<?php

use function Livewire\Volt\{state, mount, on, placeholder};

state(['site'])->reactive();
state([
   'pages',
   'page',
   'sections' => [],
    'sectionConfig' => fn () => config("yena.sections"),
]);
mount(function(){
   $this->getSections();
});
on([
   'builder::createdSection' => function($section){
      $this->getSections();
   },
   'builder::setPage' => function(){
      $this->getSections();
   },
]);
// placeholder('
//    <div class="p-5 w-full mt-1">
//       <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
//       <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
//       <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
//    </div>');
// Methods
$getSections = function(){
    $this->sections = $this->site->getEditSections();

    // dd($this->sections);
};
?>

<div class="-mobile-plane builder--page" x-data="builder__index" :class="{'active': renderMobile}">

    <div :style="styles()">
        
        <div @click="navigatePage('section::header')">
            <livewire:sections.header.viewComponent lazy :$site :key="uukey('builder::section', 'header')" />
        </div>

        {{-- @foreach ($sections as $item)
            @php
                $config = $item->getConfig();
                $component = ao($config, 'components.viewComponent');
            @endphp
            
            
            <div >
                <div @click="editSection('{{ $item->id }}')">
                    <livewire:is :component="$component" lazy :section="$item" :key="uukey('builder::section', 'section-id' . $item->id)" />
                </div>


                <div class="flex items-center justify-center">
                    <a class="btn !w-7 !h-7 !rounded-full" @click="navigatePage('section')">
                        <i class="fi fi-rr-plus text-white text-[10px]"></i>
                    </a>
                </div>
            </div>
        @endforeach --}}

{{-- 
        <div wire:ignore>

            <div class="w-[100%]">
                <template x-for="(item, index) in getSections()" :key="item.id">
                    <div class="w-[100%]" @click="editSection(item.id)">
                        <div x-data="{section:item}" x-html="generateComponent(item.section)"></div>
                    </div>
                </template>
            </div>
        </div> --}}
    </div>
    
    <div>
        
    </div>
    <div wire:ignore>
        <template x-for="(item, index) in getSections()" :key="item.id">
            <div class="w-[100%]" @click="editSection(item.id)">
                <div x-bit="'section-' + item.section" x-data="{section:item}"></div>
            </div>
        </template>
    
    
        
        <template bit-component="person">
            <li>
              <h2 x-text="item.content.title"></h2>
          
              <p x-text="item.age"></p>
          
              <ul>
                
              </ul>
            </li>
          </template>

          @foreach($sectionConfig as $key => $item)
             @php
                if(!$_name = __a($item, 'components.alpineView')) continue;
                $_name = str_replace('/', '.', $_name);
      
                $component = "livewire::$_name";
             @endphp
             <template bit-component="section-{{ $key }}">
                <div wire:ignore>
                   <x-dynamic-component :component="$component"/>
                </div>
             </template>
          @endforeach
    </div>
    {{-- <template x-component="render">
        <div class="w-[100%]">
            <template x-for="(item, index) in getSections()" :key="item.id">
                <div class="w-[100%]" @click="editSection(item.id)">
                    <div x-data="{section:item}" x-shtml="$api && $api.generateComponent(item.section) || ''"></div>
                </div>
            </template>
        </div>

        <script>
            return {
                content: '',
                generateComponent(component){
                    component = `o-section-${component}`;
                    return `<${component}></${component}>`;
                },

                changeRouter(){
                    var component = 'o-greeting';


                    this.content = `<${component}></${component}>`;
                },
                onMounted(){

                    this.changeRouter();
                }
            }
        </script>
    </template> --}}

    {{-- @foreach($sectionConfig as $key => $item)
       @php
          if(!$_name = __a($item, 'components.alpineView')) continue;
          $_name = str_replace('/', '.', $_name);

          $component = "livewire::$_name";
       @endphp
       <template x-component.unwrap="section-{{ $key }}">
          <div wire:ignore>
             <x-dynamic-component :component="$component"/>
          </div>
       </template>
    @endforeach --}}
    
    {{-- <template x-for="(section, index) in getSections()" x-shtml="$api && $api.name || ''" :key="section.id">
        <div>
            <${'o-greeting'} x-data="{ section: section }">Vimesh UI</${'o-greeting'}>
        </div>
        <script>
            return {
                name: 'Jeff'
            }
        </script>
    </template> --}}

    {{-- <template x-component="greeting">

        <div class="flex items-center justify-center">

            ddd

            <span x-text="section.content.title"></name>
            <a class="btn !w-7 !h-7 !rounded-full" @click="navigatePage('section')">
                <i class="fi fi-rr-plus text-white text-[10px]"></i>
            </a>
        </div>
        <script>
            return {
                name: 'Jeff'
            }
        </script>
    </template> --}}
    {{-- <template x-for="(section, index) in getSections()" :key="section.id">
        <div>
            <o-component template="person" x-data="{ item: section }"></o-component>
        </div>
    </template> --}}

    {{-- <template id="person">
        <li>
          <h2 x-text="item.content.title"></h2>
      
          <p x-text="item.age"></p>
      
          <ul>
            
          </ul>
        </li>
      </template> --}}
    @script
        <script>
            Alpine.data('builder__index', () => {
               return {
                    pages: @entangle('pages'),

                    generateComponent(component){
                        component = `o-section-${component}`;
                        return `<${component}></${component}>`;
                    },
                    currentPage: function(){
                        var page = this.pages[0];

                        this.pages.forEach((e, index) => {
                            if(e.id == this.site.current_edit_page) page = e;
                        });

                        return page;
                    },

                    getSections: function(){
                        var sections = [];

                        this.sections.forEach((element, index) => {
                            if(this.currentPage().id == element.page_id){
                                sections.push(element);
                            }
                        });
                        return sections;
                    },

                    styles(){
                        var site = this.site;
                        return this.$store.builder.generateSiteDesign(site);
                    },

                    init(){
                        window.initComponents();
                        //console.log(this.getSections());
                        //console.log(this.sections, this.pages, this.site)
                    }
               }
            });
        </script>
    @endscript
</div>

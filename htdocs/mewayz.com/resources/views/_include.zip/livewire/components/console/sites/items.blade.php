
<?php

   use App\Models\Site;
   use App\Models\Page;
   use function Livewire\Volt\{state, mount, placeholder, on};

   on(['trashSite' => function ($id) {
      if(!$site = Site::where('id', $id)->first()) return false;

      // Check if the site belongs to the current user
      if($site->user_id !== iam()->id) return false;


      $site->delete();
      
      $this->dispatch('refreshSites');
      $this->dispatch('hideTippy');
   },
   
   'permanentlyTrashSite' => function($id) {
      if(!$site = Site::withTrashed()->where('id', $id)->first()) return false;

      // Check if the site belongs to the current user
      if($site->user_id !== iam()->id) return false;

      $site->forceDelete();

      $this->dispatch('refreshSites');
      $this->dispatch('hideTippy');
   },

   'restoreSite' => function($id){
      if(!$site = Site::withTrashed()->where('id', $id)->first()) return false;

      // Check if the site belongs to the current user
      if($site->user_id !== iam()->id) return false;
      
      $site->restore();

      $this->dispatch('refreshSites');
      $this->dispatch('hideTippy');
   }
   ]);

   mount(function(){
      
   });

   placeholder('<div class="--placeholder-skeleton w-[230px] h-[240px] rounded-[var(--yena-radii-sm)]"></div>');

   state([
      'item',
   ]);
?>

<div>
   
   <div class="yena-linkbox" x-data="{ tippy: {
      content: () => $refs.template.innerHTML,
      allowHTML: true,
      appendTo: document.body,
      maxWidth: 360,
      interactive: true,
      trigger: 'click',
      animation: 'scale',
   } }">
     <template x-ref="template">
         <div class="yena-menu-list !w-full">
            <div class="px-4">
               <p class="yena-text">{{ $item->name }}</p>
   
               <p class="text-[color:var(--yena-colors-gray-500)] truncate text-sm">Created September 18th, 2023</p>
               <p class="text-[color:var(--yena-colors-gray-500)] truncate text-sm">by Jeff Jola</p>
            </div>
   
            <hr class="--divider">
   
            <a href="" class="yena-menu-list-item">
               <div class="--icon">
                  {!! __icon('interface-essential', 'share-arrow.2', 'w-5 h-5') !!}
               </div>
               <span>{{ __('Share') }}</span>
            </a>
   
            <a href="" class="yena-menu-list-item">
               <div class="--icon">
                  {!! __icon('interface-essential', 'document-text-edit', 'w-5 h-5') !!}
               </div>
               <span>{{ __('Rename') }}</span>
            </a>
            <hr class="--divider">
            <a href="" class="yena-menu-list-item">
               <div class="--icon">
                  {!! __icon('interface-essential', 'star-favorite', 'w-5 h-5') !!}
               </div>
               <span>{{ __('Add to favorites') }}</span>
            </a>
            <a href="" class="yena-menu-list-item">
               <div class="--icon">
                  {!! __icon('interface-essential', 'copy-duplicate-object-add-plus', 'w-5 h-5') !!}
               </div>
               <span>{{ __('Duplicate') }}</span>
            </a>
            <a href="" class="yena-menu-list-item">
               <div class="--icon">
                  {!! __icon('interface-essential', 'share-arrow.1', 'w-5 h-5') !!}
               </div>
               <span>{{ __('Copy link') }}</span>
            </a>
            @if ($item->trashed())
            <hr class="--divider">
            <a class="yena-menu-list-item cursor-pointer" @click="$dispatch('restoreSite', {id: {{ $item->id }}})">
               <div class="--icon">
                  {!! __icon('interface-essential', 'backward-rearward-back.1', 'w-5 h-5') !!}
               </div>
               <span>{{ __('Restore') }}</span>
            </a>
            @endif
            <hr class="--divider">
            @if ($item->trashed())
            <a class="yena-menu-list-item !text-[color:red] cursor-pointer" @click="$dispatch('permanentlyTrashSite', {id: {{ $item->id }}})">
               <div class="--icon">
                  {!! __icon('interface-essential', 'delete-disabled.2', 'w-5 h-5') !!}
               </div>
               <span>{{ __('Permanently delete') }}</span>
            </a>
            @else
            <a class="yena-menu-list-item !text-[color:red] cursor-pointer" @click="$dispatch('trashSite', {id: {{ $item->id }}})">
               <div class="--icon">
                  {!! __icon('interface-essential', 'trash-bin-delete', 'w-5 h-5') !!}
               </div>
               <span>{{ __('Send to trash') }}</span>
            </a>
            @endif
        </div>
     </template>

      <div class="flex flex-col h-full">
         <a href="{{ route('console-builder-index', ['slug' => $item->_slug]) }}" @navigate>
            <div class="-thumbnail">
               <div class="--thumbnail-inner">
                  <img src="https://assets.api.gamma.app/nfbl5v2efboypzx/screenshots/kyojcdmm4p0b5ei/j9arp50i6s3o4ha/slide/YHYEnM5c9FJ8KW3E2SMApYSrzz8" alt="" class="hidden">
               </div>
            </div>
         </a>

         <div class="-content">
            <a href="{{ route('console-builder-index', ['slug' => $item->_slug]) }}" @navigate>
               <p class="--title">{{ $item->name }}</p>
            </a>

            <div class="flex flex-col w-full">
               <div class="flex justify-between mt-5 w-full items-start">
                  <div class="flex items-center">
                     <div class="relative">
                        <div class="--avatar">
                           <img src="https://lh3.googleusercontent.com/a/ACg8ocIfj-FCgS0C0oMhZ-7IBAimDbMwSyK8FomVZ9d0_6f8yyLO=s96-c" alt="">
                        </div>
                     </div>
                     <div class="mx-2 w-full">
                        <p class="meta-text truncate w-full break-all text-xs">Created by you</p>
                        <p class="meta-text truncate w-full break-all text-[11px] text-[color:var(--yena-colors-gray-400)]">Last viewed 19 days ago</p>
                     </div>
                  </div>

                  <div class="relative">

             
                     <button class="yena-button h-6 w-6 rounded-full transition-all hover:text-[color:#3c3838] hover:bg-[var(--yena-colors-gray-200)] flex items-center justify-center" x-tooltip="{...tippy}">
                        {!! __icon('interface-essential', 'dots-menu', 'w-5 h-5') !!}
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
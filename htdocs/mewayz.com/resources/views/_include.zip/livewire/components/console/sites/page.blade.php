
<?php

   use App\Models\Site;
   use App\Models\Page;
   use App\Models\Folder;
   use App\Models\FolderSite;
   use function Livewire\Volt\{state, mount, placeholder, on};

   mount(function(){
      $this->getSites();


      // Check folder

      if($this->isFolder){
         //

         if(!$this->folder->isMember(iam()->id)){
            $this->sites = [];
            $route = route('console-index');
            $this->js(
               '
                  window.runToast("success", "'. __('You dont belong in this folder') .'")
                  setTimeout(function() {
                        Livewire.navigate("'.$route.'");
                  }, 2000);
               '
            );
         }
      }
   });

   placeholder('placeholders.console.sites.page-placeholder');

   state([
      'sites' => [],
      'folder' => [],
      'slug',
      'isFolder',
   ]);

   on(['refreshSites' => function(){
      $this->getSites();
   }]);
   
   $getSites = function() {
      if(!$this->isFolder){
         $this->sites = iam()->getSites();
         return;
      }

      if(!$this->folder = Folder::where('slug', $this->slug)->first()) return;


      foreach ($this->folder->folderSites as $item) {
         $site = $item->site;
         if(!$site) continue;
         if($site->trashed()) continue;

         $this->sites[] = $site;
      }
   };

   $createBlank = function(){
      // Check if plan allows it.

      if($this->isFolder){
         if(!$this->folder->isMember(iam()->id)) return;
      }

      // Create a blank site

      $randomSlug = str()->random(15);
      $addressSlug = str()->random(7);

      $_slug = "Untitled-$randomSlug";
      $name = "Untitled-$addressSlug";
      $address = "untitled-$addressSlug";

      $header = [
         'style' => 1,
      ];

      $footer = [
         'style' => 1,
      ];
      $new = new Site;
      $new->address = $address;
      $new->_slug = $_slug;
      $new->name = $name;
      $new->user_id = iam()->id;
      $new->created_by = iam()->id;
      $new->settings = [];
      $new->header = $header;
      $new->footer = $footer;
      $new->save();

      // Create a default page;

      $page = new Page;
      $page->site_id = $new->id;
      $page->name = 'Home';
      $page->slug = 'home';
      $page->default = 1;
      $page->published = 1;
      $page->save();


      $new->current_edit_page = $page->id;
      $new->save();

      // Check if has folder
      if($this->isFolder){
         $folderSite = new FolderSite;
         $folderSite->folder_id = $this->folder->id;
         $folderSite->site_id = $new->id;
         $folderSite->save();
      }

      $route = route('console-builder-index', ['slug' => $_slug]);

      $this->js(
          '
              window.runToast("success", "'. __('Site created successfully') .'")
              setTimeout(function() {
                  Livewire.navigate("'.$route.'");
              }, 2000);
          '
      );

      $this->getSites();

      return true;

      return $this->redirect($route, navigate: true);
   };
?>

<div>
   
   <div class="mb-6 ">
      <div class="flex flex-col mb-4">
         
         <div class="flex items-center h-6">
            <h2 class="text-lg font-semibold ">
               @if ($isFolder)
                  {!! __icon('Folders', 'folder-open', 'w-6 h-6 inline-block') !!}

                  @else
                  {!! __icon('interface-essential', 'browser-internet-web-network-window-app-icon', 'w-6 h-6 inline-block') !!}
               @endif

               <span class="ml-2">{{ $isFolder ? $folder->name : __('All Sites') }}</span>
            </h2>
         </div>
         <div class="flex flex-col gap-4 mt-4 lg:flex-row">
            
            <a href="" class="yena-button-stack --black">
               <div class="--icon">
                  {!! __icon('interface-essential', 'plus-add.3', 'w-6 h-6') !!}
               </div>

               {{ __('Create new') }}

               <div class="inline-flex self-center ml-2 shrink-0">
                  <div class="--badge">{{ __('AI') }}</div>
               </div>
            </a>
            
            <a wire:click="createBlank" class="cursor-pointer yena-button-stack">
               <div class="--icon">
                  {!! __icon('interface-essential', 'plus-add.3', 'w-6 h-6') !!}
               </div>

               {{ __('New from blank') }}
            </a>
         </div>
      </div>

      <div class="flex items-center">
         <div class="overflow-hidden">
            <ul class="yena-wrap-list">
               <li class="yena-wrap-list-item">
                  <a href="" class="yena-button-o">
                     <span class="--icon">
                        {!! __icon('interface-essential', 'media-library-folder.1', 'w-5 h-5') !!}
                     </span>
                     {{ __('All') }}
                  </a>
               </li>
               <li class="yena-wrap-list-item">
                  <a href="" class="yena-button-o -active">
                     <span class="--icon">
                        {!! __icon('interface-essential', 'alarm-clock-time-timer', 'w-5 h-5') !!}
                     </span>
   
                     {{ __('Recently viewed') }}
                  </a>
               </li>
               <li class="yena-wrap-list-item">
                  <a href="" class="yena-button-o">
                     <span class="--icon">
                        {!! __icon('interface-essential', 'user-circle', 'w-5 h-5') !!}
                     </span>
   
                     {{ __('Create by you') }}
                  </a>
               </li>
               <li class="yena-wrap-list-item">
                  <a href="" class="yena-button-o">
                     <span class="--icon">
                        {!! __icon('interface-essential', 'star-favorite', 'w-5 h-5') !!}
                     </span>
   
                     {{ __('Favorites') }}
                  </a>
               </li>
            </ul>
         </div>
      </div>
   </div>


   <div class="">
      <div class="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
         @foreach ($sites as $item)
            <livewire:components.console.sites.items :$item lazy :key="uukey()"/>
         @endforeach
      </div>
   </div>
</div>
<?php
    use App\Livewire\Actions\BroadcastBuilder;
    use Livewire\Volt\Component;
    use Livewire\Attributes\On;
 
    new Class extends Component {
        use BroadcastBuilder;

        public $section, $site;
        public $bannerstyles = [];

        public $rules = [
            'section.content.label' => '',
            'section.content.title' => '',
            'section.content.subtitle' => '',
            'section.settings.actiontype' => '',
            'section.settings.banner_style' => '',
            'section.settings.title' => '',
            'section.settings.height' => '',
            'section.settings.width' => '',

            'section.settings.shape' => '',
            'section.settings.shape_avatar' => '',
            'section.settings.image_type' => '',
            'section.settings.color' => '',
            'section.settings.align' => '',
            
            'section.settings.enable_image' => '',
            'section.settings.split_title' => '',
            'section.settings.enable_attr' => '',

            'section.form.first_name' => '',
            'section.form.first_name_enable' => '',
            
            'section.form.last_name' => '',
            'section.form.last_name_enable' => '',
            
            'section.form.email' => '',
            'section.form.email_enable' => '',
            
            'section.form.phone' => '',
            'section.form.phone_enable' => '',
            
            'section.form.message' => '',
            'section.form.message_enable' => '',
            
            'section.form.button_name' => '',
            'section.form.success_message' => '',
        ];
    
        #[On('sectionMediaEvent:{section.id}')]
        public function updateImage($public, $image){
            $this->section->image = $image;
            $this->section->save();
        }
        
        #[On('---updated-banner-settings.{section.id}')]
        public function updateBannerSettings($settings){
            $this->section->settings = $settings;
        }

        public function saveSection(){
            $this->section->save();

            $this->dispatch('section::saved', $this->section->id);
        }

        #[On('saveSection::{section.id}')]
        public function _saveSectionEvent($js){
            $this->section->save();

            $this->js($js);
            $this->dispatch('section::saved', $this->section->id);
        }
    
        public function updated($property){
            //$this->section->save();

            if(str()->startsWith($property, 'section.content')){
                //$this->broadcastSectionContent();
            }

            if(str()->startsWith($property, 'section.settings')){
                //$this->broadcastSectionSettings();
            }
        }

        public function mount(){
            $this->bannerstyles = config('yena.banners');
        }
    }

?>


<div x-data="builder__sectionBanner">
  <div x-show="__page == 'form'">
      <div>
         <livewire:components.builder.parts.form :$section lazy sectionBack="__page = '-'" :key="uukey()">
      </div>
  </div>

  <div x-show="__page == 'button'">
      <div>
         <livewire:components.builder.parts.button :$section lazy sectionBack="__page = '-'" :key="uukey()">
      </div>
  </div>

  <div x-show="__page == 'section'">
      <div>
         <livewire:components.builder.parts.section :$section lazy sectionBack="__page = '-'" :key="uukey()">
      </div>
  </div>

  <div x-cloak x-show="__page == '-'">
    <div class="banner-section !block">
        <div>
    
            <div class="banner-navbar">
                <ul >
                    <li class="close-header !flex">
                    <a @click="navigatePage('pages')">
                        <span>
                            {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                        </span>
                    </a>
                </li>
                <li class="!pl-0">{{ __('Banner') }}</li>
                <li></li>
                </ul>
            </div>
            <div class="container-small sticky">
                <div class="tab-link">
                    <ul class="tabs">
                    <li class="tab !w-full" @click="__tab = 'content'" :class="{'active': __tab == 'content'}">{{ __('Content') }}</li>
                    <li class="tab !w-full" @click="__tab = 'style'" :class="{'active': __tab == 'style'}">{{ __('Style') }}</li>
                    </ul>
                </div>
            </div>
            <div class="container-small tab-content-box">
                <div class="tab-content">
                    <div x-cloak x-show="__tab == 'content'" data-tab-content>
                        <x-livewire::sections.banner.partial.edit.content :$section/>
                    </div>
                    <div x-cloak x-show="__tab == 'style'" data-tab-content>
                        <x-livewire::sections.banner.partial.edit.style :$section :$bannerstyles/>
                    </div>
                </div>
            </div>
        </div>
      </div>
  </div>

  @script
  <script>
      Alpine.data('builder__sectionBanner', () => {
         return {
            section: @entangle('section'),
            autoSaveTimer: null,
            __tab: 'content',
            __page: '-',
          
            init(){
               var $this = this;
               var $eventID = 'section::{{ $section->id }}';
               var $saveSection = 'saveSection::{{ $section->id }}';

               //console.log(this.section)

               this.$watch('section' , (value, _v) => {
                  $this.$dispatch($eventID, $this.section);
                  
                  clearTimeout($this.autoSaveTimer);

                  $this.autoSaveTimer = setTimeout(function(){
                      $this.$store.builder.savingState = 0;

                        $this.$wire.saveSection().then(function(){
                            $this.$store.builder.savingState = 2;
                        });
                      /*$this.$dispatch($saveSection, {
                        js: 'this.$store.builder.savingState = 2',
                      });*/
                  }, $this.$store.builder.autoSaveDelay);
               });
            }
         }
      });
  </script>
  @endscript
</div>
<div class="yena-topbar">
    <header>
       <div class="logo">
            <div class="--placeholder-skeleton w-[32px] h-[32px] rounded-lg"></div>
       </div>
       <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
       <div class="profile">
          <div class="profile-picture-holder">
            <div class="--placeholder-skeleton w-[32px] h-[32px] rounded-full"></div>
          </div>
       </div>
    </header>
 </div>
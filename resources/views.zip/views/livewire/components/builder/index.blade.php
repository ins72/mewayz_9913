
<?php

use function Livewire\Volt\{state, mount, on, placeholder};

state(['site']);
state([
   'pages',
   'page',
   'sections' => [],
    'sectionConfig' => fn () => config("yena.sections"),
]);
mount(function(){
   $this->getSections();
});
on([
//    'builder::createdSection' => function($section){
//       $this->getSections();
//    },
//    'builder::setPage' => function(){
//       $this->getSections();
//    },
]);
// placeholder('
//    <div class="p-5 w-full mt-1">
//       <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
//       <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
//       <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
//    </div>');
// Methods
$getSections = function(){
    $this->sections = $this->site->getEditSections();

    // dd($this->sections);
};
?>

<div class="-mobile-plane builder--page" :class="{'active': renderMobile}">

    <div x-data="builder__index">
        <div :style="styles()" wire:ignore>
            {{-- <div class="page-subpanel-section" wire:ignore>
                <div class="page-type-options">
                    <div class="page-type-item">
                       <div class="container-small edit-board overflow-y-scroll transform scale-[0.29225] origin-[0px_0px]">
                          <div class="card">
                             <div class="card-body">
                                <template x-for="(section, index) in lolS" :key="section.uuid">
                                    <div x-bit="'section-' + section.section" x-data="{section:section}"></div>
                                </template>
                                 
                             </div>
                          </div>
                       </div>
                    </div>
                    <div>
                     <button class="btn">Add Page</button>
                     <button class="btn">Generate with AI</button>
                    </div>
                 </div>
             </div> --}}

        
            <div @click="navigatePage('section::header')">
                <x-livewire::sections.header.viewComponent />
                {{-- <livewire:sections.header.viewComponent lazy :$site :key="uukey('builder::section', 'header')" /> --}}
            </div>

            <div wire:ignore>
                <div class="sortable-arrows">
                    <template x-for="(item, index) in getSections()" :key="item.uuid">
                        <div class="w-[100%] section-width-fill box section-bg-wrapper focus sortable-arrows-item" :data-id="item.uuid" @click="editSection(item.id)" :class="{
                            'section-width-fill': item.section_settings.width == 'fill',
                            'lr-padding': item.section_settings.width == 'fit',
                            }">
                            <div class="block-options" x-data="{showOptions: false}" @click="$event.stopPropagation()">
                                <div class="top-right-block-options shadow-lg !border-0zz">
                                   <div class="options active">
                                      <div id="move-up" class="block-menu" :class="{
                                        '!hidden': index == 0,
                                      }" @click="sortUp">
                                         {!! __i('Arrows, Diagrams', 'Arrow.15') !!}
                                      </div>
                                      <div id="move-down" class="block-menu" :class="{
                                        '!hidden': index == getSections().length -1,
                                      }" @click="sortDown">
                                        {!! __i('Arrows, Diagrams', 'Arrow, Download, Save, Upload') !!}
                                      </div>
                                      <div id="control" class="block-menu" @click="showOptions=!showOptions">
                                        {!! __i('--ie', 'dots-menu') !!}
                                      </div>
                                   </div>
                                </div>
                                <template x-if="showOptions">
                                    <div class="all-more-block-options">
                                        <div class="more-block-options !bg-blackz !text-whitez">
                                           <ul>
                                              <li @click="editSection(item.id);showOptions=false;">{{ __('Edit') }}</li>
                                              {{-- <li>{{ __('Duplicate') }}</li> --}}
                                              <li class="more-block-options-delete" @click="deleteSectionId=item;showOptions=false;">{{ __('Delete') }}</li>
                                           </ul>
                                        </div>
                                     </div>
                                </template>
                             </div>
                             
                            <div x-bit="'section-' + item.section" x-data="{section:item}"></div>
                        </div>
                    </template>
                </div>
    
                @foreach($sectionConfig as $key => $item)
                    @php
                        if(!$_name = __a($item, 'components.alpineView')) continue;
                        $_name = str_replace('/', '.', $_name);
            
                        $component = "livewire::$_name";
                    @endphp
                    <template bit-component="section-{{ $key }}">
                        <div wire:ignore>
                        <x-dynamic-component :component="$component"/>
                        </div>
                    </template>
                @endforeach
            </div>
            
        
            <div @click="navigatePage('section::footer')">
                <x-livewire::sections.footer.viewComponent />
            </div>
        </div>

        <template x-teleport="body">
            <div class="overlay backdrop delete-overlay" :class="{
                '!block': deleteSectionId
            }" @click="deleteSectionId=false">
                <div class="delete-site-card" @click="$event.stopPropagation()">
                   <div class="overlay-card-body">
                      <h2>{{ __('Delete Section?') }}</h2>
                      <p class="mt-4 mb-4 text-[var(--t-m)] text-center leading-[var(--l-body)] text-[var(--c-mix-3)] w-3/5 ml-auto mr-auto">{{ __('Are you sure you want to delete this section? Once deleted, you will not be able to restore it.') }}</p>
                      <div class="card-button pl-[var(--s-2)] pr-[var(--s-2)] pt-[0] pb-[var(--s-2)] flex gap-2">
                         <button class="btn btn-medium neutral !h-[calc(var(--unit)*_4)]" type="button" @click="deleteSectionId=false">{{ __('Cancel') }}</button>
        
                         <button class="btn btn-medium !bg-[var(--c-red)] !text-[var(--c-light)] !h-[calc(var(--unit)*_4)]" @click="deleteSection(deleteSectionId)">{{ __('Yes, Delete') }}</button>
                      </div>
                   </div>
                </div>
             </div>
        </template>
    </div>
    @script
        <script>
            Alpine.data('builder__index', () => {
               return {
                    pages: @entangle('pages'),
                    deleteSectionId: false,

                    contacts: {!! collect(config('sections.contact'))->toJson() !!},

                    generateComponent(component){
                        component = `o-section-${component}`;
                        return `<${component}></${component}>`;
                    },

                    currentPage: function(){
                        var page = this.pages[0];

                        this.pages.forEach((e, index) => {
                            if(e.uuid == this.site.current_edit_page) page = e;
                        });

                        return page;
                    },

                    getSections: function(){
                        var sections = [];

                        this.sections.forEach((element, index) => {
                            if(this.currentPage().uuid == element.page_id){
                                sections.push(element);
                            }
                        });

                        return window._.sortBy(sections, 'position');
                    },

                    styles(){
                        var site = this.site;
                        return this.$store.builder.generateSiteDesign(site);
                    },
                    deleteSection(item){

                        this.sections.forEach((e, index) => {
                            if(item.uuid == e.uuid){
                                this.sections.splice(index, 1);
                            }
                        });

                        this.$dispatch('section::delete', {
                            id: item.uuid
                        });
                        this.deleteSectionId=false;
                    },

                    sortReset(){
                        let $this = this;
                        document.querySelectorAll('.sortable-arrows').forEach(element => {
                           element.querySelectorAll('.sortable-arrows-item').forEach((e, index) => {
                              e.setAttribute('data-sort', index);
                           });
                        });
                    },

                    sortUpdated(){
                        let $this = this;
                        let $elements = document.querySelectorAll('.sortable-arrows .sortable-arrows-item');
                        let $array = $this.getSections();
                        let event = new CustomEvent("builder::sort_sections", {
                            detail: {
                                sections: $array,
                            }
                        });

                        window.dispatchEvent(event);
                        return;

                        // let data = [];
                        // $elements.forEach((e, index) => {
                        //    let items = {
                        //         uuid: e.getAttribute('data-id'),
                        //         position: index
                        //    };
                        //     $array.forEach((x, _i) => {
                        //         if(x.uuid == e.getAttribute('data-id')) x.position = index;
                        //     });
                            
                        //     // $this.sections.forEach((element, index) => {
                        //     //     if($this.currentPage().id == element.page_id && e.getAttribute('data-id') == element.uuid){
                        //     //         element.position = e.position;
                        //     //     }
                        //     // });
                        //    data.push(items);
                        // });

                        // let event = new CustomEvent("builder::sort_sections", {
                        //     detail: {
                        //         sections: data,
                        //     }
                        // });

                        // window.dispatchEvent(event);
                        // $template._x_prevKeys = keys;

                        // $this.sections.forEach((element, index) => {
                        //     if($this.currentPage().id == element.page_id){
                        //         data.forEach(e => {
                        //             if(e.uuid == element.uuid){
                        //                 element.position = e.position;
                        //             }
                        //         });
                        //     }
                        // });
                        // data.forEach(e => {
                        //     $this.sections.forEach((element, index) => {
                        //         if($this.currentPage().id == element.page_id && e.uuid == element.uuid){
                        //             element.position = e.position;
                        //         }
                        //     });
                        // });
                        // console.log($this.getSections())
                        // __.$wire.__sort_layout(data);
                    },

                    sortUp(){
                        let $this = this;
                        $this.sortReset();

                        let $wrapper = document.querySelector('.sortable-arrows');
                        let $elements = $wrapper.querySelectorAll('.sortable-arrows-item');
                        let $item = $this.$event.target.parentNode.closest('.sortable-arrows-item');
                        let $array = $this.getSections();
                        let steps = Alpine.raw($array);

                        let prev = $item.previousElementSibling;
                        if(prev == null) return;
                        
                        let oldSort = $item.getAttribute('data-sort');
                        let newSort = oldSort - 1;

                        let moved_step = steps.splice(oldSort, 1)[0]
                        steps.splice(newSort, 0, moved_step);

                        let keys = []
                        steps.forEach((step, i) => {
                            keys.push(step.uuid);

                            $array.forEach((x, _i) => {
                                if(x.uuid == step.uuid) x.position = i;
                            });
                        });
                        $this.sortUpdated();
                    },

                    sortDown(){
                        let $this = this;
                        $this.sortReset();

                        let $wrapper = document.querySelector('.sortable-arrows');
                        let $elements = $wrapper.querySelectorAll('.sortable-arrows-item');
                        let $item = $this.$event.target.parentNode.closest('.sortable-arrows-item');
                        let $array = $this.getSections();
                        let steps = Alpine.raw($array);

                        let oldSort = $item.getAttribute('data-sort');
                        let newSort = oldSort + 1;

                        let next = $item.nextElementSibling;
                        if(next == null) return;

                        let moved_step = steps.splice(oldSort, 1)[0]
                        steps.splice(newSort, 0, moved_step);

                        let keys = []
                        steps.forEach((step, i) => {
                            keys.push(step.uuid);

                            $array.forEach((x, _i) => {
                                if(x.uuid == step.uuid) x.position = i;
                            });
                        });
                        $this.sortUpdated();

                        // console.log(moved_step, steps);


                        // $elements.forEach((e, index) => {

                        //     let items = {
                        //             uuid: e.getAttribute('data-id'),
                        //             position: index
                        //     };
                        //     $array.forEach((x, _i) => {
                        //         if(x.uuid == e.getAttribute('data-id')) x.position = index;
                        //     });
                            
                        //    data.push(items);
                        // });
                        return;
                        $this.sections.forEach((element, index) => {
                            if($this.currentPage().id == element.page_id){
                                element.position = index;
                            }
                        });

                        $this.sections.forEach((element, index) => {
                            if($this.currentPage().id == element.page_id){
                                if($item.getAttribute('data-id') == element.uuid){
                                    element.position = element.position + 1;
                                }
                            }
                        });
                        // $this.sortUpdated();

                        console.log($this.getSections());
                        
                        // let next = $item.nextElementSibling;
                        // if(next == null) return;
                        // $wrapper.insertBefore(next, $item);

                        // $this.sortUpdated();
                    },

                    init(){
                        let __ = this;

                        // this.contacts.forEach((x) => {
                        //     __.lolS = __.$store.builder.generatePageSections(x.sections);
                        // });

                        // window.initComponents();
                        //console.log(this.getSections());
                        //console.log(this.sections, this.pages, this.site)
                    }
               }
            });
        </script>
    @endscript
</div>

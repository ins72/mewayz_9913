
<?php

   use App\Models\Page;
   use function Livewire\Volt\{state, mount, placeholder};

   placeholder('
   <div class="p-5 w-full mt-1">
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
   </div>');


   state([
      'templates' => fn() => config('yena.pages')   
   ]);

   state(['site']);

   // Methods

   $createPage = function($template){
      // Create Page
      $template = $this->templates[$template];

      $name = "Untitled-" . ao($template, 'name');
      $slug = slugify(ao($template, 'name') . str()->random(3), '-');

      $header = [
         'style' => 1,
      ];

      $footer = [
         'style' => 1,
      ];

      $page = new Page;
      $page->site_id = $this->site->id;
      $page->name = ao($template, 'name');
      $page->slug = $slug;
      $page->default = 0;
      $page->published = 1;
      $page->save();

      $this->js('createPage=false');
      $this->js('pages.push('. $page .')');
      $this->dispatch('builder::pageCreated', $page);
   };
?>

<div>
  <div x-data="builder__new_page">

      <template x-for="(item, index) in templates" :key="index">
         <div x-show="_page==index">
            <div class="design-navbar">
               <ul >
                   <li class="close-header !flex">
                     <a @click="_page='-'">
                       <span>
                           {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                       </span>
                     </a>
                  </li>
                  <li class="!pl-0" x-text="item.name"></li>
                  <li></li>
               </ul>
            </div>
                     
            <div class="container-small w-[100%] py-0 px-[var(--s-2)] mt-[var(--s-2)]">
               <div :style="styles()">
                  <div class="page-subpanel-section" x-ref="scale__section">
                     <template x-for="(item, index) in generateSectionTemplate(index)" :key="index">
                        <div class="page-type-options">
                           <div class="page-type-item">
                              <div class="container-small edit-board overflow-y-scroll !origin-[0px_0px]">
                                 <div class="card">
                                    <div class="card-body" wire:ignore>
                                       <div>
                                           <x-livewire::sections.header.viewComponent />
                                       </div>
                                       <template x-for="(_section, index) in getSections(item)" :key="index">
                                          <div class="card-body-inner">
                                             <div x-bit="'section-' + _section.section" x-data="{section:_section}"></div>
                                          </div>
                                       </template>
                                       <div>
                                           <x-livewire::sections.footer.viewComponent />
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div>
                              <button class="btn" @click="generatePage(item)">{{ __('Add Page') }}</button>
                              <button class="btn"></button>
                           </div>
                        </div>
                     </template>
                  </div>
               </div>
            </div>
         </div>
      </template>
   
      <div x-show="_page=='-'">
         <div class="design-navbar">
            <ul >
                <li class="close-header !flex">
                  <a @click="createPage=false">
                    <span>
                        {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                    </span>
                  </a>
               </li>
               <li class="!pl-0">{{ __('Add Page') }}</li>
               <li></li>
            </ul>
         </div>
         <div class="container-small">
          <div class="all-pages-style !mt-4">
             <ul>
                <template x-for="(item, index) in templates" :key="index">
                   <li @click="openPage(index)">
                      <div>
                         <div>
                            <img src="https://app.vzy.co/assets/Landing-light.2dfd8ae0.svg">
                         </div>
                         <div class="section-text">
                            <p x-text="item.name"></p>
                            <p x-text="item.description"></p>
                         </div>
                      </div>
                      <span>
                         {!! __i('Arrows, Diagrams', 'Arrow.5') !!}
                      </span>
                   </li>
                </template>
             </ul>
          </div>
         </div>
      </div>
  </div>
  @script
      <script>
          Alpine.data('builder__new_page', () => {
             return {
                  templates: @entangle('templates'),

                  sectionsTemplate: {
                     contact: {!! collect(config('sections.contact'))->toJson() !!},
                  },
                  _page: '-',
                  getSections(item){
                     return this.$store.builder.generatePageSections(item.sections);
                  },

                  generateSectionTemplate(item){
                     let $template = this.templates[item];
                     let $data = this.sectionsTemplate[item];

                     return $data;
                  },
                  styles(){
                      var site = this.site;
                      return this.$store.builder.generateSiteDesign(site);
                  },

                  openPage(page){
                     this.resizeDiv();
                     // this.getSections = function(){
                     //    return this.$store.builder.generatePageSections(this.generateSectionTemplate(page).sections);
                     // };

                     this._page = page;
                  },

                  closePage(){
                     this._page = '-';
                  },

                  getDeviceWidth() {
                     let $this = this;
                     var he = $this.$refs.scale__section;
                     de = he == null ? void 0 : he.querySelector(".page-type-item");
                     let me = de == null ? void 0 : de.clientWidth;

                     let scale = me / window.innerWidth;

                     return scale;
                  },
                  updateAllScale(scale){
                     var he = this.$refs.scale__section;
                     he.querySelectorAll('.edit-board').forEach((el) => {
                        el.style.transform = 'scale(' + scale + ')';
                     })
                  },
                  resizeDiv(){
                     let $this = this;
                     var he = $this.$refs.scale__section;
                     
                     setTimeout(() => {
                        $this.updateAllScale(this.getDeviceWidth());
                     }, 500);
                     
                     window.addEventListener('resize', function(){
                        let scale = $this.getDeviceWidth();
                        $this.updateAllScale(scale);
                     });
                  },

                  init(){
                     let __ = this;
                  }
             }
          });
      </script>
  @endscript
</div>

<div class="website-section">
    <div class="design-navbar">
        <ul >
            <li class="close-header !flex">
              <a @click="__page='-'">
                <span>
                    {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                </span>
              </a>
           </li>
           <li class="!pl-0">{{ __('Seo') }}</li>
           <li></li>
        </ul>
     </div>
     <div class="container-small p-[var(--s-2)] pb-[150px]" x-data="builder__seo">
      <div>
         <div>
           <div>
             <div class="input-box">
                <div class="input-group">
                 <input type="text" class="input-small" x-model="site.seo.title" name="description" placeholder="{{ __('Seo title') }}">
               </div>
             </div>
             
             <div class="mb-[calc(var(--s-1)_-_3px)]">
               <x-builder.textarea class="w-[100%] h-[100px] border-[1px] border-solid border-[var(--c-mix-1)] rounded-[var(--r-small)] bg-[unset] p-[var(--s-1)] resize-none text-[var(--t-m)] text-[var(--foreground)] focus:bg-[var(--c-mix-1)] focus:outline-none focus:border-[var(--c-mix-1)]" x-model="site.seo.description" placeholder="{{ __('Seo description') }}"></x-builder.textarea>
             </div>

             <div class="input-box">
                <div class="input-group">
                  
                   <div class="switchWrapper flex justify-between items-center font-bold">
                      {{-- <input id="search-result-page" type="checkbox" class="switchInput" x-model="site.seo.block"> --}}
                      <label for="search-result-page" class="switchLabel">{{__('Hide from search results')}}</label>
                      <label class="toggle">
                            <input class="toggle__input" name="enable_instant" value="1" type="checkbox" x-model="site.seo.block">
                         
                         <span class="toggle__inner"></span>
                      </label>
                   </div>
                </div>
             </div>
             <div class="bg-[var(--c-mix-1)] p-[var(--s-1)] rounded-[var(--r-small)] mb-[var(--s-1)]">
                <div class="flex items-center w-[100%] border-[1px] border-solid border-[var(--c-mix-1)] rounded-[var(--r-small)] mb-[var(--s-1)]">
                   <div class="flex-[100%] flex relative">
                      <button class="h-[165px] bg-[var(--background)] border-[1px] border-solid border-[var(--c-mix-1)] p-0 flex transition-none hover:cursor-pointer hover:opacity-[.7] relative font-[var(--f-base)] text-[var(--t-m)] text-[var(--background)] rounded-[var(--r-small)] text-center leading-[var(--l-title)] opacity-100 w-[100%]" @click="openMedia({
                        event: 'seoLogoImage',
                        sectionBack:'navigatePage(\'__last_state\')'
                  });">
                         <label class="h-full flex object-cover rounded-tl-[3px] rounded-br-[0] rounded-tr-[0] rounded-bl-[3px] cursor-pointer items-center justify-center w-[100%] border-[0] rounded-[3px] overflow-hidden">
                           <template x-if="site.seo.image">
                              <img class="w-[100%] h-full object-cover" :src="$store.builder.getMedia(site.seo.image)" alt=" ">
                           </template>
                           <template x-if="!site.seo.image">
                              <div class="w-[100%] h-full flex justify-center items-center">
                                 {!! __i('--ie', 'image-picture', 'text-gray-300 w-7 h-7') !!}
                              </div>
                           </template>
 
                         </label>
                         <template x-if="site.seo.image">
                           <span class="!zzhidden h-[40px] w-[40px] border-l-[0] absolute right-[0] top-0 rounded-tl-[0] rounded-br-[0] rounded-tr-[0] rounded-bl-[4px] bg-gray-100 flex-grow flex items-center justify-center" @click="$event.stopPropagation(); site.seo.image = ''; $dispatch('seoLogoImage', {
                              image: null,
                              public: null,
                              });">
                              {!! __i('--ie', 'trash-bin-delete', 'w-5 h-5') !!}
                           </span>
                        </template>
                      </button>
                   </div>
                </div>
                <h4 class="text-[color:var(--c-mix-3)] text-[16px] mb-[var(--s-1)] leading-[var(--l-title)] font-normal" x-text="site.seo.title ? site.seo.title : site.name"></h4>
                <p class="text-[12px] leading-[var(--l-body)] text-[color:var(--c-mix-3)]">
                  <span x-show="site.seo.block">{{__('This page won\'t show up on search engines, but you can share the link so people can access it.')}}</span>

                  <span x-show="!site.seo.block" x-text="site.seo.description"></span>
               </p>
                <!---->
                {{-- <p class="text-[10px] leading-[var(--l-body)] text-[color:var(--c-mix-3)] mt-[10px]">jeffrey266.vzy.io/page2</p> --}}
             </div>
          </div>
         </div>
         
      </div>
     </div>
     @script
     <script>
         Alpine.data('builder__seo', () => {
            return {
               autoSaveTimer: null,
               init(){
                  var $this = this;
                  window.addEventListener("seoLogoImage", (event) => {
                      $this.site.seo.image = event.detail.image;
                  });
               }
            }
         });
     </script>
     @endscript
</div>
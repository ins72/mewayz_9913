
<?php

use function Livewire\Volt\{state, mount, usesFileUploads, updated, on};

// Methods

$openAiGenerate = function($context = '', $query = ''){
    $client = \OpenAI::client(config('app.openai_key'));
    $messages = [];

    $messages[] = [
        'role' => 'system',
        'content' => 'This is not interactive, generate only response. Dont act like a chatbot or generate response like a chatbot. Just generate response to the answer asked without starting with "sure", "certainly", "here is your response".'
    ];

    $messages[] = [
        'role' => 'user',
        'content' => "This is the context to work with '$context'",
    ];

    $messages[] = [
        'role' => 'user',
        'content' => $query
    ];
        
    $result = $client->chat()->createStreamed([
        'model' => 'gpt-3.5-turbo',
        'messages' => $messages,
    ]);

    $content = '';
    foreach ($result as $result) {
        $_array = $streamContent = $result->choices[0]->toArray();
        if(ao($_array, 'delta.content')){
            $streamContent = $_array['delta']['content'];
            $this->stream(
                to: 'textareaSuggest',
                content: $streamContent,
                replace: false,
            );
        }
    }
};

?>
<div class="openai-livewire"></div>
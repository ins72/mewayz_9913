
<?php
   use Illuminate\Support\Facades\Validator;
   use function Livewire\Volt\{state, mount, placeholder, on};

   state([
      '__page' => '-',
      'site',
   ]);

   placeholder('
   <div class="w-full p-5 mt-1">
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
   </div>');

   on([
    
   ]);

   $checkAddress = function($address){
      $address = slugify($address, '-');
      $validator = Validator::make([
         'address' => $address
      ], [
         'address' => 'required|string|min:4|unique:sites,address,'.$this->site->id
      ]);

      if($validator->fails()){
         $this->js('$store.builder.savingState = 2');
         return [
            'status' => 'error',
            'response' => $validator->errors()->first('address'),
         ];
      }

      $this->site->address = $address;
      $this->site->save();

      $this->js('$store.builder.savingState = 2');
      return [
         'status' => 'success',
         'response' => '',
      ];
   };
?>

<div>

   <div x-data="builder__settings">

      <div x-show="__page == 'seo'">
         <div>
           <x-livewire::components.builder.parts.settings.seo />
         </div>
     </div>
     <div x-show="__page == 'domain'">
         <div>
           <livewire:components.builder.parts.settings.domain lazy :$site :key="uukey('builder::settings', 'domain')" />
         </div>
     </div>
     <div x-show="__page == 'pixel'">
         <div>
           <livewire:components.builder.parts.settings.pixel lazy :$site :key="uukey('builder::settings', 'pixel')" />
         </div>
     </div>

      <div x-cloak x-show="__page == '-'">
        <div class="settings-section section">
            <div class="settings-section-content">
        
                <div class="top-bar">
                  <div class="page-settings-navbar">
                     <ul >
                         <li class="close-header !flex">
                         <a @click="navigatePage('pages')">
                             <span>
                                 {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                             </span>
                         </a>
                     </li>
                     <li class="!pl-0">{{ __('Settings') }}</li>
                     <li></li>
                     </ul>
                 </div>
                 <div class="sticky container-small">
                     <div class="tab-link">
                         <ul class="tabs">
                         <li class="tab !w-full" @click="__tab = 'page'" :class="{'active': __tab == 'page'}">{{ __('Page') }}</li>
                         <li class="tab !w-full" @click="__tab = 'site'" :class="{'active': __tab == 'site'}">{{ __('Site') }}</li>
                         </ul>
                     </div>
                 </div>
                </div>
                <div class="container-small tab-content-box">
                    <div class="tab-content">
                        <div x-cloak :class="{'active': __tab == 'page'}" data-tab-content>
                            <div  class="mt-2 page-settings">
                                <div  class="mt-2 seo-content">
                                    <form  action="" method="post" onsubmit="return false">
                                        <div class="input-box">
                                            <div class="input-label">{{ __('Title') }}</div>
                                            <div class="input-group">
                                                <input type="text" class="input-small" placeholder="{{ __('Add title') }}" x-model="currentPage.name">
                                            </div>
                                        </div>
                                        <template x-if="!currentPage.default">
                                            <div class="input-box">
                                                <div class="input-label">{{ __('Link') }}</div>
                                                <div class="input-group">
                                                    <input type="text" class="input-small" placeholder="{{ __('Add link') }}" x-model="currentPage.slug">
                                                </div>
                                            </div>
                                        </template>
                                        <div  class="post-settings">
                                            
                                        </div>
                                    </form>
                                </div>
                                <div  class="page-actions">
                                    <ul >
                                        <template x-if="!currentPage.default">
                                        <li>
                                            <div class="input-box !mt-0">
                                                <div class="input-group !border-0">
                                                    <div class="switchWrapper">
                                                        <input id="set-homepage" type="checkbox" class="switchInput !border-0" x-model="currentPage.default" x-on:input="$dispatch('builder::setAsHomeEvent', currentPage)">
                                                        <label for="set-homepage" class="switchLabel">{{ __('Set as homepage') }}</label>
                                                        <div class="slider"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        </template>
                                        
                                        <li >
                                            <a @click="__page='seo'">{{ __('SEO & Social') }}
                                            <span>
                                                {!! __i('Arrows, Diagrams', 'Arrow.5') !!}
                                             </span>
                                            </a>
                                        </li>
                                        {{-- <li class="!hidden">
                                            <a  name="duplicate"> Page password <span>
                                                <svg
                                                         width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path  d="M9 18L15 12L9 6" stroke="var(--foreground)"
                                                            stroke-miterlimit="10" stroke-linecap="square"></path>
                                                    </svg>
                                                </span>
                                            </a>
                                        </li> --}}
                                        <li><a  name="duplicate">{{ __('Duplicate page') }}</a></li>


                                        <li class="mb-2 !hidden" @click="deletePage();">
                                            <a class="delete-page-link" name="delete">{{ __('Delete page') }}</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                        <div x-cloak :class="{'active': __tab == 'site'}" data-tab-content>
                            <div class="mt-2 site-settings-section">
                                <form action="" method="post" onsubmit="return false">
                                   <div class="input-box">
                                      <div class="input-label active" for="display">{{ __('Title') }}</div>
                                      <div class="input-group">
                                       <input type="text" class="input-small" placeholder="{{ __('Your Site') }}" x-model="site.name">
                                    </div>
                                   </div>



                                   <div class="input-box">
                                      <div class="input-label active" for="display">{{ __('Domain') }}</div>
                                      <div class="input-group flex-col">
                                          {{-- <span class="![right:initial] left-[0] !border-l-0 [border-right:1px_solid_var(--c-mix-1)] z-10">{{ parse(config('app.url'), 'host') }}/</span> --}}

                                          <input type="text" class="input-small !zpl-[calc(var(--unit)*_7.5)]" maxlength="20" :value="site.address" @input="checkAddress($event.target.value)" placeholder="{{ __('Site Link') }}">
                                          
                                          <template x-if="addressError">
                                             <div class="bg-red-200 text-[11px] p-1 px-2 rounded-md">
                                                <div class="flex items-center">
                                                   <div>
                                                      <i class="fi fi-rr-cross-circle flex text-xs"></i>
                                                   </div>
                                                   <div class="flex-grow ml-1 text-xs" x-text="addressError"></div>
                                                </div>
                                             </div>
                                          </template>
                                       </div>
                                   </div>

                                   <!---->
                                   <div class="input-box">
                                      <div class="input-label">{{ __('Favicon') }}</div>
                                      
                                      <div class="input-group">
                                                                  
                                       <div class="group block h-20 bg-white- cursor-pointer rounded-lg border-2 border-dashed text-center hover:border-solid hover:border-yellow-600 relative mb-1 w-[100%]" :class="{
                                          'border-gray-200': !site.favicon,
                                          'border-transparent': site.favicon,
                                       }">
                                          <template x-if="site.favicon">
                                             <div class="group-hover:flex hidden w-full h-full items-center justify-center absolute right-0 top-0 left-0 bottom-0">
                                                <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center icon-shadow" @click="site.favicon = ''; $dispatch('siteFavicon:change', {
                                                   image: null,
                                                   public: null,
                                                   })">
                                                   <i class="fi fi-rr-trash"></i>
                                                </div>
                                          </div>
                                          </template>
                                          <template x-if="!site.favicon">
                                             <div class="w-[100%] h-full flex items-center justify-center" @click="openMedia({
                                                event: 'siteFavicon:change', sectionBack:'navigatePage(\'__last_state\')'
                                                })">
                                                <i class="fi fi-ss-plus"></i>
                                             </div>
                                          </template>
                                          <template x-if="site.favicon">
                                             <div class="h-full w-[100%]">
                                                <img :src="$store.builder.getMedia(site.favicon)" class="h-full w-[100%] object-cover rounded-md" alt="">
                                             </div>
                                          </template>
                                       </div>
                                      </div>
                                   </div>
                                   <div class="input-box">
                                      <div class="input-label active" for="display">{{ __('Email') }}</div>
                                      <div class="input-group">
                                          <input type="text" x-model="site.email" class="input-small" placeholder="{{ __('Site Email') }}">
                                      </div>
                                   </div>
                                </form>
                                <div class="mt-2 site-actions">
                                   <div class="input-box">
                                      <div class="input-label" for="link"></div>
                                      <div class="input-group">
                                         <div class="switchWrapper">
                                            <input id="made-in-yena" type="checkbox" class="switchInput" disabled=""><label for="made-in-yena" class="switchLabel">{{ __('Branding') }}</label>
                                            <div class="slider"></div>
                                         </div>
                                      </div>
                                   </div>

                                   <div class="input-box">
                                      <div class="input-label" for="link"></div>
                                      <div class="input-group">
                                         <div class="switchWrapper">
                                            <input id="site-preloader" type="checkbox" class="switchInput" x-model="site.settings.preloader">
                                            <label for="site-preloader" class="switchLabel">{{ __('Site preloader') }}</label>

                                            <div class="slider"></div>
                                         </div>
                                      </div>
                                   </div>
                                   <ul>
                                      <li>
                                         <a name="site plans">
                                            <p>{{ __('Site plans') }}</p>
                                            <span>
                                                {!! __i('Arrows, Diagrams', 'Arrow.5') !!}
                                            </span>
                                         </a>
                                      </li>
                                      <li @click="__page='domain'">
                                         <a name="signup">
                                            <p>{{ __('Custom domain') }}</p>
                                            <span>
                                                {!! __i('Arrows, Diagrams', 'Arrow.5') !!}
                                            </span>
                                         </a>
                                      </li>
                                      <li @click="__page='pixel'">
                                         <a name="export-site">
                                            <p>{{ __('Pixel code') }}</p>
                                            <span>
                                                {!! __i('Arrows, Diagrams', 'Arrow.5') !!}
                                            </span>
                                         </a>
                                      </li>
                                      
                                      {{-- <li>
                                         <a name="export-site">
                                            <p>{{ __('Custom code') }}</p>
                                            <span>
                                                {!! __i('Arrows, Diagrams', 'Arrow.5') !!}
                                            </span>
                                         </a>
                                      </li> --}}
                                      {{-- <li>
                                         <a name="yena-pro">
                                            <p>Transfer site</p>
                                            <span>
                                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                  <path d="M9 18L15 12L9 6" stroke="var(--foreground)" stroke-miterlimit="10" stroke-linecap="square"></path>
                                               </svg>
                                            </span>
                                         </a>
                                      </li> --}}
                                      <li>
                                         <a name="signup">
                                            <p>{{ __('Duplicate site') }}</p>
                                            <span></span>
                                         </a>
                                      </li>
                                      <li>
                                         <a>
                                            <p class="opacity-30">{{ __('Export site (soon)') }}</p>
                                            <span></span>
                                         </a>
                                      </li>
                                      <li>
                                         <a name="unpublish-site">
                                            <p class="error">{{ __('Unpublish site') }}</p>
                                            <span></span>
                                         </a>
                                      </li>
                                      <li class="mb-2">
                                         <a class="delete-site" name="yena-pro">
                                            <p>{{ __('Delete site') }}</p>
                                            <span></span>
                                         </a>
                                      </li>
                                   </ul>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
      </div>
    
      @script
      <script>
          Alpine.data('builder__settings', () => {
             return {
                __tab: 'page',
                __page: @entangle('__page'),
                autoSaveTimer: null,
                addressError: false,
                checkAddress(address){
                  address = address.toString() // Cast to string
                              .toLowerCase() // Convert the string to lowercase letters
                              .normalize('NFD') // The normalize() method returns the Unicode Normalization Form of a given string.
                              .trim() // Remove whitespace from both sides of a string
                              .replace(/\s+/g, '-') // Replace spaces with -
                              .replace(/[^\w\-]+/g, '') // Remove all non-word chars
                              .replace(/\-\-+/g, '-');
                  this.$event.target.value = address;
                  let $this = this;

                  $this.addressError = false;
                  clearTimeout($this.autoSaveTimer);

                  $this.autoSaveTimer = setTimeout(function(){
                     $this.$store.builder.savingState = 0;
                      
                     $this.$wire.checkAddress(address).then(r => {
                        if(r.status === 'error'){
                           $this.addressError = r.response;
                        }
                        if(r.status === 'success'){
                           $this.addressError = false;
                        }
                     });

                  }, $this.$store.builder.autoSaveDelay);
                },
                deletePage() {
                    //if(!this.currentPage && this.pages.length > 0) this.currentPage = this.pages[0];
                    this.pages.forEach((element, index) => {
                        if(item.id == element.id){
                            this.pages.splice(index, 1);
                        }
                    });
                    // this.$wire.deletePage(item.id);
                    // this.$dispatch('builder::reloadPage');
                    
                    // this.getCurrentPage();
                    $dispatch('builder::deletePageEvent', this.currentPage);
                    $dispatch('builder::setPageEvent', this.pages[0].id);
                },
                init(){
                   var $this = this;

                     window.addEventListener("siteFavicon:change", (event) => {
                      $this.site.favicon = event.detail.image;
                     });
                     
                    this.$watch('currentPage' , (value, _v) => {
                        $this.$dispatch('builder::updatePage', $this.currentPage);
                        clearTimeout($this.autoSaveTimer);

                        $this.autoSaveTimer = setTimeout(function(){
                            $this.$store.builder.savingState = 0;
                            event = new CustomEvent("builder::savePage", {
                                detail: {
                                    page: $this.currentPage,
                                    js: '$store.builder.savingState = 2',
                                }
                            });

                            window.dispatchEvent(event);
                        }, $this.$store.builder.autoSaveDelay);
                    });
                }
             }
          });
      </script>
      @endscript
    </div>
</div>
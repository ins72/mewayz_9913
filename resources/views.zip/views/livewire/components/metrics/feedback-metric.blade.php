<?php

use function Livewire\Volt\{state, mount};
use App\Models\ProjectPixelDatum;
use Carbon\Carbon;


state([
    'metric' => function(){
      $start_date = Carbon::now()->subDays(30)->format('Y-m-d');
      $end_date = Carbon::now()->addDays(1)->format('Y-m-d');

      $query = ProjectPixelDatum::whereBetween('created_at', [$start_date, $end_date])->get();


      $feedbackMetrics = [];
      $reactionMetrics = [];

      foreach ($query as $item) {
         if (!array_key_exists($item->reaction, $reactionMetrics)) {
             $reactionMetrics[$item->reaction] = [
                 'count' => 0
             ];
         }
         if (array_key_exists($item->reaction, $reactionMetrics)) {
             $reactionMetrics[$item->reaction]['count']++;
         }
      }

      return get_chart_data($reactionMetrics);
    }
]);

mount(function (){
    sleep(2);

    $this->js("
    
        let el = document.createElement('div');
        el.classList.add('chart-line');

        document.querySelector('.chart-line-inner').appendChild(el);
    ");
});
//

?>

<div>
    ss
    
    <div wire:ignore class="chart-line-inner">
        
    </div>

    <script>
        var lmao = {
           series: [{
              name: 'series1',
              data: [31, 40, 28, 51, 42, 109, 100]
           }],
           colors: ['#FFB7F5', '#FFB7F5', '#FFB7F5']
        }
        
        //<div class="chart-line" data-chart="lmao"></div>

        document.addEventListener('livewire:initialized', () => {
            alert();
        });
     </script>
    <script>

    </script>
</div>

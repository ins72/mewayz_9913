<div>

    @php
        $classes = collect([
            'card-box',
            'section-width-fill',
            'box',
            'section-bg-wrapper', 
            'focus'
        ]);

        $classes = $classes->toArray();
    @endphp
    <div class="{{ implode(' ', $classes) }}" x-data="builder__cardSectionView" :class="sectionClass" :style="{'--section-image': 'url('+$store.builder.getMedia(section.section_settings !== null && section.section_settings.image)+')'}">
      <div class="text-left inner-content" :class="{
         'text-left': section.settings.align == 'left' || section.settings.split_title,
         'text-center': !section.settings.split_title && section.settings.align == 'center',
         'text-right': !section.settings.split_title && section.settings.align == 'right'
        }" :style="{
         '--image-height': section.settings.desktop_height + 'px',
         '--image-height-mobile': section.settings.mobile_height + 'px',
        }">
        
        
         <div class="card-container w-boxed !border-none" :class="{
            'background': section.settings.background,
            'border': section.settings.border,
            'space-below': !section.settings.background && !section.settings.border,

            'left-title': section.settings.split_title,
            'card-1': section.settings.style == '1',
            'card-2': section.settings.style == '2',

            'left': section.settings.align == 'left',
            'center': section.settings.align == 'center',
            'right': section.settings.align == 'right',
         }">
            <div class="card-header">
               <div class="[text-align:inherit]">
                <template x-if="section.content.label">

                  <span class="text-[var(--foreground)] bg-[var(--c-mix-1)] px-[9px] py-[3px] mb-1 rounded-[var(--shape)] t-0" x-text="section.content.label"></span>
                </template>
               </div>
               <template x-if="section.content.title">
               <h2 class="t-4 pre-line [text-align:inherit]" x-text="section.content.title"></h2>
               </template>
               <template x-if="section.content.subtitle">
                  <p class="t-1 pre-line subtitle [text-align:inherit]" x-text="section.content.subtitle"></p>
               </template>
            </div>

            <div class="card-container [--scroll-speed:22.5s]" :class="`col-${section.settings.desktop_grid} col-mobile-${section.settings.mobile_grid}`">
               <template x-for="(item, index) in window._.sortBy(section.items, 'position')" :key="item.uuid">
                  <div class="cursor-none card" :class="{
                     'min-shape': section.settings.border,
                  }">
                     <a href="javascript:void(0)" target="" name="card-link" class="bottom" :class="{
                        'top': section.settings.layout_align == 'top',
                        'center': section.settings.layout_align == 'center',
                        'bottom': section.settings.layout_align == 'bottom',
                        '!p-0 !bg-transparent': !section.settings.background,
                     }">
                        <div class="card-text" :class="{
                           'min-shape': section.settings.style == '2',
                           'glass': section.settings.glass
                        }">
                           <div class="pre-line t-1" :class="{
                              't-1': section.settings.text == 's' || section.settings.text == 'm',
                              'small-size': section.settings.text == 's',
                              '!font-bold': section.settings.text == 'm',
                              't-3 !font-bold': section.settings.text == 'l',
                           }" x-text="item.content.title"></div>
                           
                           <template x-if="section.settings.style == '2'">
                              <div class="description mt-1 [text-align:inherit]">
                                 <p class="pre-line t-0 [text-align:inherit]" :class="{
                                    't-0': section.settings.text == 's' || section.settings.text == 'm',
                                    't-1': section.settings.text == 'l',
                                 }" x-text="item.content.text"></p>
                              </div>
                           </template>
                           <template x-if="section.settings.style == '2' && item.content.button">
                              <button class="card__button site-btn t-1 shape" onclick="window.open('javascript:void(0)', '_self')" :class="{
                                 'grey': item.content.color == 'default' || !item.content.color,
                                 'accent': item.content.color == 'accent', 
                              }" x-text="item.content.button"></button>
                           </template>
                        </div>

                        
                        <div class="card-image min-shape !h-[var(--image-height)]" :class="{
                           '!hidden': section.settings.style == '1' && !section.settings.enable_image
                        }">
                           <template x-if="item.content.image">
                              <img :src="$store.builder.getMedia(item.content.image)" alt="" class="!h-[var(--image-height)]">
                           </template>
                           <template x-if="!item.content.image">
                              <div class="default-image">
                                 {!! __i('--ie', 'image-picture', 'text-gray-300 w-5 h-5') !!}
                              </div>
                           </template>                     
                        </div>
                        
                        <template x-if="section.settings.style == '1'">
                           <div class="card-text">
                              <div class="description mt-1 [text-align:inherit]">
                                 <p class="pre-line t-0 [text-align:inherit]" :class="{
                                    't-0': section.settings.text == 's' || section.settings.text == 'm',
                                    't-1': section.settings.text == 'l',
                                 }" x-text="item.content.text"></p>
                              </div>
                           </div>
                        </template>
                        <template x-if="section.settings.style == '1' && item.content.button">
                           <button class="card__button site-btn t-1 shape" onclick="window.open('javascript:void(0)', '_self')" :class="{
                              'grey': item.content.color == 'default' || !item.content.color,
                              'accent': item.content.color == 'accent', 
                           }" x-text="item.content.button"></button>
                        </template>
                     </a>
                     <div class="screen"></div>
                  </div>
                  {{-- <div class="card-container__item">
                     <a class="no-dark" href="javascript:void(0)" target="_self" :style="{
                        '--scale': item.content.desktop_size,
                        '--mobile-scale': item.content.mobile_size,
                     }">
                        
                        <template x-if="item.content.image">
                           <img :src="$store.builder.getMedia(item.content.image)" alt="" class="light-logo">
                        </template>
                        
                        <template x-if="!item.content.image">
                           <div class="default-image">
                              {!! __i('--ie', 'image-picture', 'text-gray-300 w-5 h-5') !!}
                           </div>
                        </template>
                     </a>
                     <div class="screen"></div>
                  </div> --}}
               </template>
            </div>
         </div>
      </div>
   </div>
     @script
     <script>
         Alpine.data('builder__cardSectionView', () => {
            return {
               items: {},
               sectionClass: function(){
                return this.$store.builder.generateSectionClass(this.section);
               },
               sectionStyles: function(){
                return this.$store.builder.generateSectionStyles(this.section);
               },

               sectionClasses: function(){
                this.sectionClass();
                this.sectionStyles();
               },

               init(){
                  // console.log('lll', this.section, this.section.items)
                  //console.log(this.items)
                  var $this = this;
                  this.items = this.section.items;
                  window.addEventListener('section::' + this.section.id, (event) => {
                      $this.section = event.detail;
                     $this.sectionClasses();
                  });

                  window.addEventListener('sectionItem::' + this.section.id, (event) => {
                      $this.items = event.detail;
                  });
               }
            }
         });
     </script>
     @endscript
     
</div>
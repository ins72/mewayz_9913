<?php
    use App\Models\SectionItem;
    use App\Livewire\Actions\BroadcastBuilder;
    use function Livewire\Volt\{state, mount, rules, on};

    state([
        'section',
        'items' => [],
        'itemsArray' => [],
        'site',
        '__page' => '-'
    ]);

    rules([
        'section.content.label' => '',
        'section.content.title' => '',
        'section.content.subtitle' => '',
        
        'section.settings.icon' => '',
        'section.settings.align' => '',
        'section.settings.split_title' => '',
        'section.settings.bg_type' => '',
        'section.settings.background' => '',
    ]);

    on([
        'saveSection::{section.id}' => function($js){
            $this->section->save();

            $this->js($js);
            $this->dispatch('section::saved', $this->section->id);
        }
    ]);

    mount(function(){
        $this->getItems();
    });

    $getItems = function(){
        $this->items = $this->section->getItems()->orderBy('id', 'ASC')->orderBy('position', 'DESC')->get()->toArray();
    };

    $saveSection = function(){
        foreach ($this->items as $item) {
            if(!$_item = SectionItem::find(ao($item, 'id'))) continue;
            $_item->content = ao($item, 'content');
            $_item->save();
        }

        $this->section->save();

        $this->dispatch('section::saved', $this->section->id);
    };

    $deleteItem = function($id){
        $item = false;
        foreach ($this->items as $value) {
            if(ao($value, 'id') == $id) $item = $value;
        }

        if(!$_item = SectionItem::find(ao($item, 'id'))) return;

        $_item->delete();

        $this->getItems();
        $this->__page = '-';
    };

    $createItem = function(){
        $content = [
            'title' => __('Add title'),
            'text' => __('Add description'),
        ];

        $item = new SectionItem;
        $item->section_id = $this->section->id;
        $item->content = $content;
        $item->save();

        $this->getItems();
    };
?>


<div x-data="builder__sectionAccordion">

  <div x-show="__page == 'section'">
      <div>
         <livewire:components.builder.parts.section :$section lazy sectionBack="__page = '-'" :key="uukey()">
      </div>
  </div>

  <template x-for="item in items" :key="item.id">
    <div x-show="__page == 'section::accordion::' + item.id">
        <div>
            <x-livewire::sections.accordion.partial.edit.accordion />
        </div>
    </div>
  </template>

  <div x-cloak x-show="__page == '-'">
    <div class="banner-section !block">
        <div>
    
            <div class="banner-navbar">
                <ul >
                    <li class="close-header !flex">
                    <a @click="navigatePage('pages')">
                        <span>
                            {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                        </span>
                    </a>
                </li>
                <li class="!pl-0">{{ __('Accordion') }}</li>
                <li></li>
                </ul>
            </div>
            <div class="container-small sticky">
                <div class="tab-link">
                    <ul class="tabs">
                    <li class="tab !w-full" @click="__tab = 'content'" :class="{'active': __tab == 'content'}">{{ __('Content') }}</li>
                    <li class="tab !w-full" @click="__tab = 'style'" :class="{'active': __tab == 'style'}">{{ __('Style') }}</li>
                    </ul>
                </div>
            </div>
            <div class="container-small tab-content-box">
                <div class="tab-content">
                    <div x-cloak x-show="__tab == 'content'" data-tab-content>
                        <x-livewire::sections.accordion.partial.edit.content :$section :$items/>
                    </div>
                    <div x-cloak x-show="__tab == 'style'" data-tab-content>
                        <x-livewire::sections.accordion.partial.edit.style :$section/>
                    </div>
                </div>
            </div>
        </div>
      </div>
  </div>

  @script
  <script>
      Alpine.data('builder__sectionAccordion', () => {
         return {
            section: @entangle('section'),
            items: @entangle('items'),
            autoSaveTimer: null,
            __tab: 'content',
            __page: @entangle('__page'),
          
            init(){
               var $this = this;
               var $eventID = 'section::{{ $section->id }}';
               var $eventIDItem = 'sectionItem::{{ $section->id }}';
               var $saveSection = 'saveSection::{{ $section->id }}';

               //console.log(this.section)

               this.$watch('section' , (value, _v) => {
                  $this.$dispatch($eventID, $this.section);
                  
                  clearTimeout($this.autoSaveTimer);

                  $this.autoSaveTimer = setTimeout(function(){
                      $this.$store.builder.savingState = 0;

                        $this.$wire.saveSection().then(function(){
                            $this.$store.builder.savingState = 2;
                        });
                      /*$this.$dispatch($saveSection, {
                        js: 'this.$store.builder.savingState = 2',
                      });*/
                  }, $this.$store.builder.autoSaveDelay);
                });


                
               this.$watch('items' , (value, _v) => {
                    $this.$dispatch($eventIDItem, $this.items);
                    clearTimeout($this.autoSaveTimer);

                    $this.autoSaveTimer = setTimeout(function(){
                        $this.$store.builder.savingState = 0;

                            $this.$wire.saveSection().then(function(){
                                $this.$store.builder.savingState = 2;
                            });
                        /*$this.$dispatch($saveSection, {
                            js: 'this.$store.builder.savingState = 2',
                        });*/
                    }, $this.$store.builder.autoSaveDelay);
               });
            }
         }
      });
  </script>
  @endscript
</div>
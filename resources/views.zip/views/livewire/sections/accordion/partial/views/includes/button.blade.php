
<div class="flex items-center">
    <a target="" href="/page2" class="btn-1">
        <button  class="t-1 shape">Button 1</button>
    </a>
    <a target="" href="javascript:void(0)" class="btn-2">
        <button  class="t-1 shape">Button 2</button>
    </a>
    <div  class="screen"></div>
</div>
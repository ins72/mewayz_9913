<div>

    @php
        $classes = collect([
            'pricing-box',
            'section-width-fill',
            'box',
            'section-bg-wrapper', 
            'focus'
        ]);

        $classes = $classes->toArray();
    @endphp
    <div class="{{ implode(' ', $classes) }}" x-data="builder__pricingSectionView" :class="sectionClass" :style="{'--section-image': 'url('+$store.builder.getMedia(section.section_settings !== null && section.section_settings.image)+')'}">
      <div class="text-left inner-content" :class="{
         'text-left': section.settings.align == 'left' || section.settings.split_title,
         'text-center': !section.settings.split_title && section.settings.align == 'center',
         'text-right': !section.settings.split_title && section.settings.align == 'right'
        }">
        
        
         <div class="pricing-container-small w-boxed !border-none" :class="{
            'space-below': !section.settings.background && !section.settings.border,

            'left-title': section.settings.split_title,

            'left': section.settings.align == 'left',
            'center': section.settings.align == 'center',
            'right': section.settings.align == 'right',
         }">
            <div class="pricing-header">
               <div class="pricing-heading">
                  <div class="[text-align:inherit]">
                   <template x-if="section.content.label">
                      <span class="text-[var(--foreground)] bg-[var(--c-mix-1)] px-[9px] py-[3px] mb-1 rounded-[var(--shape)] t-0" x-text="section.content.label"></span>
                   </template>
                  </div>
                  <template x-if="section.content.title">
                  <h2 class="t-4 pre-line [text-align:inherit]" x-text="section.content.title"></h2>
                  </template>
                  <template x-if="section.content.subtitle">
                     <p class="t-1 pre-line subtitle [text-align:inherit]" x-text="section.content.subtitle"></p>
                  </template>
               </div>

               <template x-if="section.settings.type == 'plans'">
                  <div class="display-options">
                     <div class="display-style">
                        <ul>
                           <li class="monthly-plan-btn" @click="price_selector='month'" :class="{
                              'active': price_selector=='month'
                           }">{{ __('Monthly') }}</li>
                           <li class="yearly-plan-btn" @click="price_selector='year'" :class="{
                              'active': price_selector=='year'
                           }">{{ __('Yearly') }}</li>
                        </ul>
                     </div>
                  </div>
               </template>
            </div>

            <div class="pricing-section mt-2" :class="{   
               'layout-1': section.settings.style == '1',
               'layout-2': section.settings.style == '2',
            }">
               <template x-for="(item, index) in window._.sortBy(items, 'position')" :key="item.uuid">
                  <div class="background not-popular-price tier" :class="{
                     'background': section.settings.background,
                     'border': section.settings.border,
                     'not-popular-price': !item.content.popular_price,
                     'popular-price': item.content.popular_price,
                  }">
                     <div class="pricing-column">
                        <div class="price-title t-1" :class="{
                           't-1': section.settings.text == 's' || section.settings.text == 'm',
                           'small-size !font-normal': section.settings.text == 's',
                           '!font-bold': section.settings.text == 'm',
                           't-2 !font-bold': section.settings.text == 'l',
                        }">
                           <span x-text="item.content.title"></span>

                           <template x-if="item.content.popular_price">
                              <p class="t-0">{{ __('Most Popular') }}</p>
                           </template>
                        </div>
                        <template x-if="item.content.text">
                           <p class="price-description t-0" :class="{
                              't-0': section.settings.text == 's' || section.settings.text == 'm',
                              't-1': section.settings.text == 'l',
                           }" x-text="item.content.text"></p>
                        </template>
                        <div class="billing-price">

                           <template x-if="section.settings.type == 'single'">
                              <p class="amount t-4" x-html="generatePrice(item.content.single_price)"></p>
                           </template>
                           
                           <template x-if="price_selector == 'month' && section.settings.type == 'plans'">
                              <p class="amount t-4" x-html="generatePrice(item.content.month_price)"></p>
                           </template>
                           <template x-if="price_selector == 'year' && section.settings.type == 'plans'">
                              <p class="amount t-4" x-html="generatePrice(item.content.year_price)"></p>
                           </template>

                           <template x-if="section.settings.type == 'plans'">
                              <p class="period" x-text="price_selector == 'month' ? '{{ '/month' }}' : '{{ '/year' }}'"></p>
                           </template>
                        </div>
                     </div>
                     <div class="pricing-details">
                        <template x-if="item.content.features">
                           <div class="pricing-benefits">
                              <ul>
                                 <template x-for="(feature, index) in item.content.features" :key="index">
                                    <li>
                                       <i class="fi fi-rr-check flex items-center mr-[10px]" :class="{
                                          'text-[color:var(--accent)]': item.content.popular_price,
                                       }"></i>
                                       <span x-text="feature.name"></span>
                                    </li>
                                 </template>
                              </ul>
                           </div>
                        </template>
                        <template x-if="item.content.button">
                           <a href="javascript:void(0)" target="" :class="{
                              'mb-2': section.settings.style == '2',
                           }">
                              <button class="t-1 btn" :class="{
                                 'popular-price': item.content.popular_price,
                              }" x-text="item.content.button"></button>
                           </a>
                        </template>
                     </div>
                     <div class="screen"></div>
                  </div>
                  {{-- <div class="pricing section-item" :style="{
                     '--width': section.settings.desktop_width + 'px',
                     '--mobile-width': section.settings.mobile_width + 'px',
                  }">
                     <a href="javascript:void(0)" target="" name="item-link" class="item-link min-shape" :class="{
                        'row-reverse': section.settings.style == '2',
                        'display-block': section.settings.style == '2' && section.settings.layout == 'right',

                        'column': section.settings.style == '1' && section.settings.layout == 'right',
                        '!bg-transparent': section.settings.border,
                     }">
                     <template x-if="section.settings.icon">
                        <div class="pricing-image section-item-image min-shape" :style="{
                           'height': section.settings.desktop_height + 'px',
                           'width': section.settings.desktop_height + 'px',
                        }" :class="{
                           'avatar-image': section.settings.shape == 'circle',
                        }">
                           <div class="pricing-icon overflow-hidden" :class="{
                              'grey': section.settings.border
                           }">
                              <template x-if="item.content.image">
                                 <img :src="$store.builder.getMedia(item.content.image)" class="w-[100%] h-[100%] !rounded-none object-cover" alt="">
                              </template>
                              <template x-if="!item.content.image">
                                 <div class="default-image">
                                    {!! __i('--ie', 'image-picture', 'text-gray-300 w-5 h-5') !!}
                                 </div>
                              </template>
                           </div>
                        </div>
                     </template>
                        <div class="pricing-text">
                           <h3 class="pre-line t-1 small-size" x-text="item.content.title" :class="{
                              
                              't-1': section.settings.text == 's' || section.settings.text == 'm',
                              'small-size': section.settings.text == 's',
                              '!font-bold': section.settings.text == 'm',
                              't-2 !font-bold': section.settings.text == 'l',
                           }"></h3>
                           <template x-if="item.content.text">
                              <p class="pre-line t-0" :class="{
                                 't-0': section.settings.text == 's' || section.settings.text == 'm',
                                 't-2': section.settings.text == 'l',
                              }" x-text="item.content.text"></p>
                           </template>
                        </div>
                     </a>
                     <div class="screen"></div>
                  </div> --}}
               </template>
            </div>
         </div>
      </div>
   </div>
     @script
     <script>
         Alpine.data('builder__pricingSectionView', () => {
            return {
               items: {},
               ratings: [1,2,3,4,5],
               price_selector: 'month',
               currencies: {!! collect(\Currency::currency())->toJson() !!},

               sectionClass: function(){
                return this.$store.builder.generateSectionClass(this.section);
               },
               sectionStyles: function(){
                return this.$store.builder.generateSectionStyles(this.section);
               },

               sectionClasses: function(){
                this.sectionClass();
                this.sectionStyles();
               },

               generatePrice(price){
                  let currency = this.section.settings.currency;


                  if(this.currencies[currency]){
                     currency = this.currencies[currency];
                  }
                  price = !price ? 0 : price;
                  return currency + price;
               },

               init(){
                  // console.log('lll', this.section, this.section.items)
                  //console.log(this.items)
                  var $this = this;
                  this.items = this.section.items;
                  window.addEventListener('section::' + this.section.id, (event) => {
                      $this.section = event.detail;
                     $this.sectionClasses();
                  });

                  window.addEventListener('sectionItem::' + this.section.id, (event) => {
                      $this.items = event.detail;
                  });
               }
            }
         });
     </script>
     @endscript
     
</div>
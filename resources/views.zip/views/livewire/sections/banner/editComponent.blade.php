<div x-data="builder__sectionBanner">
    @php
      $_banners = [];
      foreach (collect(config('yena.banners')) as $key => $value) {
        $value['preview'] = Blade::render("<x-livewire::sections.banner.partial.edit.banner.banner_$key/>");
        $_banners[$key] = $value;
      }
    @endphp
  <div x-show="__page == 'form'">
      <div>
        <x-livewire::components.builder.parts.form />
      </div>
  </div>

  <div x-show="__page == 'button'">
      <div>
        <x-livewire::components.builder.parts.button />
      </div>
  </div>

  <div x-show="__page == 'section'">
      <div>
         <x-livewire::components.builder.parts.section />
      </div>
  </div>
  
  <div x-cloak x-show="__page == '-'">
    <div class="banner-section !block">
        <div>
    
            <div class="banner-navbar">
                <ul >
                    <li class="close-header !flex">
                    <a @click="navigatePage('pages')">
                        <span>
                            {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                        </span>
                    </a>
                </li>
                <li class="!pl-0">{{ __('Banner') }}</li>
                <li></li>
                </ul>
            </div>
            <div class="sticky container-small">
                <div class="tab-link">
                    <ul class="tabs">
                    <li class="tab !w-full" @click="__tab = 'content'" :class="{'active': __tab == 'content'}">{{ __('Content') }}</li>
                    <li class="tab !w-full" @click="__tab = 'style'" :class="{'active': __tab == 'style'}">{{ __('Style') }}</li>
                    </ul>
                </div>
            </div>
            <div class="container-small tab-content-box">
                <div class="tab-content">
                    <div x-cloak x-show="__tab == 'content'" data-tab-content>
                        <x-livewire::sections.banner.partial.edit.content />
                    </div>
                    <div x-cloak x-show="__tab == 'style'" data-tab-content>
                        <x-livewire::sections.banner.partial.edit.style />
                    </div>
                </div>
            </div>
        </div>
      </div>
  </div>

  @script
  <script>
      Alpine.data('builder__sectionBanner', () => {
         return {
            autoSaveTimer: null,
            __tab: 'content',
            __page: '-',

            __banners: {!! collect($_banners)->toJson() !!},
            __bannerConfig: [],

            getBannerConfig(){
                this.__bannerConfig = this.__banners[this.section.settings.banner_style];
            },

            changeBanner(){

            },


            _save(){
                var $this = this;
                var $eventID = 'section::' + this.section.id;


                $this.$dispatch($eventID, $this.section);
                clearTimeout($this.autoSaveTimer);

                $this.autoSaveTimer = setTimeout(function(){
                    $this.$store.builder.savingState = 0;

                    // $this.$dispatch('builder::saveSection', {
                    //     section: $this.section,
                    //     js: '$store.builder.savingState = 2',
                    // });

                    event = new CustomEvent("builder::saveSection", {
                        detail: {
                            section: $this.section,
                            js: '$store.builder.savingState = 2',
                        }
                    });

                    window.dispatchEvent(event);
                }, $this.$store.builder.autoSaveDelay);
            },
            init(){
               var $this = this;

               $this.getBannerConfig();
               
               window.addEventListener("sectionMediaEvent:" + this.section.id, (event) => {
                   this.section.image = event.detail.image;
                   this.section.get_image = event.detail.public;
                   $this._save();
               });
               
               window.addEventListener("sectionSettingsMediaEvent:" + this.section.id, (event) => {
                   this.section.section_settings.image = event.detail.image;
                   $this._save();
               });

               this.$watch('section' , (value, _v) => {
                $this._save();
               });
            }
         }
      });
  </script>
  @endscript
</div>
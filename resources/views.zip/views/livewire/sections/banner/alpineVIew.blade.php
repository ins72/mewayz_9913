

<div>
   <div class="" :class="{
       'section-width-fill': section.section_settings.width == 'fill',
       'lr-padding': section.section_settings.width == 'fit',

       ...getClass(),
       }" x-data="builder__bannerSectionView">


   <section class="section-content" :class="{
       'w-boxed min-shape': section.section_settings.width == 'fit'
   }">
       <div class="banner-box section-bg-wrapper transparent color" :class="sectionClass" :style="{'--section-image': 'url('+$store.builder.getMedia(section.section_settings !== null && section.section_settings.image)+')'}">
          <div class="inner-content section-container">
               @foreach(Storage::disk('sections')->files('banner/partial/views/banner') as $item)
                   @php
                       $file = Str::before($item, '.blade.php');
                       $name = basename($file);

                       $banner_name = str_replace('banner-', '', $name);
                       
                       $component = "livewire::sections.banner.partial.views.banner.$name";
                   @endphp

                   <template x-if="section.settings.banner_style == '{{$banner_name}}'">
                       <x-dynamic-component :component="$component"/>
                   </template>
               @endforeach
          </div>
       </div>
    </section>

    @script
    <script>
        Alpine.data('builder__bannerSectionView', () => {
           return {
              bannerConfigs: {!! collect(config('yena.banners'))->toJson() !!},
              media: null,
              getClass: function(){
               var __bannerConfig = this.bannerConfigs[this.section.settings.banner_style];
               var object = {
                  'banner-box': true,
                  'new': true,
                  'box': true,
                  'section-bg-wrapper': true, 
                  'focus': true
               }
               
               var align = '';
               if(!__bannerConfig.align){
                  align = __bannerConfig.default.align;

                  object = {
                     ...object,
                     'align':align
                  }
               }

               return object;
              },
              sectionClass: function(){
               return this.$store.builder.generateSectionClass(this.section);
              },
              sectionStyles: function(){
               return this.$store.builder.generateSectionStyles(this.section);
              },

              sectionClasses: function(){
               this.sectionClass();
               this.sectionStyles();
              },

              init(){
                 var $this = this;
                 $this.media = this.$store.builder.getMedia(this.section.image);

                 window.addEventListener('section::' + this.section.id, (event) => {
                   $this.section = event.detail;
                   $this.sectionClasses();
                 });

                 window.addEventListener('sectionMediaEvent:' + this.section.id, (event) => {
                     $this.media = event.detail.public;
                 });
              }
           }
        });
    </script>
    @endscript
   </div>
</div>
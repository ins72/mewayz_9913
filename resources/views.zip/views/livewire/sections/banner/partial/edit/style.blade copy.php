
<div>
   @php
       $bannerConfig = [];

       if(ao($section->settings, 'banner_style')) $bannerConfig = $bannerstyles[ao($section->settings, 'banner_style')];
   @endphp
   <div class="style">
      <div class="style-block site-layout">
         @foreach ($bannerstyles as $key => $item)
            <button class="btn-layout {{ ao($section->settings, 'banner_style') == $key ? 'active' : '' }}" wire:click="$set('section.settings.banner_style', '{{ $key }}')">
               <span >{{ $key }}</span>
               @includeIf("livewire.sections.banner.partial.edit.banner.banner_$key")
            </button>
         @endforeach
      </div>
      <div class="banner-text-size">
         <form>
            @if (ao($section->settings, 'enable_image'))
            <div class="input-box {{ ao($bannerConfig, 'shape') && ao($section->settings, 'shape') == 'circle' ? '!hidden' : '' }}">
               <label for="text-size">{{ __('Image') }}</label>
               <div class="input-group two-col">
                  <button class="btn-nav {{ ao($section->settings, 'image_type') == 'fill' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.image_type', 'fill')">{{ __('Fill') }}</button>

                  <button class="btn-nav {{ ao($section->settings, 'image_type') == 'fit' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.image_type', 'fit')">{{__('Fit')}}</button>
               </div>
            </div>
            @if (ao($section->settings, 'image_type') == 'fit')
            <div class="input-box">
               <label for="text-size">{{ __('Color') }}</label>
               <div class="input-group two-col" id="color">
                  <button class="btn-nav {{ ao($section->settings, 'color') == 'transparent' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.color', 'transparent')">
                     <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 5L19.1 19.1L5 5ZM12 22C17.5 22 22 17.5 22 12C22 6.5 17.5 2 12 2C6.5 2 2 6.5 2 12C2 17.5 6.5 22 12 22Z" stroke="var(--c-mix-2)" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                     </svg>
                  </button>
                  <button class="btn-nav {{ ao($section->settings, 'color') == 'default' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.color', 'default')">
                     <svg width="24" height="24" viewBox="0 0 24 24" fill="var(--c-mix-10)" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 22C17.523 22 22 17.522 22 12C22 6.478 17.523 2 12 2C6.477 2 2 6.478 2 12C2 17.522 6.477 22 12 22Z" stroke="var(--c-mix-10)"></path>
                     </svg>
                  </button>
                  <button class="btn-nav {{ ao($section->settings, 'color') == 'accent' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.color', 'accent')">
                     <svg width="24" height="24" viewBox="0 0 24 24" fill="var(--accent)" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 22C17.523 22 22 17.522 22 12C22 6.478 17.523 2 12 2C6.477 2 2 6.478 2 12C2 17.522 6.477 22 12 22Z" stroke="var(--accent)"></path>
                     </svg>
                  </button>
               </div>
            </div>
            @endif

            @endif

            <div class="input-box">
               <label for="text-size">{{__('Title')}}</label>
               <div class="input-group align-type">
                  <button class="btn-nav" type="button" :class="{'active': section.settings.title == 's'}" @click="section.settings.title = 's'">S</button>
                  <button class="btn-nav" type="button" :class="{'active': section.settings.title == 'm'}" @click="section.settings.title = 'm'">M</button>
                  <button class="btn-nav" type="button" :class="{'active': section.settings.title == 'l'}" @click="section.settings.title = 'l'">L</button>
                  <button class="btn-nav" type="button" :class="{'active': section.settings.title == 'xl'}" @click="section.settings.title = 'xl'">XL</button>
               </div>
            </div>
            
            @if (ao($bannerConfig, 'align'))
            <div class="input-box">
               <label for="text-size">{{ __('Align') }}</label>
               <div class="input-group align-type">
                  <button class="btn-nav {{ ao($section->settings, 'align') == 'left' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.align', 'left')">
                     {!! __i('Type, Paragraph, Character', 'align-left') !!}
                  </button>
                  <button class="btn-nav {{ ao($section->settings, 'align') == 'center' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.align', 'center')">
                     {!! __i('Type, Paragraph, Character', 'align-center') !!}
                  </button>
                  <button class="btn-nav {{ ao($section->settings, 'align') == 'right' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.align', 'right')">
                     {!! __i('Type, Paragraph, Character', 'align-right') !!}
                  </button>
               </div>
            </div>
            @endif

            @if (true)
            <div class="input-box">
               <label for="text-size">{{__('Width')}}</label>
               <div class="input-group">
                  <input type="range" class="input-small range-slider" min="50" max="75" step="1" wire:model.live="section.settings.width">
                  <p class="image-size-value">{{ao($section->settings, 'width')}}%</p>
               </div>
            </div>
            @endif

            @if (ao($section->settings, 'enable_image'))
            <div class="input-box {{ ao($bannerConfig, 'shape') && ao($section->settings, 'shape') == 'circle' ? '!hidden' : '' }}">
               <label for="text-size">{{__('Height')}}</label>
               <div class="input-group">
                  <input type="range" class="input-small range-slider" min="200" max="700" step="10" wire:model.live="section.settings.height">
                  <p class="image-size-value">{{ao($section->settings, 'height')}}px</p>
               </div>
            </div>
            @endif

            @if (ao($bannerConfig, 'shape') && ao($section->settings, 'enable_image'))
            <div class="columns">
               <div class="input-box">
                  <div class="input-label">{{ __('Shape') }}</div>
                  <div class="input-group">
                     <button class="btn btn-column !flex items-center justify-center text-center {{ ao($section->settings, 'shape') == 'circle' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.shape', 'circle')">
                        {!! __i('Basic Shapes', 'Circle') !!}
                     </button>
                     <button class="btn btn-column !flex items-center justify-center text-center  {{ ao($section->settings, 'shape') == 'square' ? 'active' : '' }}" type="button" wire:click="$set('section.settings.shape', 'square')">
                        {!! __i('Basic Shapes', 'Square', 'sfs[&>*]:stroke-transparent') !!}
                     </button>
                  </div>
               </div>
            </div>

            @if (ao($section->settings, 'shape') == 'circle')
            <div class="input-box">
               <label for="text-size">{{__('Avatar')}}</label>
               <div class="input-group">
                  <input type="range" class="input-small range-slider" min="100" max="200" step="10" wire:model.live="section.settings.shape_avatar">
                  <p class="image-size-value">{{ao($section->settings, 'shape_avatar')}}px</p>
               </div>
            </div>
            @endif
            @endif

            <div class="mt-2 input-box banner-advanced banner-image">
               <div class="input-group">
                  <div class="switchWrapper">
                     <input id="showImage-switch" type="checkbox" wire:model.live="section.settings.enable_image" class="switchInput">
                     <label for="showImage-switch" class="switchLabel">{{ __('Enable Image') }}</label>
                     <div class="slider"></div>
                  </div>
               </div>
            </div>

            @if (ao($bannerConfig, 'split'))
            <div class="input-box banner-advanced banner-action">
               <div class="input-group">
                  <div class="switchWrapper">
                     <input id="splitSection-switch" type="checkbox" wire:model.live="section.settings.split_title" class="switchInput">

                     <label for="splitSection-switch" class="switchLabel">{{ __('Split Section') }}</label>
                     <div class="slider"></div>
                  </div>
               </div>
            </div>
            @endif
            
            <div class="input-box banner-advanced banner-action">
               <div class="input-group">
                  <div class="switchWrapper">
                     <input id="showAction-switch" type="checkbox" class="switchInput"><label for="showAction-switch" class="switchLabel">Button</label>
                     <div class="slider"></div>
                  </div>
               </div>
            </div>
            
            <div class="cursor-pointer input-box banner-advanced banner-action" @click="__page = 'section'">
               <div class="input-group" >
                  <div class="section-background" >
                     <label for="showSection-switch" class="" >{{ __('Section Background') }}</label>
                     <span>
                        {!! __icon('Arrows, Diagrams', 'Arrow.5', 'w-5 h-5') !!}
                     </span>
                  </div>
               </div>
            </div>
         </form>
      </div>
   </div>
</div>
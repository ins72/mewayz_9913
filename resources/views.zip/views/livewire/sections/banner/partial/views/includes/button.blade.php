
<div class="flex items-center">
    <template x-if="section.settings.button_one_text">
        <a target="" href="javascript:void(0)" class="btn-1">
            <button class="t-1 shape" x-text="section.settings.button_one_text"></button>
        </a>
    </template>
    <template x-if="section.settings.button_two_text">
        <a target="" href="javascript:void(0)" class="btn-2">
            <button class="t-1 shape" x-text="section.settings.button_two_text"></button>
        </a>
    </template>
    <div class="screen"></div>
</div>
<?php
   use function Laravel\Folio\name;
   use App\Models\Organization;
   name('console-settings-index');

   use function Livewire\Volt\{state, mount, rules, uses, updated};
   use App\Livewire\Actions\ToastUp;

   updated([
   'organization._colors.brand_color' => function (){
      $background = ao($this->organization->_colors, 'brand_color');
      $color = getContrastColor($background);
      $this->js("window.updateOrgColor('$background', '$color');");
   },
   
   'organization.settings.enable_lang' => function() {

      if(ao($this->organization->settings, 'enable_lang')){
         $this->js('
            const el = document.querySelector(".header-laguages");

            if(el){
               el.classList.remove("hidden");
            }
         ');
      }else{
         $this->js('
            const el = document.querySelector(".header-laguages");

            if(el){
               el.classList.add("hidden");
            }
         ');
      }
   }]);

   
   state([
      'organization' => null,
      'colors' => ['#ff5757', '#ff914d', '#ffde59', '#8c52ff', '#5271ff', '#c1ff72'],
   ]);

   mount(function(){
      $this->organization = request()->project;
   });


   rules(fn () => [
    
   ]);

   uses([ToastUp::class]);

   $save = function(){

      //dd($this->organization);

      $this->organization->save();
      $this->js('document.querySelector(".header-laguages").remove();');

      $this->flashToast('success', __('Changes saved successfully'));

      //return $this->redirect(route('build-settings-index'), navigate: true);
   };
?>
<x-layouts.app>
   <x-slot:title>{{ __('Settings') }}</x-slot>

   @volt
   <div>

      <div class="mx-auto flex h-full w-full max-w-[1400px]">
         
         @include('_include.settings.settings-menu', ['current' => 'org'])
         
         <div class="flex flex-1 py-10 ps-[344px]">
            <form class="flex w-full flex-col" wire:submit="save">
               <div class="flex w-full flex-row items-center justify-between ">
                  <div class="text-lg font-semibold">{{ __('Organization settings') }}</div>
                  <div class="flex flex-row gap-2">
                     <button class="z-0 group relative inline-flex items-center justify-center box-border appearance-none select-none whitespace-nowrap font-normal subpixel-antialiased overflow-hidden tap-highlight-transparent outline-none data-[focus-visible=true]:z-10 data-[focus-visible=true]:outline-2 data-[focus-visible=true]:outline-focus data-[focus-visible=true]:outline-offset-2 px-unit-3 min-w-unit-16 h-unit-8 text-tiny gap-unit-2 rounded-small [&amp;>svg]:max-w-[theme(spacing.unit-8)] data-[pressed=true]:scale-[0.97] transition-transform-colors motion-reduce:transition-none bg-primary text-primary-foreground" type="submit">{{ __('Save Changes') }}</button>
                  </div>
               </div>
               <div class="mt-0 flex flex-col gap-8">
                  <div class="flex flex-row gap-16 py-10">
                     <div class="flex w-full flex-col gap-8">
                        <div class="relative text-sm text-left"><pre style="display: block; overflow-x: auto; background: rgb(43, 43, 43); color: rgb(248, 248, 242); padding: 2rem; border-radius: 8px;"><code class="language-html" style="white-space: pre-wrap;"><span><span>&lt;script src="https://www.feedbase.co/widget/v1.js" data-widget="2e1ea2f0-5efa-415a-b87d-3a54ce6cb306"&gt;&lt;/script&gt;</span></span></code></pre><button class="flex items-center justify-center absolute top-2 right-2 w-8 h-8 rounded-md bg-white/90"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path></svg></button></div>
                         <div class="flex flex-col"><span class="text-small text-content-primary mb-2">Logo</span>
                             <div class="bg-background-neutral-subtle flex flex-row items-center justify-between rounded-lg p-2">
                                 <div class="flex flex-row items-center justify-center rounded-lg h-16 w-16"
                                     style="background: rgb(247, 144, 9);"><span class="text-content-onBrand text-xl">I</span></div>
                                 <div class="flex flex-row items-center gap-2"><button
                                         class="z-0 group relative inline-flex items-center justify-center box-border appearance-none select-none whitespace-nowrap font-normal subpixel-antialiased overflow-hidden tap-highlight-transparent outline-none data-[focus-visible=true]:z-10 data-[focus-visible=true]:outline-2 data-[focus-visible=true]:outline-focus data-[focus-visible=true]:outline-offset-2 px-unit-3 min-w-unit-16 h-unit-8 text-tiny gap-unit-2 rounded-small [&amp;>svg]:max-w-[theme(spacing.unit-8)] data-[pressed=true]:scale-[0.97] transition-transform-colors motion-reduce:transition-none bg-primary text-primary-foreground"
                                         type="button">Upload</button><input type="file" id="file-input" class="hidden"></div>
                             </div>
                         </div>
                         <div class="flex flex-col gap-1"><span class="text-sm font-semibold">Favicon</span>
                             <div class="bg-background-neutral-subtle flex flex-row items-center justify-between rounded-lg p-2">
                                 <div class="flex flex-row items-center justify-center rounded-lg h-8 w-8"
                                     style="background: rgb(247, 144, 9);"><span class="text-content-onBrand text-xs">I</span></div>
                                 <div class="flex flex-row items-center gap-2"><button
                                         class="z-0 group relative inline-flex items-center justify-center box-border appearance-none select-none whitespace-nowrap font-normal subpixel-antialiased overflow-hidden tap-highlight-transparent outline-none data-[focus-visible=true]:z-10 data-[focus-visible=true]:outline-2 data-[focus-visible=true]:outline-focus data-[focus-visible=true]:outline-offset-2 px-unit-3 min-w-unit-16 h-unit-8 text-tiny gap-unit-2 rounded-small [&amp;>svg]:max-w-[theme(spacing.unit-8)] data-[pressed=true]:scale-[0.97] transition-transform-colors motion-reduce:transition-none bg-primary text-primary-foreground"
                                         type="button">Upload</button><input type="file" id="favicon-input" class="hidden"></div>
                             </div>
                         </div>
                         <div class="flex flex-col"><span class="text-small text-content-primary mb-1 font-semibold">Organization
                                 name</span>
                             <div class="group flex flex-col data-[has-helper=true]:pb-4 w-full group relative justify-end is-filled"
                                 data-filled="true" data-filled-within="true">
                                 <div class="h-full flex flex-col">
                                     <div class="relative w-full inline-flex tap-highlight-transparent flex-row items-center shadow-sm px-3 gap-3 bg-default-100 data-[hover=true]:bg-default-200 group-data-[focus=true]:bg-default-100 h-unit-10 min-h-unit-10 rounded-medium transition-background motion-reduce:transition-none !duration-150 outline-none group-data-[focus-visible=true]:z-10 group-data-[focus-visible=true]:ring-2 group-data-[focus-visible=true]:ring-focus group-data-[focus-visible=true]:ring-offset-2 group-data-[focus-visible=true]:ring-offset-background is-filled"
                                         style="cursor: text;"><input
                                             class="w-full h-full font-normal !bg-transparent outline-none placeholder:text-foreground-500 text-small is-filled"
                                             aria-label=" " type="text" id="react-aria79072641-:rk9:" value="ithjeff" data-filled="true"
                                             data-filled-within="true"></div>
                                 </div>
                             </div>
                         </div>
                         <div class="relative flex flex-col">
                             <div class="flex flex-row justify-between"><span
                                     class="text-small text-content-primary mb-1 font-semibold">Organization domain</span>
                                 <div class="flex flex-row items-center gap-1"><span class="text-content-secondary text-xs">Valid</span>
                                     <div class="flex h-4 w-4 items-center justify-center rounded-full bg-content-positive" style=""><svg
                                             stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24"
                                             stroke-linecap="round" stroke-linejoin="round"
                                             class="text-content-positive-onSurface text-sm" height="1em" width="1em"
                                             xmlns="http://www.w3.org/2000/svg">
                                             <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                             <path d="M5 12l5 5l10 -10"></path>
                                         </svg></div>
                                 </div>
                             </div>
                             <div class="group flex flex-col data-[has-helper=true]:pb-4 w-full group relative justify-end is-filled"
                                 data-filled="true" data-filled-within="true">
                                 <div class="h-full flex flex-col">
                                     <div class="relative w-full inline-flex tap-highlight-transparent flex-row items-center shadow-sm px-3 gap-3 bg-default-100 data-[hover=true]:bg-default-200 group-data-[focus=true]:bg-default-100 h-unit-10 min-h-unit-10 rounded-medium transition-background motion-reduce:transition-none !duration-150 outline-none group-data-[focus-visible=true]:z-10 group-data-[focus-visible=true]:ring-2 group-data-[focus-visible=true]:ring-focus group-data-[focus-visible=true]:ring-offset-2 group-data-[focus-visible=true]:ring-offset-background is-filled"
                                         style="cursor: text;"><input
                                             class="w-full h-full font-normal !bg-transparent outline-none placeholder:text-foreground-500 text-small is-filled"
                                             aria-label=" " type="text" id="react-aria79072641-:rke:" value="withjeff" data-filled="true"
                                             data-filled-within="true"></div>
                                 </div>
                             </div>
                             <div class="py-2 ps-1"><span class="text-content-brand-onSurface cursor-pointer select-none text-sm">Add
                                     custom domain</span></div><span
                                 class="text-content-secondary absolute right-4 top-[34px] z-10 select-none text-sm">.doocs.app</span>
                         </div>
                         <div class="flex flex-col gap-4"><span class="text-small text-content-primary mb-1 font-semibold">Call to
                                 action</span>
                             <div class="flex flex-col"><span class="text-small text-content-primary mb-1 font-semibold">Link</span>
                                 <div class="group flex flex-col data-[has-helper=true]:pb-4 w-full group relative justify-end is-filled"
                                     data-filled="true" data-filled-within="true">
                                     <div class="h-full flex flex-col">
                                         <div class="relative w-full inline-flex tap-highlight-transparent flex-row items-center shadow-sm px-3 gap-3 bg-default-100 data-[hover=true]:bg-default-200 group-data-[focus=true]:bg-default-100 h-unit-10 min-h-unit-10 rounded-medium transition-background motion-reduce:transition-none !duration-150 outline-none group-data-[focus-visible=true]:z-10 group-data-[focus-visible=true]:ring-2 group-data-[focus-visible=true]:ring-focus group-data-[focus-visible=true]:ring-offset-2 group-data-[focus-visible=true]:ring-offset-background is-filled"
                                             style="cursor: text;"><input
                                                 class="w-full h-full font-normal !bg-transparent outline-none placeholder:text-foreground-500 text-small is-filled"
                                                 aria-label=" " type="text" id="react-aria79072641-:rkj:" value="https://google.com"
                                                 data-filled="true" data-filled-within="true"></div>
                                     </div>
                                 </div>
                             </div>
                             <div class="flex flex-col"><span class="text-small text-content-primary mb-1 font-semibold">Label</span>
                                 <div class="group flex flex-col data-[has-helper=true]:pb-4 w-full group relative justify-end is-filled"
                                     data-filled="true" data-filled-within="true">
                                     <div class="h-full flex flex-col">
                                         <div class="relative w-full inline-flex tap-highlight-transparent flex-row items-center shadow-sm px-3 gap-3 bg-default-100 data-[hover=true]:bg-default-200 group-data-[focus=true]:bg-default-100 h-unit-10 min-h-unit-10 rounded-medium transition-background motion-reduce:transition-none !duration-150 outline-none group-data-[focus-visible=true]:z-10 group-data-[focus-visible=true]:ring-2 group-data-[focus-visible=true]:ring-focus group-data-[focus-visible=true]:ring-offset-2 group-data-[focus-visible=true]:ring-offset-background is-filled"
                                             style="cursor: text;"><input
                                                 class="w-full h-full font-normal !bg-transparent outline-none placeholder:text-foreground-500 text-small is-filled"
                                                 aria-label=" " type="text" id="react-aria79072641-:rko:" value="Go to Withjeff"
                                                 data-filled="true" data-filled-within="true"></div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                         <div class="flex flex-col">
                             <div class="mb-1 flex flex-row justify-between">
                              <span class="text-small text-content-primary font-semibold">{{ __('Brand color') }}</span></div>
                             <div class="bg-background-neutral-subtle flex flex-row items-center gap-2 rounded-md px-4 py-3 opacity-50--">
                                 @foreach ($colors as $item)
                                    <div class="h-6 w-6 rounded-full cursor-pointer" style="background: {{ $item }}" wire:click="$set('organization._colors.brand_color', '{{ $item }}')"></div>
                                 @endforeach
                                 
                                 <div class="border-border-divider box-border rounded-full p-1 relative">
                                    
                                    <i class="fi fi-ss-plus-small text-lg"></i>
                                    <div class="absolute left-0 top-0 right-0 bottom-0 cursor-pointer">
                                       <input type="color" class="opacity-0 w-full h-full cursor-pointer" wire:model="organization._colors.brand_color" wire:change="$set('organization._colors.brand_color', $event.target.value)">
                                    </div>
                                 </div>
                             </div>
                         </div>
                         <div class=" flex flex-col gap-2">
                           
                           <span class="text-small text-content-primary mb-1 font-semibold">{{ __('Others') }}</span>


                           <div class="bg-background-neutral-subtle flex items-center gap-2 rounded-lg p-3">
                              {!! __icon('interface-essential', 'language-translate copy', 'w-5 h-5') !!}
                              <span class="text-content-primary flex-1 text-sm font-semibold">{{ __('Enable multiple languages') }}</span>
                              
                              <x-yena.checkbox wire:model.live="organization.settings.enable_lang"></x-yena.checkbox>
                           </div>
                             <div class="bg-background-neutral-subtle flex items-center gap-2 rounded-lg p-3"><svg stroke="currentColor"
                                     fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round"
                                     class="text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                     <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                     <path d="M3 5m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v10a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z"></path>
                                     <path d="M6 8h.01"></path>
                                     <path d="M9 8h.01"></path>
                                 </svg><span class="text-content-primary flex-1 text-sm font-semibold">Enable spaces</span><label
                                     class="group relative max-w-fit inline-flex items-center justify-start cursor-pointer touch-none tap-highlight-transparent -me-2"
                                     data-selected="true">
                                     <div
                                         style="border: 0px; clip: rect(0px, 0px, 0px, 0px); clip-path: inset(50%); height: 1px; margin: -1px; overflow: hidden; padding: 0px; position: absolute; width: 1px; white-space: nowrap;">
                                         <input aria-labelledby=":rku:" type="checkbox" role="switch" value=""></div><span
                                         aria-hidden="true"
                                         class="px-1 relative inline-flex items-center justify-start flex-shrink-0 overflow-hidden bg-default-200 rounded-full outline-none group-data-[focus-visible=true]:z-10 group-data-[focus-visible=true]:ring-2 group-data-[focus-visible=true]:ring-focus group-data-[focus-visible=true]:ring-offset-2 group-data-[focus-visible=true]:ring-offset-background group-data-[selected=true]:bg-primary group-data-[selected=true]:text-primary-foreground w-10 h-6 mr-2 transition-background"><span
                                             class="z-10 flex items-center justify-center bg-white shadow-small rounded-full origin-right w-4 h-4 text-tiny group-data-[selected=true]:ml-4 transition-all group-data-[pressed=true]:w-5 group-data-[selected]:group-data-[pressed]:ml-3"></span></span>
                                 </label></div>
                         </div>
                         <div class="flex flex-col gap-1"><span class="text-small font-semibold">Delete organization</span><button
                                 class="z-0 group relative inline-flex items-center justify-center box-border appearance-none select-none whitespace-nowrap font-normal subpixel-antialiased overflow-hidden tap-highlight-transparent outline-none data-[focus-visible=true]:z-10 data-[focus-visible=true]:outline-2 data-[focus-visible=true]:outline-focus data-[focus-visible=true]:outline-offset-2 border-medium px-unit-4 min-w-unit-20 h-unit-10 text-small gap-unit-2 rounded-medium [&amp;>svg]:max-w-[theme(spacing.unit-8)] data-[pressed=true]:scale-[0.97] transition-transform-colors motion-reduce:transition-none bg-transparent border-border-negative text-content-negative"
                                 type="button">Delete organization</button></div>
                     </div>
                     <div class="flex flex-1 flex-col gap-10">
                         <div class="flex flex-col gap-1"><span class="text-sm font-semibold">Preview</span>
                             <div class="relative rounded-lg"><span
                                     class="text-small text-content-primary absolute left-[128px] top-[12px]">withjeff</span><span
                                     class="text-small text-content-tertiary  absolute right-[126px] top-[12px]">.doocs.app</span>
                                 <div
                                     class="absolute left-[40px] top-[76px] flex translate-x-[-50%] translate-y-[-50%] transform flex-row items-center ">
                                     <div class="flex flex-row items-center justify-center rounded-lg h-8 w-8"
                                         style="background: rgb(247, 144, 9);"><span class="text-content-onBrand text-xs">I</span></div>
                                 </div>
                                 <div
                                     class="absolute left-[216px] top-[76px] flex w-[300px] max-w-[400px] translate-x-[-50%] translate-y-[-50%] transform flex-row items-center ">
                                     <span class="text-small text-left font-semibold">ithjeff</span></div>
                                 <div
                                     class="bg-background-neutral-subtle absolute right-[24px] top-[60px] flex h-8 flex-row items-center rounded-md px-3 py-2">
                                     <span class="text-small text-content-secondary text-left font-semibold">Go to Withjeff</span></div>
                                 <svg width="608" height="280" viewBox="0 0 608 280" fill="none" xmlns="http://www.w3.org/2000/svg">
                                     <rect width="608" height="280" rx="16" class="fill-global-gray-100 dark:fill-global-dark-gray-100">
                                     </rect>
                                     <path d="M0 8C0 3.58172 3.58172 0 8 0H600C604.418 0 608 3.58172 608 8V44H0V8Z"
                                         class="fill-global-gray-100 dark:fill-global-dark-gray-100"></path>
                                     <path
                                         d="M543 29C543.527 29 543.953 28.5723 543.953 28.087V22.9377H549.055C549.565 22.9377 550 22.5182 550 22C550 21.49 549.565 21.0623 549.055 21.0623H543.953V15.913C543.953 15.4195 543.527 15 543 15C542.481 15 542.047 15.4195 542.047 15.913V21.0623H536.945C536.452 21.0623 536 21.49 536 22C536 22.5182 536.452 22.9377 536.945 22.9377H542.047V28.087C542.047 28.5723 542.481 29 543 29Z"
                                         class="fill-global-gray-400 dark:fill-global-dark-gray-600"></path>
                                     <path
                                         d="M573.728 27.0349H575.137V28.2868C575.137 30.0611 576.074 30.9897 577.865 30.9897H586.272C588.063 30.9897 589 30.0611 589 28.2868V19.8216C589 18.0473 588.063 17.1187 586.272 17.1187H584.863V15.875C584.863 14.1007 583.926 13.1721 582.135 13.1721H573.728C571.929 13.1721 571 14.1007 571 15.875V24.332C571 26.1145 571.929 27.0349 573.728 27.0349ZM573.836 25.3849C573.073 25.3849 572.65 24.987 572.65 24.1827V16.0243C572.65 15.22 573.073 14.8303 573.836 14.8303H582.027C582.782 14.8303 583.213 15.22 583.213 16.0243V17.1187H577.865C576.074 17.1187 575.137 18.0473 575.137 19.8216V25.3849H573.836ZM577.973 29.3315C577.21 29.3315 576.795 28.9335 576.795 28.1376V19.9708C576.795 19.1749 577.21 18.7769 577.973 18.7769H586.164C586.927 18.7769 587.35 19.1749 587.35 19.9708V28.1376C587.35 28.9335 586.927 29.3315 586.164 29.3315H577.973Z"
                                         class="fill-global-gray-400 dark:fill-global-dark-gray-600"></path>
                                     <g clip-path="url(#clip0_185_3069)">
                                         <circle cx="22" cy="22" r="6" fill="#ED6A5E"></circle>
                                         <circle cx="22" cy="22" r="5.5" stroke="black" stroke-opacity="0.1"></circle>
                                         <circle cx="42" cy="22" r="6" fill="#F4BD50"></circle>
                                         <circle cx="42" cy="22" r="5.5" stroke="black" stroke-opacity="0.1"></circle>
                                         <circle cx="62" cy="22" r="6" fill="#61C454"></circle>
                                         <circle cx="62" cy="22" r="5.5" stroke="black" stroke-opacity="0.1"></circle>
                                     </g>
                                     <rect x="104" y="10" width="400" height="24" rx="6"
                                         class="fill-global-gray-200 dark:fill-global-dark-gray-200"></rect>
                                     <path
                                         d="M116 28C116.106 28 116.266 27.9676 116.414 27.8919C119.818 26.2 121 25.4162 121 23.4486V19.3676C121 18.7189 120.722 18.4865 120.131 18.2541C119.475 18 117.271 17.2973 116.626 17.0973C116.431 17.0378 116.201 17 116 17C115.799 17 115.569 17.0486 115.374 17.0973C114.729 17.2649 112.525 18.0054 111.869 18.2541C111.278 18.4811 111 18.7189 111 19.3676V23.4486C111 25.4162 112.188 26.1892 115.58 27.8919C115.734 27.9676 115.894 28 116 28ZM116.319 18.0919C117.093 18.373 118.778 18.9189 119.664 19.2054C119.83 19.2649 119.871 19.3459 119.871 19.5405V23.2486C119.871 24.8324 119.002 25.2595 116.337 26.7297C116.171 26.8216 116.089 26.8541 116.006 26.8541V18.0324C116.089 18.0324 116.177 18.0486 116.319 18.0919Z"
                                         class="fill-global-gray-400 dark:fill-global-dark-gray-600"></path>
                                     <path
                                         d="M492.068 22.0645C492.238 22.0645 492.373 22.0117 492.479 21.9004L494.881 19.4805C495.01 19.3516 495.068 19.2109 495.068 19.0469C495.068 18.8887 495.004 18.7363 494.881 18.6191L492.479 16.1758C492.373 16.0586 492.238 16 492.068 16C491.752 16 491.5 16.2637 491.5 16.5859C491.5 16.7441 491.559 16.873 491.658 16.9844L493.059 18.3555C492.783 18.3145 492.502 18.291 492.221 18.291C489.32 18.291 487 20.6113 487 23.5176C487 26.4238 489.338 28.7617 492.238 28.7617C495.145 28.7617 497.477 26.4238 497.477 23.5176C497.477 23.166 497.23 22.9141 496.879 22.9141C496.539 22.9141 496.311 23.166 496.311 23.5176C496.311 25.7793 494.5 27.5957 492.238 27.5957C489.982 27.5957 488.166 25.7793 488.166 23.5176C488.166 21.2383 489.965 19.4336 492.221 19.4336C492.602 19.4336 492.953 19.4629 493.264 19.5156L491.664 21.0977C491.559 21.2031 491.5 21.332 491.5 21.4902C491.5 21.8125 491.752 22.0645 492.068 22.0645Z"
                                         class="fill-global-gray-400 dark:fill-global-dark-gray-600"></path>
                                     <rect x="8" y="44" width="592" height="228" rx="8"
                                         class="fill-global-gray-0 dark:fill-global-dark-gray-0"></rect>
                                     <rect x="180" y="112" width="164" height="12" rx="6"
                                         class="fill-global-gray-300 dark:fill-global-dark-gray-300"></rect>
                                     <rect x="180" y="128" width="93" height="8" rx="4"
                                         class="fill-global-gray-100 dark:fill-global-dark-gray-100"></rect>
                                     <rect x="180" y="152" width="316" height="80" rx="8"
                                         class="fill-global-gray-50 dark:fill-global-dark-gray-50"></rect>
                                     <rect x="24" y="112" width="120" height="24" rx="8"
                                         class="fill-global-gray-0 dark:fill-global-dark-gray-0"></rect>
                                     <rect x="32" y="120" width="54" height="8" rx="4"
                                         class="fill-global-gray-100 dark:fill-global-dark-gray-100"></rect>
                                     <rect x="24" y="136" width="120" height="24" rx="8" class="fill-background-brand-subtle"></rect>
                                     <rect x="24" y="160" width="120" height="24" rx="8"
                                         class="fill-global-gray-0 dark:fill-global-dark-gray-0"></rect>
                                     <rect x="24" y="184" width="120" height="24" rx="8"
                                         class="fill-global-gray-0 dark:fill-global-dark-gray-0"></rect>
                                     <rect x="24" y="208" width="120" height="24" rx="8"
                                         class="fill-global-gray-0 dark:fill-global-dark-gray-0"></rect>
                                     <rect x="24" y="232" width="120" height="24" rx="8"
                                         class="fill-global-gray-0 dark:fill-global-dark-gray-0"></rect>
                                     <rect x="32" y="144" width="72" height="8" rx="4" class="fill-background-brand"></rect>
                                     <rect x="32" y="168" width="45" height="8" rx="4"
                                         class="fill-global-gray-100 dark:fill-global-dark-gray-100"></rect>
                                     <rect x="32" y="192" width="66" height="8" rx="4"
                                         class="fill-global-gray-100 dark:fill-global-dark-gray-100"></rect>
                                     <rect x="32" y="216" width="78" height="8" rx="4"
                                         class="fill-global-gray-100 dark:fill-global-dark-gray-100"></rect>
                                     <rect x="32" y="240" width="54" height="8" rx="4"
                                         class="fill-global-gray-100 dark:fill-global-dark-gray-100"></rect>
                                     <defs>
                                         <clipPath id="clip0_185_3069">
                                             <rect width="52" height="12" class="fill-global-gray-0 dark:fill-global-dark-gray-0"
                                                 transform="translate(16 16)"></rect>
                                         </clipPath>
                                     </defs>
                                 </svg>
                             </div>
                         </div>
                     </div>
                 </div>
                 
               </div>
            </form>
         </div>
      </div>
      
   </div>
   @endvolt
</x-layouts.app>

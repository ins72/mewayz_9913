<div>
    
    <div class="--placeholder-skeleton w-[30%] h-[42px] rounded-[var(--yena-radii-sm)] mt-4"></div>
    <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-2"></div>
    <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-2"></div>

    <div class="flex items-center mt-8 gap-4">
        <div class="--placeholder-skeleton w-[230px] h-[240px] rounded-[var(--yena-radii-sm)]"></div>
        <div class="--placeholder-skeleton w-[230px] h-[240px] rounded-[var(--yena-radii-sm)]"></div>
    </div>
</div>
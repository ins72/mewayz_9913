<div class="p-5 w-[100%] mt-1">
    {{-- <div class="flex items-center mb-2 gap-2">
       <div class="--placeholder-skeleton w-[40px] h-[30px] rounded-sm"></div>
       <div class="--placeholder-skeleton w-[100%] h-[30px] rounded-sm"></div>
    </div> --}}
    <div class="--placeholder-skeleton w-[100%] h-[30px] rounded-sm"></div>
    <div class="--placeholder-skeleton w-[100%] h-[30px] rounded-sm mt-1"></div>
    <div class="--placeholder-skeleton w-[100%] h-[30px] rounded-sm mt-1"></div>
    <div class="grid grid-cols-2 mt-2 gap-4">
       <div class="--placeholder-skeleton w-[100%] h-[170px] rounded-sm"></div>
       <div class="--placeholder-skeleton w-[100%] h-[170px] rounded-sm"></div>
       {{-- <div class="--placeholder-skeleton w-[100%] h-[170px] rounded-sm"></div>
       <div class="--placeholder-skeleton w-[100%] h-[170px] rounded-sm"></div> --}}
    </div>
 </div>
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        @php
            $appName = config('app.name', 'Laravel');
        @endphp
        <title>{{ isset($title) ? "$appName - $title" : $appName }}</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">


        <!-- Scripts -->
        @vite([
            'resources/css/app.css',
            'resources/sass/app.scss',
            'resources/sass/console/console.sidebar.scss',
            'resources/sass/console/console.placeholder.scss',
            'resources/sass/site.scss',
            'resources/sass/create.scss',
            //'resources/sass/builder.scss',
            //'resources/sass/xcreate.scss',
            'resources/js/app.js'
        ])


        @livewireStyles
    </head>
    <body class="font-sans text-gray-900 antialiased bg-[var(--color-neutral-05)]">
        
        <div>
            <livewire:components.builder.layout.application :site="__s()" :key="uukey('builder', 'application')" lazy />
        </div>

        <script>
            var object = {
                mediaUrl: "{{ gs('media/site/images') }}",
                baseUrl: "{{ url('/') }}",
            };

            window.builderObject = object;
        </script>
        @livewireScriptConfig

        @vite([
         'resources/js/yenaWire.js'
        ])
    </body>
</html>

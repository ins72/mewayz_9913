@extends('mix::layouts.master')
@section('title', __('Pages'))
@section('content')

<script>
  function _pine(){
     return {
        create_modal: false,
        modals: [],

        openModal(id){
          var _this = this;
          if(!_this.$event.target.classList.contains('app-un')){
              this.modals[id] = true;
          }
        },

        closeModal(id){
          this.modals[id] = false;
        },

        isShownModal(id){
          if(this.modals[id]){
              return true;
          }

          return false;
        },
        init(){
          
        }
     }
  }
</script>

<div x-data="_pine">

  <div class="flex h-48 items-center">
    <div class="mx-auto w-full max-w-screen-xl px-5">
    
       <div class="mb-5 pb-5 border-b border-solid border-gray-300 pt-4">
        <div class="font-heading mb-2 px-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
          <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
          <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
        </div>
        <h1 class="text-zinc-500 text-5xl mb-2 font-bold">{{ __('All Pages') }}</h1>
  
        <div class="mt-3 flex items-center">
          <a class="bg-primary overflow-hidden rounded-lg p-1 px-5 text-white --control cursor-pointer" @click="create_modal=true">
              <div class="flex h-full items-center">
                  <div class="px-2 py-0.5 text-sm font-medium">{{ __('Create new') }}</div>
              </div>
          </a>
          
          <div class="flex z-menuc ml-3 hidden" data-max-width="600" data-handle=".--control">
            <a class="bg-white overflow-hidden rounded-lg p-1 px-2 text-black --control cursor-pointer border" aria-expanded="false">
                <div class="flex h-full items-center">
                    <div class="px-2 py-0.5 text-sm font-medium"><i class="fi fi-rr-filter"></i></div>
                </div>
            </a>
  
            <div class="z-menuc-content-temp">
                <ul class="z-menu-ul w-40em max-w-full shadow-lg border border-solid border-gray-200 rounded-xl">
                    <div class="p-6">
                        <div class="w-full">
                          <div class="flex w-full items-center justify-between">
                              <div class="flex-grow">
                                <h4 class="text-lg font-medium">{{ __('Filter') }}</h4>
                              </div>
                              <button type="button" class="-mt-1 rounded-md p-1 text-gray-500 hover:bg-zinc-50 z-menu-close" tabindex="0">
                                <i class="fi fi-rr-cross"></i>
                              </button>
                          </div>
                        </div>
  
                        <div class="border-b border-solid border-gray-300 my-3"></div>
                        
                        @includeIf('admin.users.filter')
                    </div>
                </ul>
            </div>
        </div>
        </div>
       </div>
    </div>
  </div>



  <div x-show="create_modal" x-cloak x-transition.opacity.duration.500ms="" class="alpine-dialog-modal">

    <div class="-alpine-modal-overflow" x-on:click="create_modal = false"></div>
    <div class="-alpine-dialog h-full w-full transform overflow-hidden bg-white text-left align-bottom shadow-xl sm:w-full sm:max-w-lg top-0 right-0 left-auto" x-show="create_modal !== false">
       <div>
        <div class="h-full overflow-y-auto">
          <div class="relative flex h-32 flex-col justify-end overflow-hidden bg-gray-100 p-6">
             <div class="absolute inset-0"></div>
             <div class="absolute inset-0 bg-gradient-to-tr from-gray-100 to-gray-100/0"></div>
             <div class="absolute right-4 top-4" x-on:click="create_modal = false">
                <button class="rounded-md p-1 text-gray-600 hover:bg-gray-200">
                   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" fill="none" style="" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                   </svg>
                </button>
             </div>
             <div class="font-heading mb-2 pr-2 font--12 font-extrabold uppercase tracking-wider text-gray-700 flex items-center mb-2">
              <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
              <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
            </div>
             <div class="relative">
                <h1 class="text-xl font-bold">{{ __('Create Page') }}</h1>
             </div>
          </div>
          <form action="{{ route('console-admin-pages-post', 'create') }}" class="px-6 pb-6 pt-4" method="POST" x-data="{address: ''}">
            @csrf
            <div class="field field_icon">
                <div class="field__wrap">
                    <input type="text" name="address" placeholder="{{ __('type your address') }}" x-model.debounce.800ms="address" class="field__input ring-0">
                    <i class="fi fi-rr-at icon"></i>
                </div>
                <div class="field__label">{{ config('app.url') }}/<span x-text="address"></span></div>
            </div>
            <div class="field field_icon">
                <div class="field__wrap">
                    <input type="text" name="name" class="field__input ring-0">
                    <i class="fi fi-rr-user icon"></i>
                </div>
                <div class="field__label">{{ __('Page name') }}</div>
            </div>

            <div class="form-input mt-4">
              <label class="initial">{{ __('Owner') }}</label>
              <select name="user_id">
                @foreach (\App\User::get() as $user)
                   <option value="{{ $user->id }}">{{ $user->name }}</option>
                @endforeach
              </select>
            </div>
            
            <button type="submit" class="hover:shadow-primary-600/20 bg-black text-white duration-200 hover:scale-[1.02] hover:shadow-xl active:scale-[0.98] disabled:opacity-80 mt-4 w-full block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-4 py-2.5">
              <div class="relative flex items-center justify-center ">
                 <div class="duration-100 undefined false">{{ __('Save') }}</div>
              </div>
           </button>
          </form>
        </div>
       </div>
       
      
    </div>
  </div>
  

<div class="mx-auto w-full max-w-screen-xl px-2.5 pb-10 pt-0">

  <div class="page-trans bg-gray-200">

    
    <ul class="col-span-1 grid auto-rows-min grid-cols-1 gap-3 lg:col-span-5">
      @foreach ($pages as $key => $item)
     <div class="border-gray-50 relative rounded-lg border-2 bg-white p-3 pr-1 shadow-lg transition-all hover:shadow-md sm:p-4">
        <li class="relative flex items-center justify-between">
           <div class="relative flex shrink items-center">
              <img alt=" " class="h-8 w-8 rounded-full sm:h-10 sm:w-10 blur-0" src="{{ $item->getLogo() }}" width="20" height="20">
              <div class="ml-2 sm:ml-4">
                 <div class="flex max-w-fit items-center space-x-2">
                    <a class="w-24 truncate text-sm font-semibold text-blue-800 sm:w-full sm:text-base" href="{{-- route('dashboard-pixel-edit',['_pixel_id'=>$item->pixel]) --}}">{{ $item->name }}</a>

                    

                    <div class="flex items-center z-menuc" data-max-width="400" data-placement="bottom" data-wire-updates="" data-appends-to=".--appended" wire:ignore.self data-handle=".--control">
   
   
                       <div>
                          <button type="button" class="group rounded-full bg-gray-100 p-1.5 transition-all duration-75 hover:scale-105 hover:bg-blue-100 active:scale-95 ml-2 --control">
                             <span class="sr-only">{{ __('Copy') }}</span>
                             <i class="fi fi-rr-copy text-gray-700 transition-all group-hover:text-blue-800 text-sm"></i>
                          </button>
                       </div>
   
                       
         
                       <div class="--appended" wire:ignore></div>
   
                       <div class="z-menuc-content-temp" wire:ignore.self>
                        <div class="connect__col bg-white p-5 rounded-lg w-full">
                           <form wire:submit.prevent="duplicate_page({{ $item->id }})" autocomplete="off" class="connect__message">
           
                              <a class="logo mb-5">
                               <img src="{{ mix_logo() }}" class="w-10 h-10">
                              </a>
                              
                              <div class="connect__subtitle h3 text-2xl font-bold mb-0">{{ __('Duplicate Page') }}</div>
                               <div class="connect__content hidden"></div>
                               
           
                                                     
                                
                               <button class="old-button button-stroke-black button-wide mt-5" wire:loading.attr="disabled">{{ __('Continue') }}</button>
                           </form>
                       </div>
                       </div>
                    </div>
                    <a class="flex items-center space-x-1 rounded-md bg-gray-100 px-2 py-0.5 transition-all duration-75 hover:scale-105 active:scale-100 ml-2">
                       <i class="fi fi-rr-apps-add text-gray-700 text-sm mr-1"></i>

                       
                       <p class="whitespace-nowrap text-sm text-gray-500">{{ number_format($item->layouts()->count()) }}<span class="ml-1 hidden sm:inline-block">{{ __('sections') }}</span></p>
                    </a>
                    <a class="flex items-center space-x-1 rounded-md bg-gray-100 px-2 py-0.5 transition-all duration-75 hover:scale-105 active:scale-100 ml-2" href="{{ route('console-admin-pages-view-report', ['_id' => $item->id]) }}">
                        {!! orion('warning-1', 'stroke-current w-4 h-4 mr-1') !!}

                       
                       <p class="whitespace-nowrap text-sm text-gray-500">{{ number_format($item->reports()->count()) }}<span class="ml-1 hidden sm:inline-block">{{ __('reports') }}</span></p>
                    </a>
                 </div>

                 <h3 class="max-w-[200px] truncate text-sm font-medium text-gray-700 md:max-w-md xl:max-w-lg">{{ '@' . $item->address }}</h3>
                 @if ($user = $item->user)
                 <a href="{{ route('console-admin-users-index', ['query' => $user->email, 'search_by' => 'email']) }}" class="leo-avatar-o bg-white rounded-full">
                    <div class="-avatar-inner bg-gray-100 px-2">
                       <div class="--avatar p-0 h-5 w-5 rounded-full">
                          <img alt=" " class="blur-0 " src="{{ avatar($user->id) }}">
                       </div>

                       <div class="-content">
                          <div>
                                <div class="--name text-black">{{ $user->name }}</div>
                          </div>
                       </div>

                       <div class="flex items-center ml-2">
                          <div class="menu--icon bg-black rounded-full">
                              <i class="fi fi-rr-angle-small-right text-xs text-white"></i>
                          </div>
                       </div>
                    </div>
                 </a>
                 @endif
              </div>
           </div>

           <div class="flex items-center z-menuc" data-max-width="400" data-placement="left-end" data-appends-to=".--appended" wire:ignore.self data-handle=".--control">
              <p class="mr-3 hidden whitespace-nowrap text-sm text-gray-500 sm:block">{{ \Carbon\Carbon::parse($item->created_at)->diffForHumans() }}</p>
              <p class="mr-1 whitespace-nowrap text-sm text-gray-500 sm:hidden">{{ \Carbon\Carbon::now()->diffInDays(\Carbon\Carbon::parse($item->created_at)) }}d</p>


              <div>
                 <button type="button" class="rounded-md px-1 py-2 transition-all duration-75 hover:bg-gray-100 active:bg-gray-200 --control">
                    <i class="fi fi-rr-menu-dots-vertical flex text-base text-gray-500"></i>
                 </button>
              </div>

              

              <div class="--appended" wire:ignore></div>

              <div class="z-menuc-content-temp" wire:ignore.self>
                  <ul class="grid w-full gap-1 p-5 sm:w-48">
                      <a class="group flex w-full items-center justify-between rounded-md p-2 text-left text-sm font-medium text-gray-500 transition-all duration-75 hover:bg-gray-100 cursor-pointer" href="{{ route('page-builder', ['__page_slug' => $item->_slug]) }}">
                          <div class="flex items-center justify-start space-x-2">
                              <i class="fi fi-rr-paint-brush text-sm"></i>
                             <p class="text-sm">{{ __('Edit') }}</p>
                          </div>
                      </a>
                      <a href="{{-- route('dashboard-pixel-track',['_pixel_id'=>$item->pixel]) --}}" class="group flex w-full items-center justify-between rounded-md p-2 text-left text-sm font-medium text-gray-500 transition-all duration-75 hover:bg-gray-100 hidden">
                          <div class="flex items-center justify-start space-x-2">
                              <i class="fi fi-rr-chart-pie text-sm"></i>
                             <p class="text-sm">{{ __('View usage') }}</p>
                          </div>
                      </a>
                      
                       <x-parts.--delete data-wire-updates>
                             <x-slot name="content">{{ __('Are you sure you want to delete this? This action is irreversible.') }}</x-slot>

                             <x-slot name="handle">
                             <a class="group flex w-full items-center  justify-between rounded-md p-2 text-left text-sm font-medium  text-red-600 transition-all duration-75 hover:bg-red-600  hover:text-white --open-delete cursor-pointer">
                                <div class="flex items-center justify-start space-x-2">
                                   <i class="fi fi-rr-trash text-sm"></i>
                                   <p class="text-sm">{{ __('Delete') }}</p>
                                </div>
                             </a>
                             </x-slot>

                             <x-slot name="form">
                                <form action="{{ route('console-admin-pages-post', 'delete') }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="_page" value="{{ $item->id }}">
                                   <button type="submit" class="first-letter: bg-red-500  text-white disabled:opacity-75 hover:bg-red-400
                                         block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-3 py-1.5">
                                         <div class="relative flex items-center justify-center ">
                                            <div class="duration-100">{{ __('Delete') }}</div>
                                         </div>
                                   </button>
                                </form>
                             </x-slot>
                       </x-parts.--delete>
                  </ul>
              </div>
           </div>
        </li>
     </div>
     @endforeach
  </ul>
    {{ $pages->links() }}
  </div>
</div>

  @foreach ($pages as $item)
    <div>
      <div x-cloak x-show="isShownModal('user-' + {{ $item->id }})" x-transition.opacity.duration.500ms class="alpine-dialog-modal">
        <div class="-alpine-modal-overflow" x-on:click="closeModal('user-' + {{ $item->id }})"></div>
        <div class="-alpine-dialog h-full w-full transform overflow-auto bg-white text-left align-bottom shadow-xl sm:w-full sm:max-w-lg top-0 right-0 left-auto --no-pop" x-show="isShownModal('user-' + {{ $item->id }})" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform scale-90" x-transition:enter-end="opacity-100 transform scale-100" x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100 transform scale-100" x-transition:leave-end="opacity-0 transform scale-90">
            <div>
              @includeIf('admin.users.edit', ['_user' => $item])
            </div>
        </div>
      </div>
  </div>
  @endforeach
</div>
@endsection

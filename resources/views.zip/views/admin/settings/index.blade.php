@extends('mix::layouts.master')
@section('title', __('Settings'))
@section('content')

<script>
  function pine(){
    return {

      clicked_menu(){
        var _this = this;
        //_this.$root.querySelector('.sandy-tabs-link').classList.remove('active');
        //_this.$event.currentTarget.classList.add('bg-zinc-200/70');
      },

      init(){
        var _this = this;

        
        _this.$root.querySelectorAll('.sandy-tabs-link').forEach(element => {

          element.addEventListener('click', function(e){
            _this.$root.querySelectorAll('.sandy-tabs-link').forEach(box => {
              box.classList.remove("bg-zinc-200/70");
            });
            
            
            e.currentTarget.classList.add('bg-zinc-200/70');
          });
        });

      }
    }
  }
</script>
<style>
  @media(min-width: 992px){
    .min-sid{
      width: 15em !important;
    }
  }
</style>

<form method="post" action="{{ route('console-admin-settings-post', ['tree' => 'post']) }}" class="h-full pb-16 pt-8 sm:pt-10 sandy-tabs" enctype="multipart/form-data" x-data="pine">
  @csrf
  <div class="mx-auto w-full max-w-screen-xl px-5">
    
    <div class="mb-5 pb-5 border-b border-solid border-gray-300 pt-4">

     <div class="font-heading mb-2 px-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
       <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
       <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
     </div>
     
     <h1 class="text-zinc-500 text-5xl mb-2 font-bold">{{ __('Settings') }}</h1>
    </div>
 </div>
  
  <div class="mx-auto w-full max-w-screen-xl px-0 md:px-0 pb-10 pt-8 flex flex-col lg:flex-row lg:space-x-6 mb-10">

    <div class="block">
      <div class="sticky top-0 shadow-none rounded-none lg:p-5 min-sid -lg:border-r border-gray-300 w-full">
        <div class="font-heading mb-6 px-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
          <span class="whitespace-nowrap">{{ __('Menu') }}</span>
          <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
        </div>
        <div class="flex flex-row lg:flex-col overflow-x-auto whitespace-nowrap gap-2">
          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link active">
            <span>{{ __('Application') }}</span>
          </a>

          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link">
            <div class="sidebar__text">{{ __('Payments') }}</div>
          </a>

          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link hidden">
            <div class="sidebar__text">{{ __('Invoice') }}</div>
          </a>

          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link">
            <div class="sidebar__text">{{ __('Social Login') }}</div>
          </a>

          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link">
            <div class="sidebar__text">{{ __('Invoice') }}</div>
          </a>

          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link">
            <div class="sidebar__text">{{ __('Captcha') }}</div>
          </a>

          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link">
            <div class="sidebar__text">{{ __('Smtp') }}</div>
          </a>

          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link">
            <div class="sidebar__text">{{ __('Affiliate') }}</div>
          </a>

          <a class="relative cursor-pointer flex mb-[1px] items-center gap-3 rounded-md px-2 py-[5px] text-left text-sm font-medium text-zinc-600 duration-100 hover:bg-zinc-200/70 sandy-tabs-link">
            <div class="sidebar__text">{{ __('Pwa') }}</div>
          </a>
        </div>
        
        <div class="mt-3 flex items-center w-full">
                
          <button class="sandy-button --control" aria-expanded="false">
            <div class="--sandy-button-container">
                <span>{{ __('Save') }}</span>
            </div>
          </button>
        </div>
     </div>
    </div>

    <div class="w-full">
      <div>

        <div class="sandy-tabs-body mt-6 lg:mt-0 px-0">
          <div class="sandy-tabs-item" id="general-tab">
            @includeIf('admin.settings.sections.app')
          </div>
          <div class="sandy-tabs-item" id="payments-tab">
            @includeIf('admin.settings.sections.payments')
          </div>
          <div class="sandy-tabs-item" id="invoice-tab">
            @includeIf('admin.settings.sections.invoice')
          </div>
          <div class="sandy-tabs-item" id="signin-tab">
            @includeIf('admin.settings.sections.social_login')
          </div>
          <div class="sandy-tabs-item" id="invoice-tab">
            @includeIf('admin.settings.sections.invoice')
          </div>
          <div class="sandy-tabs-item" id="captcha-tab">
            @includeIf('admin.settings.sections.captcha')
          </div>
          <div class="sandy-tabs-item" id="smtp-tab">
            @includeIf('admin.settings.sections.smtp')
          </div>
          <div class="sandy-tabs-item" id="affiliate-tab">
            @includeIf('admin.settings.sections.affiliate')
          </div>
          <div class="sandy-tabs-item" id="pwa-tab">
            @includeIf('admin.settings.sections.pwa')
          </div>
        </div>
      </div>
    </div>
  </div>

</form>
@endsection

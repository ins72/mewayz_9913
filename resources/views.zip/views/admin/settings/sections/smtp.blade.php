<div class="p-6 shadow-none border border-gray-300 mt-0 rounded-none">
  <div class="font-heading mb-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-5">
     <span class="whitespace-nowrap">{{ __('SMTP') }}</span>
     <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
  </div>
  <div class="form-input">
    <label>{{ __('Mailer') }}</label>
    <input type="text" name="env[MAIL_MAILER]" value="{{ config('app.MAIL_MAILER') }}">
  </div>

  <div class="font-heading my-6 pr-2 text-zinc-400 flex items-center">
      <span class="whitespace-nowrap"><i class="fi fi-rr-settings"></i></span>
      <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
   </div>

  <div class="grid grid-cols-2 gap-4">
   <div class="form-input">
     <label>{{ __('Host') }}</label>
     <input type="text" name="env[MAIL_HOST]" value="{{ config('app.MAIL_HOST') }}">
   </div>
   <div class="form-input">
     <label>{{ __('From email') }}</label>
     <input type="text" name="env[MAIL_FROM_ADDRESS]" value="{{ config('app.MAIL_FROM_ADDRESS') }}">
   </div>
   <div class="form-input">
     <label>{{ __('From name') }}</label>
     <input type="text" name="env[MAIL_FROM_NAME]" value="{{ config('app.MAIL_FROM_NAME') ?? '${APP_NAME}' }}">
   </div>
   <div class="form-input">
     <label>{{ __('Port') }}</label>
     <input type="text" name="env[MAIL_PORT]" value="{{ config('app.MAIL_PORT') }}">
   </div>
   <div class="form-input">
     <label>{{ __('Username') }}</label>
     <input type="text" name="env[MAIL_USERNAME]" value="{{ config('app.MAIL_USERNAME') }}">
   </div>
   <div class="form-input">
     <label>{{ __('Password') }}</label>
     <input type="text" name="env[MAIL_PASSWORD]" value="{{ config('app.MAIL_PASSWORD') }}">
   </div>
 </div>
</div>
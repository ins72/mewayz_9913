<div class="p-6 shadow-none border border-gray-300 mt-0 rounded-none">
  <div class="font-heading mb-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-5">
     <span class="whitespace-nowrap">{{ __('Affiliate') }}</span>
     <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
  </div>
  
  <div class="form-input">
    <label class="initial">{{ __('Enable affiliate') }}</label>
    <select name="settings[affiliate][enable]">
      <option value="1" {{ settings("affiliate.enable") ? 'selected' : '' }}>{{ __('Enable') }}</option>
      <option value="0" {{ !settings("affiliate.enable") ? 'selected' : '' }}>{{ __('Disable') }}</option>
    </select>
  </div>
  <div class="form-input mt-5">
    <label class="initial">{{ __('Commission') }}</label>
    <select name="settings[affiliate][commission]">
      <option value="once" {{ settings("affiliate.commission") == 'once' ? 'selected' : '' }}>{{ __('Give commission for the first payment of a referred user.') }}</option>
      <option value="forever" {{ settings("affiliate.commission") == 'forever' ? 'selected' : '' }}>{{ __('Give out commission for all the payments of a referred user.') }}</option>
    </select>
  </div>

  <div class="form-input mt-5">
    <label>{{ __('Commission percentage') }}</label>
    <input type="number" name="settings[affiliate][commission_percentage]" value="{{ settings("affiliate.commission_percentage") }}">
  </div>

  <div class="form-input mt-5">
    <label>{{ __('Min withdrawal') }}</label>
    <input type="number" name="settings[affiliate][min_withdrawal]" value="{{ settings("affiliate.min_withdrawal") }}">
  </div>

  <div class="form-input mt-5 mb-5">
    <label>{{ __('Withdrawal notes') }}</label>
    <textarea name="settings[affiliate][withdrawal_notes]">{{ settings("affiliate.withdrawal_notes") }}</textarea>
  </div>
</div>
<div class="p-6 shadow-none border border-gray-300 mt-0 rounded-none">
  <div class="font-heading mb-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-5">
     <span class="whitespace-nowrap">{{ __('Web App') }}</span>
     <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
  </div>

  <p class="mt-1 mb-1 text-xs text-gray-400 mb-5">{{ __('Add your splash screen image in all these resolution in order for IOS Splash to work properly.') }}</p>

  @foreach (['640x1136', '750x1334', '1242x2208', '1125x2436', '828x1792', '1242x2688', '1536x2048', '1668x2224', '1668x2388', '2048x2732'] as $key => $value)
  <div class="sandy-upload-v2 mb-5 border-white sandy-upload-modal-open card-shadow- cursor-pointer {{!empty(settings("pwa_splash.$value")) && file_exists(public_path('media/bio/pwa-splash/'. settings("pwa_splash.$value"))) ? 'active' : '' }}" data-generic-preview="">
    <input type="file" name="ios_pwa_splash[{{ $value }}]">
    <div class="image-con">
      @if (!empty(settings("pwa_splash.$value")) && file_exists(public_path('media/bio/pwa-splash/'. settings("pwa_splash.$value"))))
      <div class="image lozad" data-background-image="{{ url('media/bio/pwa-splash', settings("pwa_splash.$value")) }}"></div>
      @endif
      <div class="file-name">
        <span class="font-bold">{{ settings("pwa_splash.$value") }}</span>
        <p class="text-xs">{{ __('App icon for your pwa. This is required.') }}</p>
      </div>
    </div>
    <div class="info flex-col items-start">
      <span class="font-bold">{{ __(':size - 2mb', ['size' => $value]) }}</span>
      <p class="text-xs">{{ __('The spash size is :size and it is required.', ['size' => $value]) }}</p>
    </div>
    <div class="add-button text-sm">
      {{ __('Add') }}
    </div>
  </div>
  @endforeach
  
  <div class="font-heading my-6 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center">
    <span class="whitespace-nowrap">{{ __('Firebase') }}</span>
    <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
 </div>
 
  <div class="rounded-xl mb-5">
    
    <div class="form-input">
      <label>{{ __('Api Key') }}</label>
      <input type="text" name="settings[firebase][apiKey]" value="{{ settings('firebase.apiKey') }}" class="">
    </div>
    <div class="form-input mt-5">
      <label>{{ __('Auth Domain') }}</label>
      <input type="text" name="settings[firebase][authDomain]" value="{{ settings('firebase.authDomain') }}" class="">
    </div>
    <div class="form-input mt-5">
      <label>{{ __('Project ID') }}</label>
      <input type="text" name="settings[firebase][projectId]" value="{{ settings('firebase.projectId') }}" class="">
    </div>
    <div class="form-input mt-5">
      <label>{{ __('Storage Bucket') }}</label>
      <input type="text" name="settings[firebase][storageBucket]" value="{{ settings('firebase.storageBucket') }}" class="">
    </div>
    <div class="form-input mt-5">
      <label>{{ __('Messaging sender ID') }}</label>
      <input type="text" name="settings[firebase][messagingSenderId]" value="{{ settings('firebase.messagingSenderId') }}" class="">
    </div>
    <div class="form-input mt-5">
      <label>{{ __('App ID') }}</label>
      <input type="text" name="settings[firebase][appId]" value="{{ settings('firebase.appId') }}" class="">
    </div>
    <div class="form-input mt-5">
      <label>{{ __('Server Key') }}</label>
      <input type="text" name="settings[firebase][server_key]" value="{{ settings('firebase.server_key') }}" class="">
    </div>
  </div>
</div>
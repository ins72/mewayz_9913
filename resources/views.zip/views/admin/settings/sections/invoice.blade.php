@php
    
    
    $invoiceField = getOtherResourceFile('invoiceField');
@endphp

<div class="p-6 shadow-none border border-gray-300 mt-0 rounded-none">
  <div class="font-heading mb-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-5">
     <span class="whitespace-nowrap">{{ __('Invoice') }}</span>
     <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
  </div>

  <div class="form-input mb-5">
    <label>{{ __('Enable') }}</label>
    <select name="settings[invoice][enable]">
      @foreach (['0' => 'Disable', '1' => 'Enable'] as $key => $value)
      <option value="{{ $key }}" {{ settings('invoice.enable') == $key ? 'selected' : '' }}>
        {{ __($value) }}
      </option>
      @endforeach
    </select>
  </div>
  
  <div class="font-heading my-6 pr-2 text-zinc-400 flex items-center">
   <span class="whitespace-nowrap"><i class="fi fi-rr-settings"></i></span>
   <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
 </div>
  
  <div class="grid grid-cols-2 gap-4">
      @foreach ($invoiceField as $key => $value)
      <div class="form-input">
      <label>{{ ao($value, 'name') }}</label>
      <input type="text" name="settings[invoice][{{$key}}]" value="{{ settings("invoice.$key") }}">
      </div>
      @endforeach
   </div>
</div>
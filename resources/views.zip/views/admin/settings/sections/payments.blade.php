<div class="p-6 shadow-none border border-gray-300 mt-0 rounded-none">
  <div class="font-heading mb-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-5">
     <span class="whitespace-nowrap">{{ __('Payments') }}</span>
     <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
  </div>
  <div class="grid grid-cols-2 gap-4">

   <div class="form-input">
      <label>{{ __('Currency') }}</label>
      <select name="settings[payment][currency]">
      @foreach (Currency::all() as $key => $value)
         <option value="{{ $key }}" {{ settings('payment.currency') == $key ? 'selected' : '' }}>
      {!! $key !!}
      </option>
      @endforeach
      </select>
   </div>
  </div>
  <div>
    <p class="mt-2 text-xs text-gray-600 flex items-center gap-1"><i class="fi fi-rr-triangle-warning"></i> {{ __('Please select the currency that works with your current payment method & will be used to purchase plans.') }}</p>
  </div>
</div>

@php
      $payments = new \App\Yena\Payments;
      $payments = $payments->getInstalledMethods();
@endphp

<div class="flex flex-col gap-4 mt-5">
   
   @foreach ($payments as $key => $item)
   <div class="p-6 shadow-none border border-gray-300 mt-0 rounded-none">
      <div class="font-heading mb-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-5">
         <span class="whitespace-nowrap">
            <img src="{{ gs('assets/image/payments', ao($item, 'thumbnail')) }}" alt="{{ ao($item, 'name') }}" class="h-8">
         </span>
         <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
      </div>
      
      <div>
         <div class="flex items-center gap-4 py-4">
            <div class="mt-1 self-start">
               <i class="fi fi-rr-eye-crossed text-lg"></i>
            </div>
            <div>
               <div>{{ __('Enable') }} {{ ao($item, 'name') }}</div>
               <div class="text-xs font-normal text-gray-500">{{ ao($item, 'description') }}</div>
            </div>
            <div class="flex-grow"></div>

            @php
                $checked = settings("payment_$key.status");
            @endphp
            <x-input.checkbox name="settings[payment_{{ $key }}][status]" value="1" checked="{{ $checked }}" ></x-input.checkbox> 

         </div>

         <div class="form-input">
            <label>{{ __('Payment Description') }}</label>
            <input type="text" name="settings[payment_{{ $key }}][description]" value="{{ settings("payment_$key.description") }}">
         </div>
      </div>
      <div class="font-heading my-6 pr-2 text-zinc-400 flex items-center">
         <span class="whitespace-nowrap"><i class="fi fi-rr-settings"></i></span>
         <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
       </div>

      <div>
         @includeIf("Payment-$key::admin.edit")
      </div>
      <div class="grid grid-cols-2 gap-4">
      
      </div>
   </div>
   @endforeach
</div>
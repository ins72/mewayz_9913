<div class="h-full overflow-y-auto">
  <div class="relative flex h-32 flex-col justify-end overflow-hidden bg-gray-100 p-6">
     <div class="absolute inset-0"></div>
     <div class="absolute inset-0 bg-gradient-to-tr from-gray-100 to-gray-100/0"></div>
     <div class="absolute right-4 top-4" @click="add_user=false">
        <button class="rounded-md p-1 text-gray-600 hover:bg-gray-200">
           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" fill="none" style="" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
           </svg>
        </button>
     </div>
     <div class="font-heading mb-2 pr-2 font--12 font-extrabold uppercase tracking-wider text-gray-700 flex items-center mb-2">
      <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
      <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
    </div>
     <div class="relative">
        <h1 class="text-xl font-bold">{{ __('Link user to plan') }}</h1>
     </div>
  </div>
  <form class="px-6 pb-6" method="post" action="{{ route('console-admin-plans-post', 'add_user') }}">
    @csrf

    <div class="grid md:grid-cols-2 grid-cols-1 gap-4">
      <div class="form-input">
        <label class="initial">{{ __('Plan') }}</label>
        <select name="plan_id">
          @foreach ($plans as $plan)
             <option value="{{ $plan->id }}">{{ $plan->name }}</option>
          @endforeach
        </select>
      </div>
      <div class="form-input">
        <label class="initial">{{ __('User') }}</label>
        <select name="user_id">
          @foreach (\App\Models\User::get() as $user)
             <option value="{{ $user->id }}">{{ $user->name }}</option>
          @endforeach
        </select>
      </div>
    </div>
    <div class="form-input mt-5">
      <label class="initial">{{ __('Expire on') }}</label>
      <input
      type="date"
      name="date"
      autocomplete="off"
      >
    </div>
     <button type="submit" class="hover:shadow-primary-600/20 bg-black text-white duration-200 hover:scale-[1.02] hover:shadow-xl active:scale-[0.98] disabled:opacity-80 mt-4 w-full block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-4 py-2.5">
        <div class="relative flex items-center justify-center ">
           <div class="duration-100 undefined false">{{ __('Save') }}</div>
        </div>
     </button>
  </form>
</div>
@php
    $plan = $item;
@endphp
<div class="h-full overflow-y-auto">
  <div class="relative flex h-32 flex-col justify-end overflow-hidden bg-gray-100 p-6">
     <div class="absolute inset-0 bg-gradient-to-tr from-gray-100 to-gray-100/0"></div>
     <div class="absolute right-4 top-4 --closer" x-on:click="closeModal('plan-' + {{ $item->id }})">
        <button class="rounded-md p-1 text-gray-600 hover:bg-gray-200">
           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" fill="none" style="" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
           </svg>
        </button>
     </div>
     <div class="font-heading mb-2 pr-2 font--12 font-extrabold uppercase tracking-wider text-gray-700 flex items-center mb-2">
      <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
      <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
    </div>
     <div class="relative">
        <h1 class="text-xl font-bold">{{ __('Edit Package') }}</h1>
     </div>
  </div>
  <form class="px-6 pb-6" method="post" action="{{ route('console-admin-plans-post', 'edit') }}">
    @csrf

    <input type="hidden" name="_id" value="{{ $plan->id }}">

    <div class="mt-4">
      <div class="form-input">
        <label>{{ __('Package Name') }}</label>
        <input type="text" name="name" value="{{ $plan->name }}">
      </div>
      <div class="form-input mt-4 hidden">
        <label>{{ __('Package Description') }}</label>
        <textarea name="description" cols="30" rows="5">{{ $plan->description }}</textarea>
      </div>


     
      <div class="font-heading my-4 mt-5 pr-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
        <span class="whitespace-nowrap">{{ __('Pricing') }}</span>
        <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
      </div>

      <div class="grid grid-cols-2 gap-4">
        <div class="form-input">
          <input type="text" name="monthly" placeholder="{{ __('Monthly Price') }}" value="{{ $plan->price }}">
        </div>
        <div class="form-input">
          <input type="text" name="annual" placeholder="{{ __('Annual Price') }}" value="{{ $plan->annual_price }}">
        </div>
      </div>

      
      <div class="font-heading my-4 pr-2 text-zinc-400 flex items-center">
        <span class="whitespace-nowrap"><i class="fi fi-rr-settings"></i></span>
        <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
      </div>

      <div class="flex items-center gap-4 py-4">
        <div class="mt-1 self-start">
           <i class="fi fi-rr-puzzle-alt text-lg"></i>
        </div>
        <div>
           <div class="font--12">{{ __('Free Plan') }}</div>
           <div class="text-xs font-normal text-gray-500">{{ __('Make this plan free without payments.') }}</div>
        </div>
        <div class="flex-grow"></div>

        <x-input.checkbox  checked="{{ $plan->is_free }}" value="1" name="is_free" ></x-input.checkbox> 
     </div>

     <div class="flex items-center gap-4 py-4">
       <div class="mt-1 self-start">
          <i class="fi fi-rr-coins text-lg"></i>
       </div>
       <div>
          <div class="font--12">{{ __('Enable Trial') }}</div>
          <div class="text-xs font-normal text-gray-500">{{ __('Make this plan free without payments.') }}</div>
       </div>
       <div class="flex-grow"></div>

        <x-input.checkbox checked="{{ $plan->has_trial }}" value="1" name="has_trial" ></x-input.checkbox> 
    </div>
    <div class="form-input">
      <label class="text-xs">{{ __('Trial Expiry') }}</label>
      <input type="text" name="trial_days" value="{{ $plan->trial_days }}" class="text-xs">
    </div>
     
      <div class="font-heading mb-2 mt-5 pr-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
        <span class="whitespace-nowrap">{{ __('Plan Features') }}</span>
        <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
      </div>
      <div class="grid grid-cols-1 gap-4">

        @foreach (ao($skeleton, 'feature') as $key => $item)

          @php
              $feature = $plan->features()->code($key)->first();
          @endphp

          <label class="sandy-big-checkbox">
              <input type="hidden" name="feature[{{ $key }}]" value="0">
              <input type="checkbox" name="feature[{{ $key }}]" class="sandy-input-inner" value="1" {{ $feature && $feature->enable ? 'checked' : '' }}>
              <div class="checkbox-inner h-3em py-2 border-gray-200">
                <div class="checkbox-wrap">
                  <div class="content">
                    <h1 class="font--12">{{ ao($item, 'name') }}</h1>
                    <p class="font--10">{{ ao($item, 'description') }}</p>
                  </div>
                  <div class="icon">
                    <div class="active-dot h-5 w-5">
                      <i class="fi fi-rr-check font--8"></i>
                    </div>
                  </div>
                </div>
              </div>
          </label>
        @endforeach
        </div>

      
      <div class="font-heading mb-2 mt-5 pr-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
        <span class="whitespace-nowrap">{{ __('Consumeable') }}</span>
        <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
      </div>
      <div class="grid sm:grid-cols-2 gap-4">

        @foreach (ao($skeleton, 'consume') as $key => $item)

          @php
              $feature = $plan->features()->code($key)->first();
          @endphp

          <div class="form-input">
            <label class="text-xs">{{ ao($item, 'name') }}</label>
            <input type="text" name="consume[{{ $key }}]" value="{{ $feature ? $feature->limit : -1 }}" class="text-xs" placeholder="{{ ao($item, 'description') }}">
          </div>
        @endforeach
        </div>
        <div>
          <p class="mt-2 text-xs text-gray-600 flex items-center gap-1"><i class="fi fi-rr-triangle-warning"></i> {{ __('-1 for unlimited') }}</p>
        </div>

    </div>
     <button type="submit" class="hover:shadow-primary-600/20 bg-black text-white duration-200 hover:scale-[1.02] hover:shadow-xl active:scale-[0.98] disabled:opacity-80 mt-4 w-full block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-4 py-2.5">
        <div class="relative flex items-center justify-center ">
           <div class="duration-100 undefined false">{{ __('Save') }}</div>
        </div>
     </button>
  </form>
</div>
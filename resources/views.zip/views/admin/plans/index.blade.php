<x-layouts.app>
  <x-slot:title>{{ __('Plans') }}</x-slot>


  <script>
    function plan_pine(){
  
      return {
        create_modal: false,
        add_user: false,
        modals: [],
  
        openModal(id){
          var _this = this;
          if(!_this.$event.target.classList.contains('app-un')){
              this.modals[id] = true;
          }
        },
  
        closeModal(id){
          this.modals[id] = false;
        },
  
        isShownModal(id){
          if(this.modals[id]){
              return true;
          }
  
          return false;
        },
      }
    }
  </script>
  
  <div class="h-full pb-16 pt-8 sm:pt-10" x-data="plan_pine">
    <div class="flex h-32 items-center border-b border-gray-200">
      <div class="mx-auto w-full max-w-screen-xl px-5">
      
         <div class="mb-5 pb-5 pt-0">
          <div class="font-heading mb-2 px-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
            <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
            <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
          </div>
          <h1 class="text-zinc-500 text-5xl mb-2 font-bold">{{ __('Packages') }}</h1>
            <div class="mt-3 flex items-center gap-2">
              <a class="bg-primary overflow-hidden rounded-lg p-1 px-5 text-white --control cursor-pointer" @click="create_modal=true">
                  <div class="flex h-full items-center">
                      <div class="px-2 py-0.5 text-sm font-medium">{{ __('Create new') }}</div>
                  </div>
              </a>
              
              <a class="bg-primary overflow-hidden rounded-lg p-1 px-5 text-white cursor-pointer" @click="add_user=true">
                  <div class="flex h-full items-center">
                      <div class="px-2 py-0.5 text-sm font-medium">{{ __('Add a user') }}</div>
                  </div>
              </a>
            </div>
         </div>
      </div>
    </div>
    <div x-show="add_user" x-cloak x-transition.opacity.duration.500ms="" class="alpine-dialog-modal">
  
      <div class="-alpine-modal-overflow" x-on:click="add_user = false"></div>
      <div class="-alpine-dialog h-full w-full transform overflow-hidden bg-white text-left align-bottom shadow-xl sm:w-full sm:max-w-lg top-0 right-0 left-auto" x-show="add_user !== false">
         <div>
            @includeIf('admin.plans.add-user')
         </div>
      </div>
    </div>
  
    <div x-show="create_modal" x-cloak x-transition.opacity.duration.500ms="" class="alpine-dialog-modal">
  
      <div class="-alpine-modal-overflow" x-on:click="create_modal = false"></div>
      <div class="-alpine-dialog h-full w-full transform overflow-hidden bg-white text-left align-bottom shadow-xl sm:w-full sm:max-w-lg top-0 right-0 left-auto" x-show="create_modal !== false">
         <div>
            @includeIf('admin.plans.new')
         </div>
      </div>
    </div>
  
    <div class="mx-auto w-full max-w-screen-xl px-2.5 pb-10 pt-8">
      @if ($plans->isEmpty())
        
      <div>
        <p class="mt-2 text-xs text-gray-600 flex items-center gap-1"><i class="fi fi-rr-triangle-warning"></i> {{ __('No available plan(s)') }}</p>
      </div>
    
      @endif
    
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
        
      @foreach ($plans as $item)
    
      <div class="block rounded-lg border border-solid border-gray-200 hover:bg-gray-100" style="">
        <div class="group flex items-center gap-4 px-4 py-2.5">
           <a class="flex flex-grow items-center gap-4 overflow-x-hidden cursor-pointer">
              <div class="rounded-md px-0.5 py-1">
                 <div class="">
                    <i class="fi fi-rr-box"></i>
                 </div>
              </div>
    
              <div>
                <div class="flex w-full">
                   <div class="truncate text-sm font-medium">{{ $item->name }}</div>
                </div>
                <div class="flex items-center gap-1 truncate text-sm text-gray-500">{{ number_format($item->subscribers()->paid()->notCancelled()->count()) }} {{ __('Current Users') }}. {{ __('Created on') }} {{ \Carbon\Carbon::parse($item->created_at)->toFormattedDateString() }}</div>
             </div>
              <div class="border-b border-solid border-zinc-700 w-full ml-2 flex"></div>
           </a>
           <div class="flex items-center text-gray-500">
              <a x-on:click="openModal('plan-' + {{ $item->id }})" class="rounded-md p-1.5 hover:bg-gray-100 mx-1 cursor-pointer">
                <i class="fi fi-rr-attribution-pencil text-lg"></i>
              </a>
    
              
              <div>
                <div x-cloak x-show="isShownModal('plan-' + {{ $item->id }})" x-transition.opacity.duration.500ms class="alpine-dialog-modal">
                  <div class="-alpine-modal-overflow" x-on:click="closeModal('plan-' + {{ $item->id }})"></div>
                  <div class="-alpine-dialog h-full w-full transform overflow-auto bg-white text-left align-bottom shadow-xl sm:w-full sm:max-w-lg top-0 right-0 left-auto --no-pop" x-show="isShownModal('plan-' + {{ $item->id }})" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform scale-90" x-transition:enter-end="opacity-100 transform scale-100" x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100 transform scale-100" x-transition:leave-end="opacity-0 transform scale-90">
                      <div>
                        @includeIf('admin.plans.edit')
                      </div>
                  </div>
                </div>
            </div>
            
              
              
              <x-parts.--delete>
                <x-slot name="content">{{ __('Are you sure you want to delete this plan? This action is irreversible.') }}</x-slot>
    
                <x-slot name="handle">
                  <a class="rounded-lg px-2 py-1 text-xs font-medium duration-200 bg-red-400 shadow-xl text-white flex items-center gap-1 --open-delete cursor-pointer">
                      <i class="fi fi-rr-trash"></i>
                      {{ __('Delete') }}
                  </a>
                </x-slot>
    
                <x-slot name="form">
                  <form action="{{ route('console-admin-plans-post', 'delete') }}" method="post">
                    @csrf
                    <input type="hidden" name="_id" value="{{ $item->id }}">
                    <button type="submit" class="first-letter: bg-red-500  text-white disabled:opacity-75 hover:bg-red-400
                           block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-3 py-1.5">
                           <div class="relative flex items-center justify-center ">
                            <div class="duration-100">{{ __('Delete') }}</div>
                          </div>
                    </button>
                  </form>
                </x-slot>
              </x-parts.--delete>
           </div>
        </div>
     </div>
    
      <div class="sandy-widget mt-10 sm:mt-0 sortable-item p-5 shadow-none border border-gray-200 border-solid remove-before hidden" data-id="{{ $item->id }}">
        <div class="font-heading mb-2 pr-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
          <span class="whitespace-nowrap">{{ $item->name }}</span>
          <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
        </div>
    
    
        <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
        <div class="sandy-quality my-7">
          <div class="sandy-quality-list">
            <div class="border-b border-solid border-gray-300 sandy-quality-item pb-4 mb-4">
              <div class="preview bg-gray-100 w-10 h-10">
                <i class="fi fi-rr-users-alt text-lg"></i>
              </div>
              <div class="sandy-quality-details">
                <div class="sandy-quality-line">
                  <div class="text-xs">{{ __('Current Users') }}</div>
                </div>
    
                <a class="sandy-quality-info href-link-button" href="">
                  {{ number_format($item->subscribers()->count()) }}
                </a>
              </div>
            </div>
            <div class="sandy-quality-item">
              <div class="preview bg-pink-opacity">
                <i class="sio design-and-development-098-key text-2xl"></i>
              </div>
            </div>
          </div>
    
          <div class="font-heading mb-0 pr-2 text-zinc-400 flex items-center">
            <span class="whitespace-nowrap"><i class="fi fi-rr-settings"></i></span>
            <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
    
            <div class="flex gap-2">
    
              <div class="sandy-popup flex" data-opener=".--control" data-closer=".--closer">
                <a class="sandy-button --control" aria-expanded="false">
                  <div class="--sandy-button-container">
                      <span class="text-xs">{{ __('Edit') }}</span>
                  </div>
                </a>
        
        
                <div class="sandy-popup-content-temp">
                  <div class="h-full w-full transform overflow-hidden bg-white text-left align-bottom shadow-xl sm:w-full sm:max-w-lg top-0 right-0 left-auto --no-pop">
                    
                    @includeIf('admin.plans.edit')
                  </div>
                </div>
        
              </div>
              
              <x-parts.--delete>
                <x-slot name="content">{{ __('Are you sure you want to delete this plan? This action is irreversible.') }}</x-slot>
    
                <x-slot name="handle">
                  <a class="rounded-lg px-2 py-1 text-xs font-medium duration-200 bg-red-400 shadow-xl text-white flex items-center gap-1 --open-delete cursor-pointer">
                    <i class="fi fi-rr-trash"></i>
                    {{ __('Delete') }}
                  </a>
                </x-slot>
    
                <x-slot name="form">
                  <form action="{{ route('console-admin-plans-post', 'delete') }}" method="post">
                    @csrf
                    <input type="hidden" name="_id" value="{{ $item->id }}">
                    <button type="submit" class="first-letter: bg-red-500  text-white disabled:opacity-75 hover:bg-red-400
                           block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-3 py-1.5">
                           <div class="relative flex items-center justify-center ">
                            <div class="duration-100">{{ __('Delete') }}</div>
                          </div>
                    </button>
                  </form>
                </x-slot>
              </x-parts.--delete>
            </div>
          </div>
        </div>
      </div>
      @endforeach
    
      </div>
    </div>
  </div>
</x-layouts.app>
@extends('dashboard::layouts.master')
@section('title', __('Edit Blog'))
@section('content')
    

<x-lmao :href="'sss'" :active="request()->routeIs('dashboard')">
    {{ __('Dashboard') }}
</x-lmao>

<x-header-title>
    {{ $blog->id ? __('Edit Blog') : __('Create Blog') }}
</x-header-title>


<form method="post" action="{{-- route('console-admin-blog-post',['tree'=>'store','blog_id'=>$blog->id]) --}}" class="rounded-3xl card-shadow p-5" enctype="multipart/form-data">
        @csrf
          <div class="form-input">
            <label for="">{{ __('Name') }}</label>
            <input type="text" class="" value="{{ $blog->name }}" name="name">
          </div>
          <div class="grid grid-cols-2 gap-4 mt-5">
            <div class="form-input mt-5">
              <label class="initial">{{ __('Page type') }}</label>
              <select name="type" class="">
                <option value="internal" {{ $blog->type == 'internal' ? 'selected' : '' }}>{{ __('Internal') }}</option>
                <option value="external" {{ $blog->type == 'external' ? 'selected' : '' }}>{{ __('External') }}</option>
              </select>
            </div>
            <div class="form-input mt-5">
              <label class="initial">{{ __('Status') }}</label>
              <select name="status" class="">
                <option value="1" {{ $blog->status ? 'selected' : '' }}>{{ __('Active') }}</option>
                <option value="0" {{ !$blog->status ? 'selected' : '' }}>{{ __('Hidden') }}</option>
              </select>
            </div>
          </div>
        <div class="mb-5 p-5 sandy-main-bg rounded-2xl">
          <div class="form-input pre" id="blog-slug">
            <label class="initial">{{ __('Slug') }}</label>
            <div class="flex">
              <div class="input-side-pre">
                <span>{{ url('/') }}/{{ __('blog') }}/</span>
              </div>
              <input type="text" name="location" value="{{ $blog->location }}" class="">
            </div>
          </div>
        </div>
        <div class="mb-5 p-5 sandy-main-bg rounded-2xl">
          <div class="flex items-center flex-col">
            <div class="h-avatar h-52 w-full is-upload is-outline-dark text-2xl" data-generic-preview=".h-avatar">
              <i class="flaticon-upload-1"></i>
              <input type="file" name="blog_thumbnail">
              <div class="image lozad" data-background-image="{{ gs('media/site/blog', $blog->thumbnail) }}"></div>
            </div>
          </div>
        </div>
          <div class="form-input mb-5">
            <label for="">{{ __('Description') }}</label>
            <textarea name="description" class="editor" id="" cols="30" rows="10">{!! $blog->description !!}</textarea>
          </div>
          <div class="form-input mb-5">
            <label>{{ __('Author') }}</label>
            <input type="text" name="author" value="{{ $blog->author }}" class="">
          </div>
          <div class="form-input">
            <label>{{ __('Time to read. Ex: 5 min') }}</label>
            <input type="text" name="ttr" value="{{ $blog->ttr }}" class="">
          </div>
      </form>
@endsection

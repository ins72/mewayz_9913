@extends('mix::layouts.master')
@section('title', __('Payments'))
@section('content')

<div class="h-full pb-16 pt-8 sm:pt-10">
  <div class="flex h-32 items-center border-b border-gray-200">
    <div class="mx-auto w-full max-w-screen-xl px-5">
    
       <div class="mb-5 pb-5 pt-0">
        <div class="font-heading mb-2 px-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
          <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
          <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
        </div>
        <h1 class="text-zinc-500 text-5xl mb-2 font-bold">{{ __('Payments') }}</h1>
        <div class="mt-3 flex items-center">
          <a class="bg-primary overflow-hidden rounded-lg p-1 px-5 text-white cursor-pointer block" href="{{ route('console-admin-payments-pending') }}">
             <div class="flex h-full items-center">
                 <div class="px-2 py-0.5 text-sm font-medium">{{ __('Pending Payments') }} ({{ $pendingCount }})</div>
             </div>
            </a>
        </div>
       </div>
    </div>
  </div>
  

  <div class="mx-auto w-full max-w-screen-xl px-2.5 pb-10 pt-8">
    @if (!$payments->isEmpty())
    <div class="page-trans">
        
        <div class="flex-table mt-4">
            <!--Table header-->
            <div class="flex-table-header">
                <span class="is-grow">{{ __('User') }}</span>
                <span>{{ __('Date') }}</span>
                <span>{{ __('Amount') }}</span>
                <span>{{ __('Method') }}</span>
                <span>{{ __('Plan') }}</span>
            </div>
            @foreach ($payments as $item)
            <div class="flex-table-item shadow-none">
                <div class="flex-table-cell is-media is-grow" data-th="">
                    @if (\App\User::find($item->user))
                    <div class="h-avatar h-12 w-12 rounded-full mr-4">
                        <img class="avatar is-squared lozad" data-src="{{ avatar($item->user) }}" alt="">
                    </div>
                    @endif
                    <div>
                        <span class="item-name dark-inverted is-font-alt is-weight-600">{{ !empty(user('name', $item->user)) ? user('name', $item->user) : $item->name }}</span>
                        <span class="item-meta text-xs mt-2">
                            <span>{{ $item->email }}</span>
                        </span>
                    </div>
                </div>
                <div class="flex-table-cell" data-th="{{ __('Date') }}">
                    <span class="light-text">{{ Carbon\Carbon::parse($item->created_at)->toFormattedDateString() }}</span>
                </div>
                <div class="flex-table-cell" data-th="{{ __('Amount') }}">
                    <span class="dark-inverted is-weight-600">{!! Currency::symbol($item->currency) . $item->price !!}</span>
                </div>
                <div class="flex-table-cell" data-th="{{ __('Method') }}">
                    <span class="tag is-green is-rounded">{{ $item->gateway }}</span>
                </div>
                <div class="flex-table-cell" data-th="{{ __('Plan') }}">
                    <div class="ml-auto md:ml-0">
                        <span class="item-name font-normal text-base">{{ !empty(GetPlan('name', $item->plan)) ? GetPlan('name', $item->plan) : $item->plan_name }}</span>
                        <span class="item-meta text-xs mt-2 block">
                            <span>{{ ucfirst($item->duration) }}</span>
                        </span>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @else
    <div class="is-empty md:p-20 text-center mt-10 block">
        <img src="{{ gs('assets/image/others', 'empty-fld.png') }}" class="w-half m-auto" alt="">
        <p class="mt-10 text-lg font-bold">{{ __('No Payments Found.') }}</p>
    </div>
    @endif
  </div>
</div>
@endsection

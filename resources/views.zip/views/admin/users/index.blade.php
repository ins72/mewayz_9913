@extends('mix::layouts.master')
@section('title', __('Users'))
@section('content')

<script>
  function _pine(){
     return {
        create_modal: false,
        modals: [],

        openModal(id){
          var _this = this;
          if(!_this.$event.target.classList.contains('app-un')){
              this.modals[id] = true;
          }
        },

        closeModal(id){
          this.modals[id] = false;
        },

        isShownModal(id){
          if(this.modals[id]){
              return true;
          }

          return false;
        },
        init(){
          
        }
     }
  }
</script>

<div x-data="_pine">

  <div class="flex h-48 items-center border-b border-gray-200">
    <div class="mx-auto w-full max-w-screen-xl px-5">
    
       <div class="mb-5 pb-5 border-b border-solid border-gray-300 pt-4">
        <div class="font-heading mb-2 px-2 font--12 font-extrabold uppercase tracking-wider text-zinc-400 flex items-center mb-2">
          <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
          <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
        </div>
        <h1 class="text-zinc-500 text-5xl mb-2 font-bold">{{ __('All Users') }}</h1>
  
        <div class="mt-3 flex items-center">
          <a class="bg-primary overflow-hidden rounded-lg p-1 px-5 text-white --control cursor-pointer" @click="create_modal=true">
              <div class="flex h-full items-center">
                  <div class="px-2 py-0.5 text-sm font-medium">{{ __('Create new') }}</div>
              </div>
          </a>
          
          <div class="flex z-menuc ml-3" data-max-width="600" data-handle=".--control">
            <a class="bg-white overflow-hidden rounded-lg p-1 px-2 text-black --control cursor-pointer border" aria-expanded="false">
                <div class="flex h-full items-center">
                    <div class="px-2 py-0.5 text-sm font-medium"><i class="fi fi-rr-filter"></i></div>
                </div>
            </a>
  
            <div class="z-menuc-content-temp">
                <ul class="z-menu-ul w-40em max-w-full shadow-lg border border-solid border-gray-200 rounded-xl">
                    <div class="p-6">
                        <div class="w-full">
                          <div class="flex w-full items-center justify-between">
                              <div class="flex-grow">
                                <h4 class="text-lg font-medium">{{ __('Filter') }}</h4>
                              </div>
                              <button type="button" class="-mt-1 rounded-md p-1 text-gray-500 hover:bg-zinc-50 z-menu-close" tabindex="0">
                                <i class="fi fi-rr-cross"></i>
                              </button>
                          </div>
                        </div>
  
                        <div class="border-b border-solid border-gray-300 my-3"></div>
                        
                        @includeIf('admin.users.filter')
                    </div>
                </ul>
            </div>
        </div>
        </div>
       </div>
    </div>
  </div>



  <div x-show="create_modal" x-cloak x-transition.opacity.duration.500ms="" class="alpine-dialog-modal">

    <div class="-alpine-modal-overflow" x-on:click="create_modal = false"></div>
    <div class="-alpine-dialog h-full w-full transform overflow-hidden bg-white text-left align-bottom shadow-xl sm:w-full sm:max-w-lg top-0 right-0 left-auto" x-show="create_modal !== false">
       <div>
        <div class="h-full overflow-y-auto">
          <div class="relative flex h-32 flex-col justify-end overflow-hidden bg-gray-100 p-6">
             <div class="absolute inset-0"></div>
             <div class="absolute inset-0 bg-gradient-to-tr from-gray-100 to-gray-100/0"></div>
             <div class="absolute right-4 top-4" x-on:click="create_modal = false">
                <button class="rounded-md p-1 text-gray-600 hover:bg-gray-200">
                   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" fill="none" style="" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                   </svg>
                </button>
             </div>
             <div class="font-heading mb-2 pr-2 font--12 font-extrabold uppercase tracking-wider text-gray-700 flex items-center mb-2">
              <span class="whitespace-nowrap">{{ __('Super Admin') }}</span>
              <div class="border-b border-solid border-gray-300 w-full ml-2 flex"></div>
            </div>
             <div class="relative">
                <h1 class="text-xl font-bold">{{ __('Create User') }}</h1>
             </div>
          </div>
          <form action="{{ route('console-admin-users-post', 'create') }}" class="px-6 pb-6 pt-4" method="POST">
            @csrf
            <div class="grid grid-cols-2 gap-4 mb-5">
              <div class="form-input">
                <label>{{ __('Name') }}</label>
                <input type="text" name="name">
              </div>
              <div class="form-input">
                <label>{{ __('Email') }}</label>
                <input type="email" name="email">
              </div>
            </div>
            <div class="form-input mb-5">
              <label>{{ __('Password') }}</label>
              <input type="password" name="password">
            </div>
            <div class="text-xs text-gray-400 my-5">{{ __('Password must have at least one uppercase, lowercase number, special characters') }}</div>
            
            <button type="submit" class="hover:shadow-primary-600/20 bg-black text-white duration-200 hover:scale-[1.02] hover:shadow-xl active:scale-[0.98] disabled:opacity-80 mt-4 w-full block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-4 py-2.5">
              <div class="relative flex items-center justify-center ">
                 <div class="duration-100 undefined false">{{ __('Save') }}</div>
              </div>
           </button>
          </form>
        </div>
       </div>
       
      
    </div>
  </div>
  

<div class="mx-auto w-full max-w-screen-xl px-2.5 pb-10 pt-8">

  <div class="page-trans">

  <!-- Users -->
  <div class="flex flex-col divide-y divide-gray-100 border-t border-gray-100 lg:hidden">
    <div class="">
      
      @foreach ($users as $_user)
       <div class="cursor-pointer px-1 py-6 text-left align-top text-sm duration-100 hover:bg-gray-50">
          <div class="text-col">

            <div class="flex min-w-[10rem] max-w-[15rem] gap-2">
              <div class="relative flex-none">
                 <div class="relative">
                    <div class="sj-avatar-container">
                      <img src="{{ avatar($_user->id) }}" alt=" " class="w-10 h-10 rounded-full" referrerpolicy="no-referrer">
                    </div>
                    <div class="absolute -bottom-2 -right-1">
                       <div class="rounded-full bg-white/75 p-1 backdrop-blur-sm">
                          <div class=""></div>
                       </div>
                    </div>
                 </div>
              </div>
              <div class="flex flex-col justify-center truncate">
                 <div class="truncate whitespace-pre-wrap text-gray-900">{{ $_user->name }}</div>
                 <div class="truncate whitespace-pre-wrap">{{ $_user->email }}</div>
              </div>
           </div>
          </div>
          <div class="text-col mt-0">
             <div class="h-full w-full max-w-md">
                <div class="row-content truncate whitespace-pre-wrap text-gray-600">{{ __('Last Activity') }} : {{ \Carbon\Carbon::parse($_user->lastActivity)->toDayDateTimeString() }}</div>
                <div class="mt-2 flex-none text-xs text-gray-400">{{ __('Registered on') }}: {{ \Carbon\Carbon::parse($_user->created_at)->toFormattedDateString() }}</div>
                <div class="mt-2">
                  
                  <div class="flex flex-wrap gap-1">
                    @if ($_user->status)
                    <span class="rounded-full px-2 py-1 text-xs font-medium bg-green-400 text-black">{{ __('Active') }}</span>
                    @else
                    <span class="rounded-full px-2 py-1 text-xs font-medium bg-red-500 text-white">{{ __('Disabled') }}</span>
                    @endif
                  </div>
                </div>
                <div class="-ml-1 mt-2 flex flex-wrap gap-1">

                  <div class="flex">
              
                    <div class="flex z-menuc" data-max-width="600" data-handle=".--control">
                        <a class="rounded-full border-[1.5px] px-2 py-1 text-xs font-medium duration-200 bg-white shadow-xl border-amber-500/0 hover:border-amber-500 text-amber-600 flex items-center gap-1 --control cursor-pointer">
                          <i class="fi fi-rr-attribution-pencil"></i>
                          {{ __('Edit') }}
                        </a>
      
                        <div class="z-menuc-content-temp">
                            <ul class="z-menu-ul w-40em max-w-full shadow-lg border border-solid border-gray-200 rounded-xl">
                                <div class="p-6">
                                    <div class="w-full">
                                      <div class="flex w-full items-center justify-between">
                                          <div class="flex-grow">
                                            <h4 class="text-lg font-medium">{{ __('Edit User') }}</h4>
                                          </div>
                                          <button type="button" class="-mt-1 rounded-md p-1 text-gray-500 hover:bg-zinc-50 z-menu-close" tabindex="0">
                                            <i class="fi fi-rr-cross"></i>
                                          </button>
                                      </div>
                                    </div>
      
                                    <div class="border-b border-solid border-gray-300 my-3"></div>
                                    
                                    @includeIf('admin.users.edit')
                                </div>
                            </ul>
                        </div>
                    </div>

                    <div class="flex z-menuc ml-2" data-max-width="600" data-handle=".--control">
                        <a class="rounded-full border-[1.5px] px-2 py-1 text-xs font-medium duration-200 bg-red-400 shadow-xl text-white flex items-center gap-1 --control cursor-pointer">
                          <i class="fi fi-rr-trash"></i>
                          {{ __('Delete') }}
                        </a>
      
                        <div class="z-menuc-content-temp">
                            <ul class="z-menu-ul w-40em max-w-full shadow-lg border border-solid border-gray-200 rounded-xl">
                                <div class="p-6">
                                  <i class="fi fi-rr-triangle-warning text-lg text-red-500"></i>
                                  <div class="mt-1 text-sm text-gray-600">
                                    <div>
                                      <span slot="description">{{ __('Are you sure you want to delete this user? This action is irreversible.') }}</span>
                                    </div>
                                  </div>
      
                                    <div class="border-b border-solid border-gray-300 my-3"></div>
                                    <div class="mt-4 flex justify-end gap-2">
                                      <button type="button" class=" block appearance-none rounded-md border bg-white text-sm font-medium text-gray-600 shadow-sm duration-100 focus:ring-0
                                      px-3 py-1.5 block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-3 py-1.5 z-menu-close">{{ __('Cancel') }}</button>
                                      
                                      <form action="{{ route('console-admin-users-post', 'delete') }}" method="post">
                                        @csrf

                                        <input type="hidden" name="_user" value="{{ $_user->id }}">
                                        <button type="submit" class="first-letter: bg-red-500  text-white disabled:opacity-75 hover:bg-red-400
                                               block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-3 py-1.5">
                                               <div class="relative flex items-center justify-center "><div class="duration-100">{{ __('Delete') }}</div>
                                          </div>
                                      </button>
                                      </form>
                                              
                                    </div>
                                </div>
                            </ul>
                        </div>
                    </div>
                  </div>
                </div>
            </div>
          </div> 
            <div class="text-col flex-nowrap whitespace-nowrap"></div>
        </div>
        @endforeach
    </div>
 </div>

  <table class="hidden min-w-[600px] table-fixed divide-y divide-gray-200 lg:table lg:min-w-full ">
    <thead>
       <tr>
          <th scope="col" class="table-header "><span class="">{{ __('User') }}</span></th>
          <th scope="col" class="table-header ">{{ __('Status') }}</th>
          <th scope="col" class="table-header ">{{ __('Registered on') }}</th>
          <th scope="col" class="table-header ">{{ __('Action') }}</th>
       </tr>
    </thead>
    <tbody class="divide-y divide-gray-100">
      @foreach ($users as $_user)
       <tr class="cursor-pointer align-top duration-100 hover:bg-gray-50">
          <td class="text-col svelte-1aqujna">
             <div class="flex min-w-[10rem] max-w-[15rem] gap-2">
                <div class="relative flex-none">
                   <div class="relative">
                      <div class="sj-avatar-container">
                        <img src="{{ avatar($_user->id) }}" alt=" " class="w-10 h-10 rounded-full" referrerpolicy="no-referrer">
                      </div>
                      <div class="absolute -bottom-2 -right-1">
                         <div class="rounded-full bg-white/75 p-1 backdrop-blur-sm">
                            <div class=""></div>
                         </div>
                      </div>
                   </div>
                </div>
                <div class="flex flex-col justify-center truncate">
                   <div class="truncate whitespace-pre-wrap text-gray-900">{{ $_user->name }}</div>
                   <div class="truncate whitespace-pre-wrap">{{ $_user->email }}</div>
                </div>
             </div>
          </td>
          <td class="text-col svelte-1aqujna">
             <div class="h-full min-w-[18rem] max-w-[25rem] ">
                <div class="row-content truncate whitespace-pre-wrap text-gray-600" >{{ __('Last Activity') }} : {{ \Carbon\Carbon::parse($_user->lastActivity)->toDayDateTimeString() }}</div>
                <div class="-ml-1 mt-2 flex flex-wrap gap-1">
                  @if ($_user->status)
                  <span class="rounded-full px-2 py-1 text-xs font-medium bg-green-400 text-black">{{ __('Active') }}</span>
                  @else
                  <span class="rounded-full px-2 py-1 text-xs font-medium bg-red-500 text-white">{{ __('Disabled') }}</span>
                  @endif
                </div>
             </div>
          </td>
          <td class="text-col flex-nowrap whitespace-nowrap svelte-1aqujna">
             <div class="flex-none text-xs">{{ \Carbon\Carbon::parse($_user->created_at)->toFormattedDateString() }}</div>
          </td>
          <td class="text-col">
             <div class="flex">
              
              <a x-on:click="openModal('user-' + {{ $_user->id }})" class="rounded-full border-[1.5px] px-2 py-1 text-xs font-medium duration-200 bg-white shadow-xl border-amber-500/0 hover:border-amber-500 text-amber-600 flex items-center gap-1 --control cursor-pointer">
                <i class="fi fi-rr-attribution-pencil"></i>
                {{ __('Edit') }}
              </a>
              
              <div class="flex z-menuc ml-2" data-max-width="600" data-handle=".--control">
                  <a class="rounded-full border-[1.5px] px-2 py-1 text-xs font-medium duration-200 bg-red-400 shadow-xl text-white flex items-center gap-1 --control cursor-pointer">
                    <i class="fi fi-rr-trash"></i>
                    {{ __('Delete') }}
                  </a>

                  <div class="z-menuc-content-temp">
                      <ul class="z-menu-ul w-40em max-w-full shadow-lg border border-solid border-gray-200 rounded-xl">
                          <div class="p-6">
                            <i class="fi fi-rr-triangle-warning text-lg text-red-500"></i>
                            <div class="mt-1 text-sm text-gray-600">
                              <div>
                                <span slot="description">{{ __('Are you sure you want to delete this user? This action is irreversible.') }}</span>
                              </div>
                            </div>

                              <div class="border-b border-solid border-gray-300 my-3"></div>
                              <div class="mt-4 flex justify-end gap-2">
                                <button type="button" class=" block appearance-none rounded-md border bg-white text-sm font-medium text-gray-600 shadow-sm duration-100 focus:ring-0
                                px-3 py-1.5 block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-3 py-1.5 z-menu-close">{{ __('Cancel') }}</button>
                                
                                <form action="{{ route('console-admin-users-post', 'delete') }}" method="post">
                                  @csrf
                                  <input type="hidden" name="_user" value="{{ $_user->id }}">
                                  <button type="submit" class="first-letter: bg-red-500  text-white disabled:opacity-75 hover:bg-red-400
                                         block appearance-none rounded-lg text-sm font-medium duration-100 focus:outline-transparent px-3 py-1.5">
                                         <div class="relative flex items-center justify-center "><div class="duration-100">{{ __('Delete') }}</div>
                                    </div>
                                </button>
                                </form>
                                        
                              </div>
                          </div>
                      </ul>
                  </div>
              </div>
            </div>
          </td>
          <td class="py-4"></td>
       </tr>
       @endforeach
    </tbody>
 </table>

 {{ $users->links() }}

  </div>

  </div>

  @foreach ($users as $item)
    <div>
      <div x-cloak x-show="isShownModal('user-' + {{ $item->id }})" x-transition.opacity.duration.500ms class="alpine-dialog-modal">
        <div class="-alpine-modal-overflow" x-on:click="closeModal('user-' + {{ $item->id }})"></div>
        <div class="-alpine-dialog h-full w-full transform overflow-auto bg-white text-left align-bottom shadow-xl sm:w-full sm:max-w-lg top-0 right-0 left-auto --no-pop" x-show="isShownModal('user-' + {{ $item->id }})" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform scale-90" x-transition:enter-end="opacity-100 transform scale-100" x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100 transform scale-100" x-transition:leave-end="opacity-0 transform scale-90">
            <div>
              @includeIf('admin.users.edit', ['_user' => $item])
            </div>
        </div>
      </div>
  </div>
  @endforeach
</div>
@endsection

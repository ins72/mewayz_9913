<div class="w-[100%]">
    <div class="flex flex-col py-2">
        <div class="flex flex-col items-start">
            <div class="flex justify-between items-center w-[100%]">
                <div class="bg-[#cccccc] flex w-[100%] h-1 w-4 rounded-md"></div>
                <div class="bg-[#cccccc] flex w-[100%] h-1 w-4 rounded-md"></div>
            </div>

            <div class="w-[100%] flex flex-col items-center justify-center mt-1 h-8 bg-[#cccccc]">
                <div class="w-14 h-[2px] bg-white rounded-none"></div>
                <div class="w-10 h-[2px] bg-white rounded-none mt-[2px]"></div>
                <div class="w-4 h-1 bg-white rounded-none mt-[2px]"></div>
            </div>
        </div>
    </div>
</div>
<div class="w-[100%]">
    <div class="flex flex-col py-2">
        <div class="flex flex-col items-start">
            <div class="flex justify-between items-center w-[100%]">
                <div class="bg-[#cccccc] flex w-[100%] h-1 w-4 rounded-md"></div>
                <div class="bg-[#cccccc] flex w-[100%] h-1 w-4 rounded-md"></div>
            </div>

            <div class="w-[100%] flex flex-col items-center px-2 mt-1">
                <div class="w-[100%] h-1 bg-[#cccccc] rounded-none"></div>
                <div class="w-[100%] h-4 bg-[#cccccc] rounded-none mt-[2px]"></div>
                <div class="bg-[#cccccc] flex h-1 w-4 rounded-md mt-[2px]"></div>
            </div>
        </div>
    </div>
</div>
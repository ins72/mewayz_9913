<div class="w-[100%] h-full">
    <div class="flex flex-col py-0 h-full">

        <div class="border border-solid border-[#cccccc] flex items-center justify-center rounded-xs h-full w-[100%]">
            <div class="bg-[#cccccc] flex h-1 w-8 rounded-md"></div>
        </div>
    </div>
</div>
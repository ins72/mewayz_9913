
<?php

   use App\Yena\Page\Generate;
   use App\Models\BioSite;
   use Illuminate\Support\Facades\Validator;
   use function Livewire\Volt\{state, mount, placeholder};

   placeholder('
   <div class="p-5 w-full mt-1">
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)]"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
      <div class="--placeholder-skeleton w-full h-[30px] rounded-[var(--yena-radii-sm)] mt-1"></div>
   </div>');


   state([
      'address' => '',
   ]);

   state(['site']);

   // Methods

   $createPage = function(){
      $this->skipRender();
      // $_c = SitePage::where('site_id', $this->site->id)->count();
      // if(__o_feature('consume.pages', iam()) != -1 && $_c >= __o_feature('consume.pages', iam())){
      //    $this->js('window.runToast("error", "'. __('You have reached your page creation limit. Please upgrade your plan.') .'");');
      //    return;
      // }
      // Create Page
      // $name = "Untitled-" . ao($template, 'name');
      // $slug = slugify(ao($_page, 'name') . str()->random(3), '-');

      $generate = new Generate;
      $build = $generate->setOwner(iam())->setName('My new Page')->build();


      $route = route('console-bio-index', ['slug' => $build->_slug]);
      return redirect($route);
   };

   $checkAddress = function($address){
      $address = slugify($address, '-');
      $validator = Validator::make([
         'address' => $address
      ], [
         'address' => 'required|string|min:3|unique:bio_sites'
      ]);

      if($validator->fails()){
         $this->js('$store.builder.savingState = 2');
         return [
            'status' => 'error',
            'response' => $validator->errors()->first('address'),
         ];
      }

      $this->js('$store.builder.savingState = 2');
      return [
         'status' => 'success',
         'response' => __(':address is available', ['address' => $address]),
      ];
   };
?>

<div>
  <div x-data="builder__new_page">
   
      <div>
         <div class="design-navbar">
            <ul >
                <li class="close-header !flex">
                  <a @click="createPage=false">
                    <span>
                        {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                    </span>
                  </a>
               </li>
               <li class="!pl-0">{{ __('Add Page') }}</li>
               <li></li>
            </ul>
         </div>
         <div class="container-small">
          <div class="p-5">
            <form @submit.prevent="$wire.createPage(); buttonLoader=true;" class="">
               <div class="flex flex-col gap-3">
                  {{-- <div class="text-xl font-extrabold tracking-[-1px]">{{ __('Domain') }}</div> --}}
                  <div class="flex flex-col justify-center items-center px-[20px] pt-[60px]">
                     {!! __i('Internet, Network', 'Browser, Internet, Web, Network, Site', 'w-14 h-14') !!}
                     <p class="mt-3 text-[var(--c-mix-3)] text-center text-[var(--t-m)]">
                        {!! __t('Take your time to think of something unique and creative for your linkinbio address.') !!}
                     </p>
                  </div>
               </div>

               <div class="custom-content-input border-2 border-dashed mb-1">
                  <label class="h-10 !flex items-center px-5">
                     <span class="text-sm">{{ config('app.bio_address') . config('app.bio_prefix') . '/' }}</span>
                  </label>
                  <input type="text" x-model="address" @input="checkAddress()" placeholder="{{ __('Address') }}" class="w-[100%] !bg-gray-100">
               </div>

               <template x-if="backendError">
                  <div class="bg-red-200 text-[11px] p-1 px-2 mb-1 rounded-full">
                     <div class="flex items-center">
                        <div>
                           <i class="fi fi-rr-cross-circle flex text-xs"></i>
                        </div>
                        <div class="flex-grow ml-1 text-xs !text-black" x-text="backendError"></div>
                     </div>
                  </div>
               </template>
               <template x-if="addressAvailable">
                  <div class="bg-green-200 text-[11px] p-1 px-2 mb-1 rounded-full">
                     <div class="flex items-center">
                        <div>
                           <i class="ph ph-checkmark flex text-xs"></i>
                        </div>
                        <div class="flex-grow ml-1 text-xs !text-black" x-text="addressAvailable"></div>
                     </div>
                  </div>
               </template>
                                    

               <button class="yena-button-stack w-[100%]" :disabled="!backendError && !addressAvailable || backendError && !addressAvailable">
                  <span :class="{
                        'hidden': !buttonLoader,
                        'flex': buttonLoader
                  }">
                        <span class="loader-o20 !text-[9px] mx-auto !text-black"></span>
                  </span>
                  <span x-show="!buttonLoader">{{ __('Continue') }}</span>
               </button>
            </form>
          </div>
         </div>
      </div>
  </div>
  @script
      <script>
          Alpine.data('builder__new_page', () => {
             return {
               buttonLoader: false,
               address: @entangle('address'),
               addressAvailable: null,
               backendError: null,
               checkAddress(){

                  let $this = this;
                  let address = this.address;
                  address = address.toString() // Cast to string
                              .toLowerCase() // Convert the string to lowercase letters
                              .normalize('NFD') // The normalize() method returns the Unicode Normalization Form of a given string.
                              .trim() // Remove whitespace from both sides of a string
                              .replace(/\s+/g, '-') // Replace spaces with -
                              .replace(/[^\w\-]+/g, '') // Remove all non-word chars
                              .replace(/\-\-+/g, '-');
                  this.address = address;

                  $this.backendError = null;
                  $this.addressAvailable = null;
                  $this.buttonLoader = true;
                  clearTimeout($this.autoSaveTimer);

                  $this.autoSaveTimer = setTimeout(function(){
                     $this.$store.builder.savingState = 0;
                     
                     $this.$wire.checkAddress(address).then(r => {
                        $this.buttonLoader = false;
                        if(r.status == 'error'){
                           $this.backendError = r.response;
                           $this.addressAvailable = null;
                        }
                        if(r.status == 'success'){
                           $this.backendError = null;
                           $this.addressAvailable = r.response;
                        }
                     });

                  }, $this.$store.builder.autoSaveDelay);
               },
               init(){
                  let $this = this;
               }
             }
          });
      </script>
  @endscript
</div>

<?php

   use App\Livewire\Actions\Logout;
   use function Livewire\Volt\{on};

   on([

      'logout' => function(Logout $logout){
        $logout();
        $this->redirect(route('login'), navigate: true);
      },
   ]);
?>
<div></div>

<div>
    <textarea name="data[text]" rows="6" class="w-full" x-model="item.lesson_data.text" class="editor" placeholder="{{ __('Start typing with plain text') }}"></textarea>
</div>

<div class="w-[100%]">
    <div class="flex flex-col p-1">
        <div class="flex flex-col items-start">
            <div class="w-10 h-1 bg-[#cccccc] rounded-full"></div>
            <div class="bg-[#cccccc] flex h-4 rounded-xs text-white items-center justify-center px-1 gap-1 w-[100%] mt-[2px]">
                {!! __i('Type, Paragraph, Character', 'image-square', 'w-3 h-3') !!}
            </div>
            <div class="bg-[#cccccc] flex h-[5px] rounded-xs !mt-1 w-[100%]"></div>
            <div class="bg-[#cccccc] flex h-[5px] rounded-xs !mt-1 w-[100%]"></div>
        </div>
    </div>
</div>
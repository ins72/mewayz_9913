<div wire:ignore>

    <div x-data="builder__sectionGallery">


        <div x-show="__page == 'section'">
            <div>
               <x-livewire::components.builder.parts.section />
            </div>
        </div>
      
        <template x-for="(item, index) in section.items" :key="item.uuid">
          <div x-show="__page == 'section::gallery::' + item.uuid">
              <div>
                  <x-livewire::sections.gallery.partial.edit.items />
              </div>
          </div>
        </template>
      
        <div x-cloak x-show="__page == '-'">
          <div class="banner-section !block">
              <div>
          
                  <div class="banner-navbar">
                      <ul >
                          <li class="close-header !flex">
                          <a @click="navigatePage('pages')">
                              <span>
                                  {!! __i('Arrows, Diagrams', 'Arrow.8', '!w-6 !h-6') !!}
                              </span>
                          </a>
                      </li>
                      <li class="!pl-0">{{ __('Gallery') }}</li>
                      <li></li>
                      </ul>
                  </div>
                  <div class="sticky container-small">
                      <div class="tab-link">
                          <ul class="tabs">
                          <li class="tab !w-full" @click="__tab = 'content'" :class="{'active': __tab == 'content'}">{{ __('Content') }}</li>
                          <li class="tab !w-full" @click="__tab = 'style'" :class="{'active': __tab == 'style'}">{{ __('Style') }}</li>
                          </ul>
                      </div>
                  </div>
                  <div class="container-small tab-content-box">
                      <div class="tab-content">
                          <div x-cloak x-show="__tab == 'content'" data-tab-content>
                              <x-livewire::sections.gallery.partial.edit.content/>
                          </div>
                          <div x-cloak x-show="__tab == 'style'" data-tab-content>
                              <x-livewire::sections.gallery.partial.edit.style />
                          </div>
                      </div>
                  </div>
              </div>
            </div>
        </div>
      
    </div>
  @script
  <script>
      Alpine.data('builder__sectionGallery', () => {
         return {
            autoSaveTimer: null,
            __tab: 'content',
            __page: '-',
            skeleton: {
                label: '',
                title: '',
            },

            itemSkeleton: {

            },

            __delete_item(item_id){
                var index = 0;

                this.section.items.forEach(element => {
                    if(item_id == element.uuid){
                        this.section.items.splice(index, 1);
                    }

                    index++;
                });

                this.__page = '-';

                this.$dispatch('section::deleteItem', {
                   item: item_id
                });
            },

            createItem(){
                var $this = this;

                let item = {
                    uuid: this.$store.builder.generateUUID(),
                    content: {
                        'image': null,
                        'link': '',
                        'desktop_size': 1,
                        'mobile_size': 1,
                    },
                };
                $this.section.items.push(item);
                var $index = $this.section.items.length-1;

                this.$dispatch('section::create_section_item', {
                    item: item,
                    section_id: this.section.uuid,
                });
            },
            _save(){
                var $this = this;
                var $eventID = 'section::' + this.section.uuid;


                $this.$dispatch($eventID, $this.section);
                clearTimeout($this.autoSaveTimer);

                $this.autoSaveTimer = setTimeout(function(){
                    $this.$store.builder.savingState = 0;

                    event = new CustomEvent("builder::save_sections_and_items", {
                        detail: {
                            section: $this.section,
                            js: '$store.builder.savingState = 2',
                        }
                    });

                    window.dispatchEvent(event);
                }, $this.$store.builder.autoSaveDelay);
            },

            dispatchSections(){
                var $this = this;
                $this.$dispatch('sectionItem::' + this.section.uuid, $this.section.items);
            },

            init(){
               //if(!this.section) this.section = this.skeleton;
               var $this = this;
               var $eventID = 'section::' + this.section.uuid;

               //this.section.items = window._.sortBy(this.section.items, 'position');

                if(this.section.items === undefined || this.section.items == null){
                    this.section.items = [];
                }

                if(this.section.section_settings === undefined || this.section.section_settings == null){
                    this.section.section_settings = {
                        color: 'transparent',
                    };
                }

                this.$watch('section' , (value, _v) => {
                    $this._save();
                });

               this.$watch('section.items' , (value, _v) => {
                    $this.dispatchSections();
                    $this._save();
               });

               window.Sortable.create(this.$refs.sortable_wrapper, {
                    animation: 150,
                    sort: true,
                    scroll: true,
                    scrollSensitivity: 100,
                    delay: 100,
                    delayOnTouchOnly: true,
                    group: false,
                    swapThreshold: 5,
                    filter: ".disabled",
                    preventOnFilter: true,
                    containment: "parent",
                    handle: '.handle',
                    onEnd: (event) => {
                        let steps = Alpine.raw(window._.sortBy(this.section.items, 'position'))
                        let moved_step = steps.splice(event.oldIndex, 1)[0]
                        steps.splice(event.newIndex, 0, moved_step)
                        
                        // HACK update prevKeys to new sort order
                        let keys = []
                        steps.forEach((step, i) => {
                            keys.push(step.uuid);

                            $this.section.items.forEach((x, _i) => {
                              if(x.uuid == step.uuid) x.position = i;
                            });
                        });

                        this.$refs.sortable_template._x_prevKeys = keys
                    },
                });
            }
         }
      });
  </script>
  @endscript
</div>
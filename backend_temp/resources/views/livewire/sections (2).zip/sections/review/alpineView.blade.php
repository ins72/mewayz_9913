<div>

    @php
        $classes = collect([
            'review-box',
            'section-width-fill',
            'box',
            'section-bg-wrapper', 
            'focus'
        ]);

        $classes = $classes->toArray();
    @endphp
    <div class="{{ implode(' ', $classes) }}" x-data="builder__reviewSectionView" :class="sectionClass" :style="{'--section-image': 'url('+$store.builder.getMedia(section.section_settings !== null && section.section_settings.image)+')'}">
      <div class="text-left inner-content" :class="{
         'text-left': section.settings.align == 'left' || section.settings.split_title,
         'text-center': !section.settings.split_title && section.settings.align == 'center',
         'text-right': !section.settings.split_title && section.settings.align == 'right',
         'w-boxed min-shape': section.section_settings.width == 'fit'
        }">
        
        
         <div class="review-section w-boxed !border-none" :class="{
            'background': section.settings.background,
            'border': section.settings.border,
            'space-below': !section.settings.background && !section.settings.border,

            'left-title': section.settings.split_title,
            'layout-1': section.settings.style == '1',
            'layout-2': section.settings.style == '2',

            'left': section.settings.align == 'left',
            'center': section.settings.align == 'center',
            'right': section.settings.align == 'right',
         }">
            <div class="review-header">
               <div class="[text-align:inherit]">
                <template x-if="section.content.label">
                   <span class="gallery-label t-0" x-text="section.content.label"></span>
                </template>
               </div>
               <template x-if="section.content.title">
               <h2 class="t-4 pre-line [text-align:inherit] --text-color" x-text="section.content.title"></h2>
               </template>
               <template x-if="section.content.subtitle">
                  <p class="t-1 pre-line subtitle [text-align:inherit] --text-color" x-text="section.content.subtitle"></p>
               </template>
            </div>

            <div class="review-container grid [--scroll-speed:22.5s]" :style="{
               '--columns': section.settings.desktop_grid,
               '--mobile-columns': section.settings.mobile_grid
            }">
               <template x-for="(item, index) in window._.sortBy(section.items, 'position')" :key="item.uuid">
                  <div class="review yena-section-items" :data-id="item.uuid">
                     <a href="javascript:void(0)" name="review-link" class="review-link min-shape row-reverse">
                        <div class="review-item">
                           <template x-if="section.settings.rating">
                              <div class="review-icon">
                                 <template x-if="section.settings.type == 'quote'">
                                    <span ><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m18.187 18.893c2.6255 0 4.8133-2.1878 4.8133-4.8133 0-2.6254-2.1878-4.8132-4.8133-4.8132h-0.6563c0.2188-1.3127 0.4376-1.7503 2.2972-3.6099-2.7348 0.21878-7.548 3.5006-6.5635 8.7514 0.547 2.8442 2.2972 4.4851 4.9226 4.4851z" fill="var(--accent)"></path><path d="m1.1307 14.626c0.43757 2.6254 2.2972 4.2663 4.9226 4.2663s4.8133-2.1878 4.8133-4.8133c0-2.6254-2.1879-4.8132-4.8133-4.8132h-0.65635c0.21878-1.3127 0.43757-1.7503 2.2972-3.6099-2.7348 0.32818-7.5481 3.6099-6.5635 8.9702z" fill="var(--accent)"></path></svg></span>
                                 </template>
                                 <template x-if="section.settings.type == 'stars'">
                                    <template x-for="(star, index) in ratings" :key="index">
                                       <span>
                                          <template x-if="item.content.rating>=star">
                                             <svg fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path d="m12 16.733-6.1667 4.6 2.3667-7.4-6.2-4.6h7.6667l2.3333-7.3333 2.3333 7.3333h7.6667l-6.2 4.6 2.3667 7.4-6.1667-4.6z" clip-rule="evenodd" fill="var(--accent)" fill-rule="evenodd"></path>
                                             </svg>
                                          </template>
                                          <template x-if="item.content.rating<star">
                                             <svg fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path d="m12 16.733-6.1667 4.6 2.3667-7.4-6.2-4.6h7.6667l2.3333-7.3333 2.3333 7.3333h7.6667l-6.2 4.6 2.3667 7.4-6.1667-4.6z" clip-rule="evenodd" fill="var(--c-mix-10)" fill-rule="evenodd"></path>
                                             </svg>
                                          </template>
                                       </span>
                                    </template>
                                 </template>
   
                              </div>
                           </template>
                           <div class="review-text">
                              <h3 class="pre-line t-1" :class="{
                                 't-1': section.settings.text == 's' || section.settings.text == 'm',
                                 'small-size': section.settings.text == 's',
                                 '!font-bold': section.settings.text == 'm',
                                 't-2 !font-bold': section.settings.text == 'l',
                              }" x-text="item.content.text"></h3>
                           </div>
                        </div>
                        <div class="reviewer-details">

                           <template x-if="section.settings.avatar">
                              <div class="reviewer-image min-shape square" :class="{
                                 'square': section.settings.shape == 'square',
                                 'avatar-image': section.settings.shape == 'circle',
                              }">
                                 <template x-if="item.content.image">
                                    <img :src="$store.builder.getMedia(item.content.image)" alt="">
                                 </template>
                                 <template x-if="!item.content.image">
                                    <div class="default-image">
                                       {!! __i('--ie', 'image-picture', 'text-gray-300 w-5 h-5') !!}
                                    </div>
                                 </template>
                              </div>
                           </template>
                           <div class="reviewer-description">
                              <p class="pre-line name t-0" x-text="item.content.title"></p>
                              <p class="pre-line about t-0" x-text="item.content.bio"></p>
                           </div>
                        </div>
                     </a>
                     <div class="screen"></div>
                  </div>

                  {{-- <div class="cursor-none card" :class="{
                     'min-shape': section.settings.border,
                  }">
                     <a href="javascript:void(0)" target="" name="card-link" class="bottom" :class="{
                        'top': section.settings.layout_align == 'top',
                        'center': section.settings.layout_align == 'center',
                        'bottom': section.settings.layout_align == 'bottom',
                        '!p-0 !bg-transparent': !section.settings.background,
                     }">
                        <div class="card-text" :class="{
                           'min-shape': section.settings.style == '2',
                           'glass': section.settings.glass
                        }">
                           <div class="pre-line t-1" :class="{
                              't-1': section.settings.text == 's' || section.settings.text == 'm',
                              'small-size': section.settings.text == 's',
                              '!font-bold': section.settings.text == 'm',
                              't-3 !font-bold': section.settings.text == 'l',
                           }" x-text="item.content.title"></div>
                           
                           <template x-if="section.settings.style == '2'">
                              <div class="description mt-1 [text-align:inherit]">
                                 <p class="pre-line t-0 [text-align:inherit]" :class="{
                                    't-0': section.settings.text == 's' || section.settings.text == 'm',
                                    't-1': section.settings.text == 'l',
                                 }" x-text="item.content.text"></p>
                              </div>
                           </template>
                           <template x-if="section.settings.style == '2' && item.content.button">
                              <button class="card__button site-btn t-1 shape" onclick="window.open('javascript:void(0)', '_self')" :class="{
                                 'grey': item.content.color == 'default' || !item.content.color,
                                 'accent': item.content.color == 'accent', 
                              }" x-text="item.content.button"></button>
                           </template>
                        </div>

                        
                        <div class="card-image min-shape !h-[var(--image-height)]" :class="{
                           '!hidden': section.settings.style == '1' && !section.settings.enable_image
                        }">
                           <template x-if="item.content.image">
                              <img :src="$store.builder.getMedia(item.content.image)" alt="" class="!h-[var(--image-height)]">
                           </template>
                           <template x-if="!item.content.image">
                              <div class="default-image">
                                 {!! __i('--ie', 'image-picture', 'text-gray-300 w-5 h-5') !!}
                              </div>
                           </template>                     
                        </div>
                        
                        <template x-if="section.settings.style == '1'">
                           <div class="card-text">
                              <div class="description mt-1 [text-align:inherit]">
                                 <p class="pre-line t-0 [text-align:inherit]" :class="{
                                    't-0': section.settings.text == 's' || section.settings.text == 'm',
                                    't-1': section.settings.text == 'l',
                                 }" x-text="item.content.text"></p>
                              </div>
                           </div>
                        </template>
                        <template x-if="section.settings.style == '1' && item.content.button">
                           <button class="card__button site-btn t-1 shape" onclick="window.open('javascript:void(0)', '_self')" :class="{
                              'grey': item.content.color == 'default' || !item.content.color,
                              'accent': item.content.color == 'accent', 
                           }" x-text="item.content.button"></button>
                        </template>
                     </a>
                     <div class="screen"></div>
                  </div> --}}
               </template>
            </div>
         </div>
      </div>
   </div>
     @script
     <script>
         Alpine.data('builder__reviewSectionView', () => {
            return {
               items: {},
               ratings: [1,2,3,4,5],
               sectionClass: function(){
                  var $class = {
                     ...this.$store.builder.generateSectionClass(this.site, this.section),
                     'min-shape': false,
                     'section-bg-wrapper': false,
                  };

                  return $class;
               },
               sectionStyles: function(){
                return this.$store.builder.generateSectionStyles(this.section);
               },

               sectionClasses: function(){
                this.sectionClass();
                this.sectionStyles();
               },

               init(){
                  // console.log('lll', this.section, this.section.items)
                  //console.log(this.items)
                  var $this = this;
                  this.items = this.section.items;
                  window.addEventListener('section::' + this.section.uuid, (event) => {
                      $this.section = event.detail;
                     $this.sectionClasses();
                  });

                  window.addEventListener('sectionItem::' + this.section.uuid, (event) => {
                      $this.items = event.detail;
                  });
               }
            }
         });
     </script>
     @endscript
     
</div>
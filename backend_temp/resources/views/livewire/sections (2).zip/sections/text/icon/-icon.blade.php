
<div class="w-[100%]">
    <div class="flex flex-col p-1">
        <div class="flex flex-col items-start">
            <div class="w-10 h-1 bg-[#cccccc] rounded-none"></div>
            <div class="w-[100%] h-[1px] bg-[#cccccc] rounded-none !mt-2"></div>
            <div class="w-[100%] h-[1px] bg-[#cccccc] rounded-none mt-[3px]"></div>
            <div class="w-[100%] h-[1px] bg-[#cccccc] rounded-none mt-[3px]"></div>
            <div class="w-[100%] h-[1px] bg-[#cccccc] rounded-none mt-[3px]"></div>
            <div class="w-[100%] h-[1px] bg-[#cccccc] rounded-none mt-[3px]"></div>
            <div class="w-[100%] h-[1px] bg-[#cccccc] rounded-none mt-[3px]"></div>
        </div>
    </div>
</div>
export interface LoadingWrapperProps {
  label?: string
}

export interface LoaderProps extends LoadingWrapperProps {
  hasOverlay?: boolean
}

<template>
  <button :class="dropdownClass" class="">
    <slot></slot>
  </button>
</template>

<script>
export default {
  props: ['isActive', 'disabled'],
  data() {
    return {
      dropdownClass: ''
    }
  },
  mounted() {
    this.dropdownClass = this.calculateDropdownClass()
  },
  methods: {
    calculateDropdownClass() {
      let classes = 'flex items-center gap-2 p-1.5 text-sm font-medium text-neutral-500 dark:text-neutral-400 text-left bg-transparent w-full rounded ';

      
      if (!this.isActive && !this.disabled) classes += 'hover:bg-neutral-100 hover:text-neutral-800 dark:hover:bg-neutral-900 dark:hover:text-neutral-200 ';

      if (this.isActive && !this.disabled) classes += 'bg-neutral-100 text-neutral-800 dark:bg-neutral-900 dark:text-neutral-200 ';
      
      if (this.disabled) classes += 'text-neutral-400 cursor-not-allowed dark:text-neutral-600 ';

      return classes;
    }
  }
}
</script>

<style scoped>
</style>

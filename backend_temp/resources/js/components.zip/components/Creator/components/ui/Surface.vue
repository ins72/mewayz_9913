<template>
  <div :class="surfaceClass" ref="surfaceRef">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'Surface',
  props: {
    withShadow: {
      type: Boolean,
      default: true
    },
    withBorder: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      surfaceClass: ''
    }
  },
  mounted() {
    this.surfaceClass = this.calculateSurfaceClass()
  },
  methods: {
    calculateSurfaceClass() {
      const classes = ['bg-white', 'rounded-lg', 'dark:bg-black']
      if (this.withShadow) {
        classes.push('shadow-sm')
      }
      if (this.withBorder) {
        classes.push('border', 'border-neutral-200', 'dark:border-neutral-800')
      }
      return classes.join(' ')
    }
  }
}
</script>

<style scoped>
/* Add any additional styles here */
</style>

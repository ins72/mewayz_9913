<script>
import { defineAsyncComponent } from 'vue';

export default {
  props: {
    name: {
      type: String,
      required: true,
    },
  },

  computed: {
    dynamicComponent() {
      const name = this.name;
      const assetsUrl = '';

      return defineAsyncComponent(() => import(`/public/assets/__icons/${name}.svg`));
    },
  },
};
</script>

<template>
  <component :is="dynamicComponent" />
</template>
<template>
  <div class="site-popover p-[16px] !w-[100vw] !max-w-[280px]">
    <div class="stack -gap-16">
        <h4>Section</h4>
        <div class="field">
            <label class="field_label">Minimum height</label>
            <div class="segmented-control -smaller">
              <button class="segmented-control_item" v-on:click="changeAttr('sectionHeight', '-')" :class="{'-active': node.attrs.sectionHeight == '-'}" type="button">Small</button>

              <button class="segmented-control_item" v-on:click="changeAttr('sectionHeight', 'medium')" :class="{'-active': node.attrs.sectionHeight == 'medium'}" type="button">Medium</button>

              <button class="segmented-control_item" v-on:click="changeAttr('sectionHeight', 'large')" :class="{'-active': node.attrs.sectionHeight == 'large'}" type="button">Large</button>
            </div>
        </div>
        <div class="field">
            <label class="field_label">Align content</label>
            <div class="segmented-control -smaller">
              <button class="segmented-control_item" v-on:click="changeAttr('sectionAlign', 'left')" :class="{'-active': node.attrs.sectionAlign == 'left'}" type="button">
                  <Icon name="Type, Paragraph, Character/align-left" class="w-4 h-4" />
              </button>
              <button class="segmented-control_item" v-on:click="changeAttr('sectionAlign', 'center')" :class="{'-active': node.attrs.sectionAlign == 'center'}" type="button">
                  <Icon name="Type, Paragraph, Character/align-center" class="w-4 h-4" />
              </button>
              <button class="segmented-control_item" v-on:click="changeAttr('sectionAlign', 'right')" :class="{'-active': node.attrs.sectionAlign == 'right'}" type="button">
                  <Icon name="Type, Paragraph, Character/align-right" class="w-4 h-4" />
              </button>
            </div>
        </div>
        <div class="field"><label class="field_label" for="section-id">ID</label><input class="input -smaller" id="section-id" placeholder="section-name" autocomplete="off" type="text" value=""></div>
        <div class="field">
            <label class="field_label" for="image">Background image</label>
            <div class="flex -gap-8"><label class="button -smaller -secondary"><input hidden="" accept=".png,.jpeg,.jpg,.gif,.svg" type="file">Choose file</label></div>
        </div>
        <div class="field">
            <label class="field_label">Theme</label>
            <button type="button" role="combobox" aria-controls="radix-:rec:" aria-expanded="false" aria-autocomplete="none" dir="ltr" data-state="closed" class="custom-select -small theme -default">
              <span style="pointer-events: none;">
                  <div class="theme -default">Default</div>
              </span>
              <span aria-hidden="true" class="custom-select_indicator">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square" stroke-linejoin="arcs">
                    <path d="m6 9 6 6 6-6"></path>
                  </svg>
              </span>
            </button>
        </div>
      </div>

  </div>
</template>
  
<script>
  import { NodeViewContent, nodeViewProps, NodeViewWrapper } from '@tiptap/vue-3'
  import Icon from "../../components/ui/Icon.vue"
  
  export default {
	  props: nodeViewProps,
  
    components: {
      NodeViewWrapper,
      NodeViewContent,
      Icon
    },

    methods: {
      changeAttr(attr, value) {
        let object = {};

        object[attr] = value;
        this.updateAttributes(object);
      }
    },

    mounted(){
      console.log(this.editor)
    }
  }
  </script>
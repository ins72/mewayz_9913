<template>
  <node-view-wrapper class="section-node">
    <div contenteditable="false">
      <div class="flex -gap-8">
        <div class="toolbar -active !opacity-100 !pointer-events-auto ml-auto mr-5 mt-5">
            <button class="toolbar_item cursor-pointer" data-state="closed">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 19V6m-7 6 7-7 7 7"></path>
              </svg>
            </button>
            <button class="toolbar_item edit-section-button" type="button">
              <Icon name="Design Tools/Settings.2" />
            </button>
            <button class="toolbar_item" type="button" id="radix-:rd7:" aria-haspopup="menu" aria-expanded="true" data-state="open" aria-controls="radix-:rd8:">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="arcs">
                  <circle cx="12" cy="12" r="1"></circle>
                  <circle cx="19" cy="12" r="1"></circle>
                  <circle cx="5" cy="12" r="1"></circle>
              </svg>
            </button>
        </div>
      </div>

      
    </div>
    <div contenteditable="false">
      <button
        @click="editor.chain().focus().toggleBold().run()"
        :class="{ 'is-active': editor.isActive('bold') }"
      >
        

      
      </button>
    </div>

    <div class="flex">
      <div class="editor_space -active relative">
        <button class="editor_space-handle"></button>
        <div class="editor_space-value">96</div>
      </div>
    </div>

    <node-view-content class="section" :class="{
      '-medium': node.attrs.sectionHeight == 'medium',
      '-large': node.attrs.sectionHeight == 'large',
      '-justify-left': node.attrs.sectionAlign == 'left',
      '-justify-right': node.attrs.sectionAlign == 'right',
    }" />
  </node-view-wrapper>
</template>
  
<script>
  import { NodeViewContent, nodeViewProps, NodeViewWrapper } from '@tiptap/vue-3'
  import { VueRenderer } from '@tiptap/vue-3';
  import tippy from 'tippy.js';
  import SectionSettings from './SectionSettings.vue';
  import Icon from "../../components/ui/Icon.vue";
  
  export default {
	  props: nodeViewProps,
  
    components: {
      NodeViewWrapper,
      NodeViewContent,
      Icon
    },

    methods: {
      createEditSectionTippy(){
        const props = this;
        let component = new VueRenderer(SectionSettings, {
          props,
          editor: props.editor,
        });


        
        let popup = tippy(this.$el.querySelector('.edit-section-button'), {
          interactive: true,
          trigger: 'click',
          placement: 'bottom',
          theme: 'slash-command',
          maxWidth: '350px',
          offset: [16, 8],
          appendTo: () => document.body,
          content: component.element,
          popperOptions: {
            strategy: 'fixed',
            modifiers: [
              {
                name: 'flip',
                enabled: false,
              },
            ],
          },
        });
      }
    },

    mounted(){
      this.createEditSectionTippy();
      //console.log(this.$root)
      //console.log(this.$el)
    }
  }
  </script>
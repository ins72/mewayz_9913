import { Document as TiptapDocument } from '@tiptap/extension-document'
import { Node, mergeAttributes } from '@tiptap/core'
import { VueNodeViewRenderer } from '@tiptap/vue-3'
import Component from './Component.vue'

export const SectionNode = Node.create({
	name: 'sectionNode',
	group: "section",
	content: "block+",
	draggable: true,
	isolating: true,

	addOptions: {
		HTMLAttributes: {},
	},

	addAttributes() {
		return {
		  sectionHeight: {
			default: '-',
		  },
		  sectionAlign: {
			default: 'center',
		  },
		}
	},

	parseHTML() {
		return [
			{
				tag: "section-node",
			},
		];
	},

	renderHTML({ HTMLAttributes }) {
		return ["section-node", 0];
	},

	addNodeView() {
		return VueNodeViewRenderer(Component)
	},
});

export default Document
import { Node, mergeAttributes } from '@tiptap/core'
import { VueNodeViewRenderer } from '@tiptap/vue-3'
import Component from './Component.vue';
import { VueRenderer } from '@tiptap/vue-3';
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'

export const Default = Node.create({
	name: 'paragraph',

	priority: 1000,

	group: 'block',

	content: 'inline*',
	parseHTML() {
		return [
			{ tag: 'div' },
		]
	},
	
	addAttributes() {
		return {
		  sectionSize: {
			default: 8,
		  },
		}
	},

	renderHTML({ HTMLAttributes }) {
		return ['div', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes), 0]
	},

  addNodeView() {

    // VueNodeViewRenderer(Component)
    return new VueNodeViewRenderer(Component, {
      editor: this.editor,
    });
  },

	addCommands() {
		return {
			setParagraph: () => ({ commands }) => {
				return commands.toggleNode('paragraphDiv', 'paragraphDiv')
			},
		}
	},
  
  addProseMirrorPlugins() {
    return [
		new Plugin({
		  key: new PluginKey('placeholder'),
		  props: {
			view(view) {
				console.log(view)
			}
		  },
		}),
	]
  },
});

export default Default;
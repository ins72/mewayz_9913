import { Node, mergeAttributes } from '@tiptap/core'
import { VueNodeViewRenderer } from '@tiptap/vue-3'
import Component from './Component.vue';
import { VueRenderer } from '@tiptap/vue-3';
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'

let isEmpty = 'false';
export const Default = Node.create({
	name: 'paragraph',

	priority: 1000,

	group: 'block',

	content: 'inline*',
  watch: {
    value(value) {
      const isSame = this.editor.getHTML() === value

      if (this.editor.isEmpty()) {
        this.isEmptyEditor(true)
      } else {
        this.isEmptyEditor(false)
      }

      console.log('lmaoo')

      if (isSame) {
        return
      }

      this.editor.commands.setContent(this.value, false)
    },
  },
	parseHTML() {
		return [
			{ tag: 'div' },
		]
	},
  addAttributes() {
    return {
      emptyEditor: {
        default: 2,
      },
    }
  },

  addOptions() {
    return {
      emptyEditorClass: 'is-editor-empty',
      emptyNodeClass: 'is-empty',
      placeholder: 'Write something …',
      showOnlyWhenEditable: true,
      showOnlyCurrent: true,
      includeChildren: false,
    }
  },

	renderHTML({ HTMLAttributes }) {
		return ['div', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes), 0]
	},

  addNodeView() {

    // VueNodeViewRenderer(Component)
    return new VueNodeViewRenderer(Component, {
      editor: this.editor,
    });
  },

	addCommands() {
		return {
			setParagraph: () => ({ commands }) => {
				return commands.toggleNode('paragraphDiv', 'paragraphDiv')
			},
		}
	},
  
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('placeholder'),
        props: {

          decorations(state) {
            const selection = state.selection;
            const resolved = state.doc.resolve(selection.from);
            console.log(state.doc)
            return;
            const decoration = Decoration.node(resolved.before(), resolved.after(), {class: 'current-element'});
            // This is equivalent to:
            // const decoration = Decoration.node(resolved.start() - 1, resolved.end() + 1, {class: 'current-element'});
            return DecorationSet.create(state.doc, [decoration]);
          },
          /*decorations: ({ doc, selection }) => {
            const active = this.editor.isEditable || !this.options.showOnlyWhenEditable
            const { anchor } = selection
            const decorations = []
            const { view } = this.editor

            if (!active) {
              return null
            }

            // only calculate isEmpty once due to its performance impacts (see issue #3360)
            const emptyDocInstance = doc.type.createAndFill()
            const isEditorEmpty = emptyDocInstance?.sameMarkup(doc) && emptyDocInstance.content.findDiffStart(doc.content) === null
			

            doc.descendants((node, pos) => {
              const hasAnchor = anchor >= pos && anchor <= pos + node.nodeSize
              const isEmpty = !node.isLeaf && !node.childCount
              // … dispatch a transaction, for the current position in the document … 

              if ((hasAnchor || !this.options.showOnlyCurrent) && isEmpty) {
                const classes = [this.options.emptyNodeClass]
                //console.log(view)
                
                if (isEditorEmpty) {
                  
                  classes.push(this.options.emptyEditorClass)
                }
                
                const decoration = Decoration.node(pos, pos + node.nodeSize, {
                  class: classes.join(' '),
                  'data-placeholder':
                    typeof this.options.placeholder === 'function'
                      ? this.options.placeholder({
                        editor: this.editor,
                        node,
                        pos,
                        hasAnchor,
                      })
                      : this.options.placeholder,
                })


                decorations.push(decoration)
              }

              return this.options.includeChildren
            })
            return DecorationSet.create(doc, decorations)
          },*/
        },
      }),
    ]
  },
});

export default Default;
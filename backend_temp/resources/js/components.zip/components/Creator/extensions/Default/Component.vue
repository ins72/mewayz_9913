<template>
	<node-view-wrapper class="block paragraph relative lolzz" v-bind:class="'-columns-' + node.attrs.sectionSize">
		<div><div class="flex -gap-8" style="position: absolute; z-index: 9; right: 12px; top: 12px;"><div class="toolbar"><button class="toolbar_item" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="radix-:r11:" data-state="closed"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"></path></svg></button><button class="toolbar_item" type="button" id="radix-:r13:" aria-haspopup="menu" aria-expanded="false" data-state="closed"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="arcs"><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle><circle cx="5" cy="12" r="1"></circle></svg></button></div></div><div style="position: absolute; z-index: 10; left: 50%; transform: translateX(-50%); top: 12px;"><div class="toolbar"><button class="toolbar_item" data-state="closed"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square" stroke-linejoin="arcs"><path d="M12 5v14M5 12h14"></path></svg></button></div></div><div class="editor_space" style="left: 0px; top: 0px; width: 2248px; height: 80px;"><button class="editor_space-handle"></button><div class="editor_space-value">80</div></div><div class="editor_space" style="left: 0px; top: 108.8px; width: 2248px; height: 80px;"><button class="editor_space-handle"></button><div class="editor_space-value">80</div></div><div style="position: absolute; z-index: 10; left: 50%; transform: translateX(-50%); top: 140.8px;"><div class="toolbar"><button class="toolbar_item" data-state="closed"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square" stroke-linejoin="arcs"><path d="M12 5v14M5 12h14"></path></svg></button></div></div><div class="editor_section -last" style="top: 0px; height: 188.8px;"></div></div>


		<div class="flex items-center gap-0">
			<div class="toolbar -small block-toolbar">
				<button class="toolbar_item" data-state="closed">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square" stroke-linejoin="arcs">
						<path d="M12 5v14M5 12h14"></path>
					</svg>
				</button>
				<button class="toolbar_item cursor-grab min-[24px] touch-none">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<circle cx="8" cy="12" r="1"></circle>
						<circle cx="8" cy="5" r="1"></circle>
						<circle cx="8" cy="19" r="1"></circle>
						<circle cx="16" cy="12" r="1"></circle>
						<circle cx="16" cy="5" r="1"></circle>
						<circle cx="16" cy="19" r="1"></circle>
					</svg>
				</button>
			</div>

			<div class="w-full flex items-center">
				<div class="editor_resize z-[2] h-[28.8px] !relative"  @mousedown="handleMouseDown">
					<div class="editor_resize-handle"></div>
				</div>
				
				 <div class="w-full">
					<node-view-content />
				 </div>

				<div class="editor_resize z-[2] h-[28.8px] !relative">
					<div class="editor_resize-handle"></div>
				</div>
			</div>
			<div class="toolbar -small block-toolbar">
				<button class="toolbar_item" type="button" id="radix-:rq:" aria-haspopup="menu" aria-expanded="false" data-state="closed">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="arcs">
						<circle cx="12" cy="12" r="1"></circle>
						<circle cx="19" cy="12" r="1"></circle>
						<circle cx="5" cy="12" r="1"></circle>
					</svg>
				</button>
			</div>

		</div>
	</node-view-wrapper>
</template>
  
  <script>
  import { NodeViewContent, nodeViewProps, NodeViewWrapper } from '@tiptap/vue-3'
  
  export default {
	props: nodeViewProps,

	methods: {
		handleColumnSizeChange(width){


			if(width < 417) this.updateAttributes({count: this.node.attrs.sectionSize = 12})


			if(width < 513) this.updateAttributes({count: this.node.attrs.sectionSize = 10})
		},
		handleMouseDown(event) {
			let timer;
			const parent = event.target.closest('.lolzz');
			const image = parent?.querySelector('[data-node-view-content]') ?? null;

			if (image === null) return;

			const startSize = { x: image.clientWidth, y: image.clientHeight };
			const startPosition = { x: event.pageX, y: event.pageY };

			const onMouseMove = (mouseMoveEvent) => {

				let width = startSize.x - startPosition.x + mouseMoveEvent.pageX;
				document.querySelector('.editor_grid').classList.add('-active');

				clearTimeout(timer)
    			timer = setTimeout(function(){
					document.querySelector('.editor_grid').classList.remove('-active');
				}, 300)

				this.handleColumnSizeChange(width);
				console.log(width)
			};

			const onMouseUp = () => {
				document.body.removeEventListener('mousemove', onMouseMove);
			};

			document.body.addEventListener('mousemove', onMouseMove);
			document.body.addEventListener('mouseup', onMouseUp, { once: true });
		},
  	},
  
	components: {
	  NodeViewWrapper,
	  NodeViewContent,
	},
  }
  </script>
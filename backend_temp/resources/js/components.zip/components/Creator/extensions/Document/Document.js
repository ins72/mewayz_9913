import { Document as TiptapDocument } from '@tiptap/extension-document'
import { Node, mergeAttributes } from '@tiptap/core'
import { VueNodeViewRenderer } from '@tiptap/vue-3'
import Component from './Component.vue'

export const Document = Node.create({
	name: 'doc',

	topNode: true,
	content: '(block|section)+',

	addOptions: {
		HTMLAttributes: {},
	},

	//group: 'block',

	//content: 'inline*',
  //content: '(block|columns)+',

	parseHTML() {
		return [
			{ tag: 'div' },
		]
	},

	renderHTML({ HTMLAttributes }) {
		return ['div', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes), 0]
	},

  addNodeView() {
    return VueNodeViewRenderer(Component)
  },
});

export default Document
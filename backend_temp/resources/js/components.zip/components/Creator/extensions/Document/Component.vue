<template>
	<node-view-wrapper>
		
		sdfsdfd
	  <node-view-content class="content" />
	</node-view-wrapper>
  </template>
  
  <script>
  import { NodeViewContent, nodeViewProps, NodeViewWrapper } from '@tiptap/vue-3'
  
  export default {
	props: nodeViewProps,
  
	components: {
	  NodeViewWrapper,
	  NodeViewContent,
	},
  }
  </script>
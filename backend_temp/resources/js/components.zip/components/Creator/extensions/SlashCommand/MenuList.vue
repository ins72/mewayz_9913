<template>
  <div ref="scrollContainer" class="yena-menu-list">
    <div class="yena-menu-list-padd">

      <div class="flex flex-col gap-0.5">
        <template v-for="(group, groupIndex) in items" :key="`${group.title}-wrapper`">
          <div class="menu_heading">{{ group.title }}</div>
          <div class="flex flex-col gap-0.5">
            <template v-for="(command, commandIndex) in group.commands" :key="`${command.label}`">
              <button class="yena-menu-list-item" :class="{'-active': selectedGroupIndex === groupIndex && selectedCommandIndex === commandIndex}" @click="createCommandClickHandler(groupIndex, commandIndex)">
                <span class="-icon">
                  <Icon :name="command.iconName" class="w-5 h-5" />
                </span>
                <span class="-name">{{ command.label }}</span>
                <span v-if="command.command" class="-command">{{ command.command }}</span>
              </button>
            </template>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import Icon from "../../components/ui/Icon.vue"
import { ref, onMounted, onBeforeUnmount } from 'vue'

export default {
  props: ['items', 'editor', 'range', 'query', 'text', 'command', 'decorationNode', 'clientRect'],
  
  name: 'MenuList',
  components: {
    Icon
  },
  setup(props) {
    const scrollContainer = ref(null)
    const activeItem = ref(null)
    const selectedGroupIndex = ref(0)
    const selectedCommandIndex = ref(0)

    // Anytime the groups change, i.e. the user types to narrow it down, we want to
    // reset the current selection to the first menu item
    onMounted(() => {
      selectedGroupIndex.value = 0
      selectedCommandIndex.value = 0
    })

    const selectItem = (groupIndex, commandIndex) => {
      const command = props.items[groupIndex].commands[commandIndex]
      props.command(command)
    }

    const onKeyDown = ({ event }) => {
      if (event.key === 'ArrowDown') {
        if (!props.items.length) {
          return false
        }

        const commands = props.items[selectedGroupIndex.value].commands

        let newCommandIndex = selectedCommandIndex.value + 1
        let newGroupIndex = selectedGroupIndex.value

        if (commands.length - 1 < newCommandIndex) {
          newCommandIndex = 0
          newGroupIndex = selectedGroupIndex.value + 1
        }

        if (props.items.length - 1 < newGroupIndex) {
          newGroupIndex = 0
        }

        selectedCommandIndex.value = newCommandIndex
        selectedGroupIndex.value = newGroupIndex

        return true
      }

      if (event.key === 'ArrowUp') {
        if (!props.items.length) {
          return false
        }

        let newCommandIndex = selectedCommandIndex.value - 1
        let newGroupIndex = selectedGroupIndex.value

        if (newCommandIndex < 0) {
          newGroupIndex = selectedGroupIndex.value - 1
          newCommandIndex = props.items[newGroupIndex]?.commands.length - 1 || 0
        }

        if (newGroupIndex < 0) {
          newGroupIndex = props.items.length - 1
          newCommandIndex = props.items[newGroupIndex].commands.length - 1
        }

        selectedCommandIndex.value = newCommandIndex
        selectedGroupIndex.value = newGroupIndex

        return true
      }

      if (event.key === 'Enter') {
        if (!props.items.length || selectedGroupIndex.value === -1 || selectedCommandIndex.value === -1) {
          return false
        }

        selectItem(selectedGroupIndex.value, selectedCommandIndex.value)

        return true
      }

      return false
    }

    onMounted(() => {
      if (activeItem.value && scrollContainer.value) {
        const offsetTop = activeItem.value.offsetTop
        const offsetHeight = activeItem.value.offsetHeight

        scrollContainer.value.scrollTop = offsetTop - offsetHeight
      }
    })

    const createCommandClickHandler = (groupIndex, commandIndex) => {
      selectItem(groupIndex, commandIndex)
      return true
    }

    onBeforeUnmount(() => {
      // Clean up any event listeners or subscriptions here
    })

    return {
      scrollContainer,
      activeItem,
      selectedGroupIndex,
      selectedCommandIndex,
      onKeyDown,
      createCommandClickHandler,
    }
  },
}
</script>

<style scoped>
/* Add any necessary styles here */
</style>

export const GROUPS = [
  {
    name: 'format',
    title: 'Format',
    commands: [
      {
        name: 'heading1',
        command: '# Heading 1',
        label: 'Heading 1',
        iconName: 'Type, Paragraph, Character/text-h1',
        description: 'High priority section title',
        aliases: ['h1'],
        action: function (editor) {
          editor.chain().focus().setHeading({ level: 1 }).run();
        },
      },
      {
        name: 'heading2',
        label: 'Heading 2',
        iconName: 'Type, Paragraph, Character/text-h2',
        description: 'Medium priority section title',
        aliases: ['h2'],
        action: function (editor) {
          editor.chain().focus().setHeading({ level: 2 }).run();
        },
      },
      {
        name: 'heading3',
        label: 'Heading 3',
        iconName: 'Type, Paragraph, Character/text-h2',
        description: 'Low priority section title',
        aliases: ['h3'],
        action: function (editor) {
          editor.chain().focus().setHeading({ level: 3 }).run();
        },
      },
      {
        name: 'bulletList',
        label: 'Bullet List',
        iconName: 'Type, Paragraph, Character/list-paragraph',
        description: 'Unordered list of items',
        aliases: ['ul'],
        action: function (editor) {
          editor.chain().focus().toggleBulletList().run();
        },
      },
      {
        name: 'numberedList',
        label: 'Numbered List',
        iconName: 'Type, Paragraph, Character/list-paragraph-1-2',
        description: 'Ordered list of items',
        aliases: ['ol'],
        action: function (editor) {
          editor.chain().focus().toggleOrderedList().run();
        },
      },
      {
        name: 'taskList',
        label: 'Task List',
        iconName: 'Type, Paragraph, Character/list-paragraph-checkmark',
        description: 'Task list with todo items',
        aliases: ['todo'],
        action: function (editor) {
          editor.chain().focus().toggleTaskList().run();
        },
      },
      {
        name: 'blockquote',
        label: 'Blockquote',
        iconName: 'Type, Paragraph, Character/text-h2',
        description: 'Element for quoting',
        action: function (editor) {
          editor.chain().focus().setBlockquote().run();
        },
      },
      {
        name: 'codeBlock',
        label: 'Code Block',
        iconName: 'Type, Paragraph, Character/text-h2',
        description: 'Code block with syntax highlighting',
        shouldBeHidden: function (editor) {
          return editor.isActive('columns');
        },
        action: function (editor) {
          editor.chain().focus().setCodeBlock().run();
        },
      },
    ],
  },
  {
    name: 'insert',
    title: 'Insert',
    commands: [
      {
        name: 'table',
        label: 'Table',
        iconName: 'Type, Paragraph, Character/text-h2',
        description: 'Insert a table',
        shouldBeHidden: function (editor) {
          return editor.isActive('columns');
        },
        action: function (editor) {
          editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: false }).run();
        },
      },
      {
        name: 'image',
        label: 'Image',
        iconName: 'Type, Paragraph, Character/text-h2',
        description: 'Insert an image',
        aliases: ['img'],
        action: function (editor) {
          editor.chain().focus().setImageUpload().run();
        },
      },
      {
        name: 'columns',
        label: 'Columns',
        iconName: 'Type, Paragraph, Character/text-h2',
        description: 'Add two column content',
        aliases: ['cols'],
        shouldBeHidden: function (editor) {
          return editor.isActive('columns');
        },
        action: function (editor) {
          editor
            .chain()
            .focus()
            .setColumns()
            .focus(editor.state.selection.head - 1)
            .run();
        },
      },
      {
        name: 'horizontalRule',
        label: 'Horizontal Rule',
        iconName: 'Type, Paragraph, Character/text-h2',
        description: 'Insert a horizontal divider',
        aliases: ['hr'],
        action: function (editor) {
          editor.chain().focus().setHorizontalRule().run();
        },
      },
      {
        name: 'toc',
        label: 'Table of Contents',
        iconName: 'Type, Paragraph, Character/text-h2',
        aliases: ['outline'],
        description: 'Insert a table of contents',
        shouldBeHidden: function (editor) {
          return editor.isActive('columns');
        },
        action: function (editor) {
          editor.chain().focus().insertTableOfContent().run();
        },
      },
    ],
  },
  {
    name: 'layout',
    title: 'Layout',
    commands: [
      {
        name: 'card',
        label: 'Card',
        iconName: 'Hotels/Room, Card',
        description: 'Insert a table',
        shouldBeHidden: function (editor) {
          return editor.isActive('columns');
        },
        action: function (editor) {
          editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: false }).run();
        },
      },
      {
        name: 'stack',
        label: 'Stack',
        iconName: 'Type, Paragraph, Character/column-padding',
        description: 'Insert an image',
        action: function (editor) {
          editor.chain().focus().setImageUpload().run();
        },
      },
      {
        name: 'columns',
        label: 'Columns',
        iconName: 'Table, Edit/column-artboard',
        description: 'Add two column content',
        aliases: ['cols'],
        shouldBeHidden: function (editor) {
          return editor.isActive('columns');
        },
        action: function (editor) {
          editor
            .chain()
            .focus()
            .setColumns()
            .focus(editor.state.selection.head - 1)
            .run();
        },
      },
      {
        name: 'accordion',
        label: 'Accordion',
        iconName: 'Internet, Network/Browser, Internet, Web, Network, Edit',
        description: 'Insert a horizontal divider',
        aliases: ['hr'],
        action: function (editor) {
          editor.chain().focus().setHorizontalRule().run();
        },
      },
      {
        name: 'divider',
        label: 'Divider',
        iconName: 'Type, Paragraph, Character/page-artboard-replace-divider',
        description: 'Insert a table of contents',
        action: function (editor) {
          editor.chain().focus().insertTableOfContent().run();
        },
      },
    ],
  },
];

export default GROUPS;

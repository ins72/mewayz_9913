export * from './trailing-node'

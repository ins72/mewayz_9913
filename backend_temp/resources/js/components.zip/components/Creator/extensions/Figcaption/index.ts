export * from './Figcaption'

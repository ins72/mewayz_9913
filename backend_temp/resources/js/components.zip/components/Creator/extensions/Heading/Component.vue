<template>
	<node-view-wrapper class="block -columns-8 heading -level-1">
	  <node-view-content />
	</node-view-wrapper>
  </template>
  
<script>
  import { NodeViewContent, nodeViewProps, NodeViewWrapper } from '@tiptap/vue-3'
  import { ref, onMounted, onBeforeUnmount } from 'vue'
  
  export default {
	components: {
	  NodeViewWrapper,
	},

	props: {
		...nodeViewProps,
		_options: {
			type: Object
		}
	},
    setup() {
        onMounted(() => {
			
        });
    },
	mounted(){
		console.log(this._options.levels)
	},
	components: {
	  NodeViewWrapper,
	  NodeViewContent,
	},
  }
</script>
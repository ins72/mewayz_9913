import { mergeAttributes } from "@tiptap/core"
import TiptapHeading from "@tiptap/extension-heading"
import Suggestion from '@tiptap/suggestion';
import { PluginKey } from '@tiptap/pm/state';
import Component from './Component.vue'
import { VueNodeViewRenderer } from '@tiptap/vue-3'
import { VueRenderer } from '@tiptap/vue-3';

export const Heading = TiptapHeading.extend({
  /*addNodeView() {
    let _component;
    return (props) => {
      props['_options'] = this.options;
      _component = new VueRenderer(Component, {
        props,
        editor: props.editor,
      });

      return {dom: _component.element};
      console.log(component)
    }
    console.log(props)
    return VueNodeViewRenderer(Component);
  },*/
  renderHTML({ node, HTMLAttributes }) {
    const nodeLevel = parseInt(node.attrs.level, 10)
    const hasLevel = this.options.levels.includes(nodeLevel)
    const level = hasLevel ? nodeLevel : this.options.levels[0]

    HTMLAttributes['class'] = `block -columns-8 heading -level-${level}`

    return [
      `h${level}`,
      mergeAttributes(this.options.HTMLAttributes, HTMLAttributes),
      0
    ]
  },
})

export default Heading

<template>
	<div>
		dfdsfsd
	</div>
  </template>
  
  <script>
  import { NodeViewContent, nodeViewProps, NodeViewWrapper } from '@tiptap/vue-3'
  
  export default {
	props: nodeViewProps,
  
	components: {
	  NodeViewWrapper,
	  NodeViewContent,
	},
  }
  </script>
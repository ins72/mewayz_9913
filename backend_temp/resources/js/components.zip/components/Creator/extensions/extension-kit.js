// 'use client'
import {
  Document,
  SectionNode,
  Paragraph,
  SlashCommand,
  Default,
  Placeholder,
  Heading,
} from '.'
import StarterKit from "@tiptap/starter-kit";
import Text from '@tiptap/extension-text'

const ExtensionKit = () => [
  Document,
  Default,
  Text,
  SectionNode,
  SlashCommand,
  Heading.configure({
    levels: [1, 2, 3, 4, 5, 6],
  }),
]

export default ExtensionKit

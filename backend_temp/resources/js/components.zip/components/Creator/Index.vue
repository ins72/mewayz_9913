

<template>
  <div class="document-content">
    <div>
        
      <floating-menu :editor="editor" :tippy-options="{
        duration: 100, 
        offset: [-2, 16],
        zIndex: 99, }" v-if="editor">
        <button @click="editor.chain().focus().toggleHeading({ level: 1 }).run()" :class="{ 'is-active': editor.isActive('heading', { level: 1 }) }">
          H1
        </button>
        <button @click="editor.chain().focus().toggleHeading({ level: 2 }).run()" :class="{ 'is-active': editor.isActive('heading', { level: 2 }) }">
          H2
        </button>
        <button @click="editor.chain().focus().toggleBulletList().run()" :class="{ 'is-active': editor.isActive('bulletList') }">
          Bullet List
        </button>
      </floating-menu>
      <editor-content :editor="editor" />
    </div>
  </div>
</template>

<script>
import { Editor, EditorContent, FloatingMenu } from '@tiptap/vue-3'
import StarterKit from '@tiptap/starter-kit'
import ExtensionKit from './extensions/extension-kit'

export default {
  components: {
    EditorContent,
    FloatingMenu,
  },

  data() {
    return {
      editor: null,
    }
  },

  mounted() {
    this.editor = new Editor({
      content: `
        <section-node>
          <p>nested</p>
        </section-node>
        
        <p>
          This is an example of a Medium-like editor. Enter a new line and some buttons will appear.
        </p>
        <p></p>
        `,
      extensions: [
        ...ExtensionKit()
      ],
    })
  },

  beforeUnmount() {
    this.editor.destroy()
  },
}
</script>
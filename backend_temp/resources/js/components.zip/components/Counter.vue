

<template>
  <div>
    sdf
  </div>
</template>

<script>
export default {

  data() {
    return {
      editor: null,
    }
  },

  mounted() {
    
  },

  beforeUnmount() {
    
  },
}
</script>